# Akatsuki — Java 2D Game

A university coursework game built with Java, Swing and City CS Engine (JBox2D). This snapshot contains the final classroom version, not the earlier `game1` prototype.

## Features
- Three levels with distinct, multi-phase boss encounters.
- Character movement, collision/sensor interactions, health and gravity changes.
- Dialogue, main menu, pause menu, sound management and a save/load system.
- Shared abstract `GameLevel` and a `GameController` coordinating transitions.

## Run
1. Install JDK 25 (the coursework development version).
2. Obtain `CityEngine.jar` from the university course and place it in `lib/`.
3. On macOS/Linux run `./run.sh`; on Windows run `run.bat`.
4. For IntelliJ: open the folder, set JDK 25, add `src` as source root and `lib/CityEngine.jar` as a library; run `Game` with the project root as working directory.

The engine is not bundled. Source and game assets are included. A personal save is deliberately excluded; the game creates `save.txt` locally.

## Controls
A/D: move. W: jump (or upward movement in relevant combat phases).
W/A/S/D: directional controls in applicable phases. K: dash. Enter: interact/advance dialogue. Escape: pause.

## Provenance and contribution
Source: the author's GitHub Classroom submission `cityteaching/java-project-2026-llllan12432`, commit `5384f80` (11 April 2026). The personal `game1` repository was an earlier version. The coursework engine/template is third-party code, not authored by the student.

The student designed the gameplay and progression and tested, debugged and tuned the implementation. Generative AI assisted substantially with feature code, comments, translation and some assets. See `Use_of_AI.txt` for the original declaration.

## Verification and limitations
Compilation is checked separately in the accompanying verification report. A full gameplay playthrough is still required; compilation alone does not prove all gameplay paths work. Save-file corruption handling and broader automated testing remain improvement areas.

This is an educational fan project. Character, music and art rights are not claimed. Do not describe it as commercially licensed or redistribute third-party assets without checking their permissions.

## October portfolio maintenance
See `REVIEW.md` and `PORTFOLIO_CHANGES.md` for save-data and combat-timer fixes. Run `./test.sh` for dependency-free regression checks. These later changes are separate from the assessed submission. The public source archive intentionally omits the course engine and third-party media; it is not a complete game distribution. The local development copy retains its existing `data/` files.
