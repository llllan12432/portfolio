import java.nio.file.*;
import java.util.concurrent.*;
import javax.swing.*;

/** Run in a fresh temporary working directory; never use a real player's save. */
public final class RegressionTests {
    static int checks = 0;
    static void check(boolean ok, String message) {
        checks++; if (!ok) throw new AssertionError(message);
    }
    public static void main(String[] args) throws Exception {
        check(SaveSystem.load() == null, "Missing save must be recoverable");
        for (String invalid : new String[]{"", "1,5", "oops", "0,5,false,1,2", "4,5,false,1,2", "1,9,false,1,2", "1,5,maybe,1,2", "1,5,true,NaN,2", "1,5,true,1,Infinity"}) {
            Files.writeString(Path.of("save.txt"), invalid);
            check(SaveSystem.load() == null, "Invalid save must not crash: " + invalid);
            check(!SaveSystem.hasSave(), "Invalid save must not enable Load Game");
        }
        SaveSystem.save(2,4,true,1.5f,-3f);
        SaveData save = SaveSystem.load();
        check(save != null && save.levelNum == 2 && save.health == 4 && save.combatWon && save.x == 1.5f && save.y == -3f, "Save round trip must preserve state");
        CountDownLatch fired = new CountDownLatch(1);
        TimerRegistry group = new TimerRegistry();
        SwingUtilities.invokeAndWait(() -> {
            Timer timer = group.create(50, e -> fired.countDown());
            timer.setRepeats(false); timer.start(); group.pause();
        });
        check(!fired.await(120, TimeUnit.MILLISECONDS), "Paused combat must not advance");
        SwingUtilities.invokeAndWait(group::resume);
        check(fired.await(2, TimeUnit.SECONDS), "Combat timer must resume");
        CountDownLatch stale = new CountDownLatch(1);
        SwingUtilities.invokeAndWait(() -> {
            Timer timer = group.create(30, e -> stale.countDown());
            timer.start(); group.close(); timer.start();
        });
        check(!stale.await(100, TimeUnit.MILLISECONDS), "Disposed levels cannot restart timers");
        System.out.println("PASS " + checks + " save/lifecycle regression checks");
        System.exit(0);
    }
}
