import org.jbox2d.common.Vec2;
import javax.swing.*;
import city.cs.engine.*;

/**
 * Level2 — 佩恩（Pain）关卡 / Pain's level.
 *
 * 战斗分两个阶段 / Combat has two phases:
 *   Phase 1: 爆炸冲击波 + 陨石雨（15秒）/ Explosion shockwaves + meteor rain (15s)
 *   Phase 2: 重力翻转演出（5秒，纯演出无伤害，战斗胜利）
 *            Gravity flip sequence (5s, no damage, ends in victory)
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Level2 extends GameLevel {

    private Pain pain;           // 佩恩NPC体 / Pain NPC body
    private PainSensor sensor;   // 佩恩的接近传感器 / Pain's proximity sensor
    private Food food;           // 场景内的饭团 / food pickup in the scene

    private Timer shockwaveTimer; // 阶段一：爆炸生成定时器 / phase 1 explosion spawn timer
    private Timer meteorTimer;    // 阶段一：陨石生成定时器 / phase 1 meteor spawn timer

    // ── 节奏调整区 / Timing constants ────────────────────────────────────
    private static final int COMBAT_START_DELAY = 2000;  // 开始前延迟ms / pre-combat delay
    private static final int PHASE1_DURATION    = 15000; // 阶段一时长ms / phase 1 duration
    private static final int METEOR_START_DELAY = 7000;  // 陨石雨开始延迟ms / meteor rain delay
    private static final int BLACKOUT_DURATION  = 500;   // 黑屏时长ms / blackout duration
    private static final int PHASE2_DURATION    = 5000;  // 阶段二时长ms / phase 2 duration

    // ── 场景构建 / Scene setup ────────────────────────────────────────────

    @Override
    public void populate() {

        StaticBody p1 = new StaticBody(this, new BoxShape(2.3f, 1.9f));
        p1.addImage(new BodyImage("data/dizhuan.png", 1f));
        p1.setPosition(new Vec2(-11f, -7f));  // 左高平台放Food

        StaticBody p2 = new StaticBody(this, new BoxShape(2.3f, 1.9f));
        p2.addImage(new BodyImage("data/dizhuan.png", 1f));
        p2.setPosition(new Vec2(-7f, -4f));   // 中间同高，距p1约9单位，需要冲刺，放SavePoint

        StaticBody p3 = new StaticBody(this, new BoxShape(2.3f, 1.9f));
        p3.addImage(new BodyImage("data/dizhuan.png", 1f));
        p3.setPosition(new Vec2(-3f, -1f));    // 右侧低平台，装饰用

        // 存档点 / save point
        SavePoint savePoint = new SavePoint(this, getRan(), 2);
        savePoint.setPosition(new Vec2(9, 3f));

        // 佩恩NPC及传感器 / Pain NPC with sensor
        pain = new Pain(this);
        pain.setPosition(new Vec2(6, -5.3f));
        sensor = new PainSensor(pain);

        // 饭团拾取物 / food pickup
        food = new Food(this);
        food.setPosition(new Vec2(-3, 1f));

        // 场景背景 / scene background
        StaticBody background = new StaticBody(this);
        background.addImage(new BodyImage("data/painbeijing.png", 20f));
        background.setPosition(new Vec2(0, 0));
    }

    // ── 战斗流程 / Combat sequence ────────────────────────────────────────

    @Override
    public void startCombat(Ran ran, UserInterface ui) {
        Timer startDelay = managedTimer(COMBAT_START_DELAY, e -> {
            ((Timer) e.getSource()).stop();
            startPhase1(ran, ui);
        });
        startDelay.setRepeats(false);
        startDelay.start();
    }

    /**
     * 阶段一：持续爆炸覆盖战斗框，7秒后叠加陨石雨。
     * Phase 1: Continuous explosions cover the combat box; meteor rain added after 7s.
     */
    private void startPhase1(Ran ran, UserInterface ui) {
        ui.combatPhase = 1;

        // 每80ms在随机位置生成爆炸，距玩家1.5单位内跳过（给玩家留一口气）
        // Every 80ms spawn an explosion at a random position; skip within 1.5 units of player
        shockwaveTimer = managedTimer(80, e -> {
            float x = (float) (Math.random() * 7 - 3.5);
            float y = (float) (Math.random() * 5 + 47.5f);
            float dx = x - ran.getPosition().x;
            float dy = y - ran.getPosition().y;
            if (Math.sqrt(dx * dx + dy * dy) > 1.5f) {
                new Explosion(this, ran, x, y);
            }
        });
        shockwaveTimer.start();

        // 7秒后额外叠加陨石雨 / add meteor rain on top after 7s
        Timer meteorStart = managedTimer(METEOR_START_DELAY, e -> {
            ((Timer) e.getSource()).stop();
            meteorTimer = managedTimer(400, em -> {
                float x = (float) (Math.random() * 9 - 3);
                new Meteor(this, ran, x);
            });
            meteorTimer.start();
        });
        meteorStart.setRepeats(false);
        meteorStart.start();

        // 阶段一结束：清场 → 黑屏 → 阶段二
        // Phase 1 end: clear field → blackout → phase 2
        Timer phase1End = managedTimer(PHASE1_DURATION, e -> {
            ((Timer) e.getSource()).stop();
            shockwaveTimer.stop();
            if (meteorTimer != null) meteorTimer.stop();
            clearMeteors();
            clearExplosions();
            ui.playCombatBlackout(BLACKOUT_DURATION, () -> startPhase2(ran, ui));
        });
        phase1End.setRepeats(false);
        phase1End.start();
    }

    /**
     * 阶段二：重力翻转演出，无伤害，结束后判定战斗胜利。
     * Phase 2: Gravity-flip sequence (no damage); victory is declared at the end.
     */
    private void startPhase2(Ran ran, UserInterface ui) {
        ui.combatPhase = 2;

        // 切换蓝魂模式，玩家变为蓝心并受重力影响
        // Switch to blue-soul mode: player becomes a blue heart under gravity
        sensor.setBlueMode(true);
        ran.setGravityScale(2f);
        ran.setCombatHitbox(false);
        ran.removeAllImages();
        ran.setPosition(new Vec2(0, 45.5f));

        // 透明地面，触地播震动音效 / transparent floor, plays thud on contact
        StaticBody floor = new StaticBody(this, new BoxShape(4f, 0.2f));
        floor.setPosition(new Vec2(0, 45f));
        floor.setFillColor(new java.awt.Color(0, 0, 0, 0));
        floor.setLineColor(new java.awt.Color(0, 0, 0, 0));
        floor.addCollisionListener(new CollisionListener() {
            @Override
            public void collide(CollisionEvent e) {
                if (e.getOtherBody() == ran) {
                    SoundManager.play("jumpland");
                    ui.triggerShake();
                }
            }
        });

        // 透明天花板 / transparent ceiling
        StaticBody ceiling = new StaticBody(this, new BoxShape(4f, 0.2f));
        ceiling.setPosition(new Vec2(0, 55f));
        ceiling.setFillColor(new java.awt.Color(0, 0, 0, 0));
        ceiling.setLineColor(new java.awt.Color(0, 0, 0, 0));
        ceiling.addCollisionListener(new CollisionListener() {
            @Override
            public void collide(CollisionEvent e) {
                if (e.getOtherBody() == ran) {
                    SoundManager.play("jumpland");
                    ui.triggerShake();
                }
            }
        });

        // 左右隐形墙，防止玩家飘出战斗框 / invisible side walls to contain the player
        StaticBody wallLeft = new StaticBody(this, new BoxShape(0.2f, 5f));
        wallLeft.setPosition(new Vec2(-4.2f, 40f));
        wallLeft.setFillColor(new java.awt.Color(0, 0, 0, 0));
        wallLeft.setLineColor(new java.awt.Color(0, 0, 0, 0));

        StaticBody wallRight = new StaticBody(this, new BoxShape(0.2f, 5f));
        wallRight.setPosition(new Vec2(4.2f, 40f));
        wallRight.setFillColor(new java.awt.Color(0, 0, 0, 0));
        wallRight.setLineColor(new java.awt.Color(0, 0, 0, 0));

        // 每250ms翻转重力，制造失重感 / flip gravity every 250ms for weightlessness
        Timer gravityTimer = managedTimer(250, e -> {
            ran.setLinearVelocity(new Vec2(ran.getLinearVelocity().x, 0));
            ran.setGravityScale(ran.getGravityScale() > 0 ? -30f : 30f);
        });
        gravityTimer.start();

        // 阶段二结束，判定胜利 / phase 2 ends, declare victory
        Timer phase2End = managedTimer(PHASE2_DURATION, e -> {
            ((Timer) e.getSource()).stop();
            gravityTimer.stop();
            ran.setGravityScale(0);
            ran.setLinearVelocity(new Vec2(0, 0));

            // 短暂停顿后切回场景 / brief settle before returning to scene
            Timer settleTimer = managedTimer(100, es -> {
                ((Timer) es.getSource()).stop();
                sensor.setBlueMode(false);
                ran.setGravityScale(1);
                ran.setCombatHitbox(false);
                ran.removeAllImages();
                ran.addImage(new BodyImage("data/11xin.png", 1.5f));
                ran.setPosition(new Vec2(6, -5f));
                ran.setLinearVelocity(new Vec2(0, 0));
                sensor.setCombatActive(false);
                sensor.setCombatWon(true);
                sensor.resetDialogue();
                SoundManager.playBGM(getSceneBGM());
                ui.playScript(Dialogue.PAIN_TALK_AFTER);
            });
            settleTimer.setRepeats(false);
            settleTimer.start();
        });
        phase2End.setRepeats(false);
        phase2End.start();
    }

    // ── 清理方法 / Cleanup methods ────────────────────────────────────────

    /** 销毁战斗框内所有陨石 / Destroy all Meteor bodies in the combat box. */
    private void clearMeteors() {
        for (DynamicBody b : getDynamicBodies()) {
            if (b instanceof Meteor) b.destroy();
        }
    }

    /** 销毁战斗框内所有爆炸体 / Destroy all Explosion bodies in the combat box. */
    private void clearExplosions() {
        for (DynamicBody b : getDynamicBodies()) {
            if (b instanceof Explosion) b.destroy();
        }
    }

    // ── 接口实现 / Interface implementations ─────────────────────────────

    @Override public String[]   getTalkScript()      { return Dialogue.PAIN_TALK; }
    @Override public String[]   getTalkAfterScript() { return Dialogue.PAIN_TALK_AFTER; }
    @Override public NpcSensor  getSensor()          { return sensor; }
    @Override public String     getCombatBGM()       { return "data/Pain.wav"; }
    @Override public String     getSceneBGM()        { return "data/Pain.wav"; }
    @Override public String     getCombatImagePath() { return "data/pain.png"; }
}