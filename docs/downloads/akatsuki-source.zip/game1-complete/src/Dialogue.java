/**
 * Dialogue — 游戏全部对话/独白的文本库 / Central repository for all in-game dialogue and narration.
 *
 * 每个 String[] 对应一段剧情，格式为 "角色名: 台词"。
 * Each String[] represents a script segment, formatted as "CHARACTER: line".
 * UserInterface 的打字机系统会自动按冒号拆分名字与内容。
 * The typewriter system in UserInterface splits on the colon to extract name and content.
 *
 * 前缀约定 / Prefix conventions:
 *   DARK:  — 黑屏独白，画在遮罩层上 / narration shown over black overlay
 *   WARN:  — 警告提示（光敏）/ photosensitivity warning
 *   其他   — 普通对话框 / standard dialogue box
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Dialogue {

    // ── 开场独白：Ran 醒来后的内心独白 ──────────────────────────────────
    // Opening monologue: Ran's inner voice upon waking in the Akatsuki world.
    public static final String[] START_STORY = {
            "RAN:……",
            "RAN:?",
            "RAN:Where am I? The smell of mold and blood in the air is unbearable.",
            "RAN:Black cloak, red clouds... Akatsuki robes? How did I end up here...",
            "RAN:My body feels impossibly heavy, and my mind is a blur.\n Wasn't I supposed to be resting at the guest house?",
            "RAN:This isn't a dream. The pain, the sensation — all far too real... tch."
    };

    // ── Level 1：蝎（Sasori）战前对话 / Pre-combat dialogue with Sasori ──
    public static final String[] XIE_TALK = {
            "SASORI: Hey. Ran.",
            "SASORI: ......",
            "SASORI: Your eyes are different. Who are you?",
            "RAN: I am Ran.",
            "RAN: You must be Sasori. I've heard of you.",
            "SASORI: Hmph. If you're not her, then this body is of no use.",
            "RAN: !?"
    };

    // Level 1：蝎战斗结束后的对话 / Post-combat dialogue with Sasori
    public static final String[] XIE_TALK_AFTER = {
            "SASORI: The way you dodge... identical to hers.",
            "SASORI: Tch. Go let the leader take a look at whatever you are."
    };

    // ── Level 2：佩恩（Pain）战前对话 / Pre-combat dialogue with Pain ────
    public static final String[] PAIN_TALK = {
            "PAIN: A soul from another world — why does it inhabit this vessel?",
            "RAN: I'm looking for answers myself. Tell me where Uchiha Itachi is.\n He may know a way.",
            "PAIN: Uncertainty has no place in this order. If you cannot survive\n within it, then this is where you end.",
            "RAN: Tch."
    };

    // Level 2：佩恩战斗结束后的对话 / Post-combat dialogue with Pain
    public static final String[] PAIN_TALK_AFTER = {
            "PAIN: To hold a soul steady without it unraveling...",
            "PAIN: Itachi is ahead, at the Samsara Tower.\n Go confirm your own fate."
    };

    // ── Level 3：鼬（Itachi）战前对话 / Pre-combat dialogue with Itachi ──
    public static final String[] ITACHI_TALK = {
            "RAN: Itachi. You look far worse than the you I know.\n Can you tell me why I've ended up here, in Akatsuki?",
            "ITACHI: ...Ran?",
            "ITACHI: No. You're not her. Your state — it's as though a consciousness\n has been forced into a vessel that isn't yours.",
            "RAN: That's exactly how it feels. Everything here is wrong, Itachi. Even\n you feel like a stranger. I just want to know why I'm here.",
            "ITACHI: Not just your personality — even your abilities are gone? In\n this place, the way you are now, you wouldn't last three\n minutes.",
            "ITACHI: The Hokage's only daughter has no business in a den of\n missing-nin.",
            "RAN: So what are you going to do about it?",
            "ITACHI: Drive you out. What comes next will be violent — it's meant\n to sever your connection to this time and space.\n Only when your mind reaches its breaking point can you return."
    };

    // Level 3：鼬战斗接近尾声时的对话 / Dialogue near the end of Itachi's combat
    public static final String[] ITACHI_TALK_AFTER = {
            "ITACHI: One last step. Close your eyes. Don't resist the pain."
    };

    // ── 结局独白 / Ending narration ────────────────────────────────────
    // DARK: 前缀的行画在黑色遮罩上，其余行用普通对话框
    // Lines prefixed with DARK: are drawn over the black overlay; others use the dialogue box.
    public static final String[] ENDING = {
            "DARK:......",
            "DARK:Am I dead?",
            "ITACHI: You're awake.",
            "RAN: Mm...",
            "RAN: I dreamed of you — back in Akatsuki. You were so cold.",
            "ITACHI: That was a long time ago...",
            "ITACHI: Or perhaps — a version of me I never wanted you to see."
    };

    // 光敏警告文本，在Level3战斗黑屏期间显示于画面中央
    // Photosensitivity warning shown in Level 3's combat blackout screen.
    public static final String[] PHOTOSENSITIVE_WARNING = {
            "WARN: This sequence contains flashing lights and rapidly changing images.",
            "WARN: It may affect players with photosensitive epilepsy. Press Enter to continue."
    };
}