import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Pillar — Level3 阶段二从左右两侧横扫的柱子障碍物 / Horizontal pillar obstacle in Level3 phase 2.
 *
 * 使用 StaticBody 而非 DynamicBody，因为引擎的 DynamicBody 在
 * setPosition 驱动下移动会产生物理推力，干扰蓝魂阶段的玩家重力控制。
 * StaticBody is used instead of DynamicBody because DynamicBody movement via setPosition
 * would generate physical impulses that interfere with the blue-soul gravity control.
 *
 * 碰撞检测通过 Level3 的 StepListener 手动计算距离实现，而不依赖物理引擎
 * 的碰撞事件，因为 StaticBody 与 DynamicBody 之间的碰撞事件不可靠。
 * Collision detection is done via manual distance checks in Level3's StepListener
 * rather than physics collision events, which are unreliable between StaticBody and DynamicBody.
 *
 * 飞出战斗框边界后自动销毁，防止堆积。
 * Auto-destroys when it flies out of the combat box bounds to prevent accumulation.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Pillar extends StaticBody {

    // 每帧移动速度（正值向右，负值向左）/ movement speed per frame (positive = right, negative = left)
    private float speed;

    /**
     * @param world   所属物理世界 / physics world
     * @param ran     玩家引用（预留，当前伤害逻辑在Level3中处理）/ player reference (damage handled in Level3)
     * @param startX  初始X坐标（战斗框左边界约-5，右边界约5）/ initial X (left ~-5, right ~5)
     * @param y       固定Y坐标 / fixed Y position
     * @param speed   横向移动速度 / horizontal movement speed
     * @param tall    是否使用高柱贴图 / whether to use the tall pillar sprite
     */
    public Pillar(World world, Ran ran, float startX, float y, float speed, boolean tall) {
        super(world, new BoxShape(0.001f, 0.001f)); // 极小碰撞体，实际碰撞由Level3手动检测 / minimal shape; collision detected manually
        this.speed = speed;
        setPosition(new Vec2(startX, y));
        // 根据高度参数选择贴图 / select sprite based on height parameter
        addImage(tall
                ? new BodyImage("data/pillar2.png", 3f)
                : new BodyImage("data/pillar.png", 3f));
    }

    /**
     * 每帧由 Level3 的 StepListener 调用，更新柱子位置并在飞出边界后销毁。
     * Called every frame by Level3's StepListener to move the pillar and destroy it when out of bounds.
     */
    public void move() {
        Vec2 pos = getPosition();
        setPosition(new Vec2(pos.x + speed * 0.016f, pos.y)); // 16ms/帧 ≈ 60fps / 16ms per frame ≈ 60fps
        // 飞出战斗框两侧则销毁 / destroy when beyond the combat box sides
        if (pos.x > 6f || pos.x < -6f) {
            destroy();
        }
    }
}