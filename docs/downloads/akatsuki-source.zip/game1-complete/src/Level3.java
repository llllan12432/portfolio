import org.jbox2d.common.Vec2;
import javax.swing.*;
import city.cs.engine.*;

/**
 * Level3 — 鼬（Itachi）关卡 / Itachi's level.
 *
 * 战斗分三个阶段 / Combat has three phases:
 *   Phase 1: 追踪乌鸦（9秒）/ Tracking crows (9s)
 *   Phase 2: 蓝魂重力柱子（6秒）/ Blue-soul gravity with pillar obstacles (6s)
 *   Phase 3: 火焰边框演出 → 强制死亡结局 / Fire border sequence → forced-death ending
 *
 *   @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Level3 extends GameLevel {

    private Itachi itachi;           // 鼬NPC体 / Itachi NPC body
    private ItachiSensor sensor;     // 鼬的接近传感器 / Itachi's proximity sensor
    private Food food;               // 场景内的饭团 / food pickup
    private long lastPillarHitTime = 0; // 柱子伤害冷却时间戳（毫秒）/ pillar damage cooldown timestamp

    // ── 场景构建 / Scene setup ────────────────────────────────────────────

    @Override
    public void populate() {

        StaticBody p1 = new StaticBody(this, new BoxShape(2.3f, 1.9f));
        p1.addImage(new BodyImage("data/dizhuan.png", 1f));
        p1.setPosition(new Vec2(-2f, -7f));

        StaticBody p2 = new StaticBody(this, new BoxShape(2.3f, 1.9f));
        p2.addImage(new BodyImage("data/dizhuan.png", 1f));
        p2.setPosition(new Vec2(-11f, -7f));

        // 存档点 / save point
        SavePoint savePoint = new SavePoint(this, getRan(), 3);
        savePoint.setPosition(new Vec2(-2, -4.5f));

        // 鼬NPC及传感器 / Itachi NPC with sensor
        itachi = new Itachi(this);
        itachi.setPosition(new Vec2(6, -5.3f));
        sensor = new ItachiSensor(itachi);

        // 饭团拾取物 / food pickup
        food = new Food(this);
        food.setPosition(new Vec2(-11, -4.5f));

        // 场景背景 / scene background
        StaticBody background = new StaticBody(this);
        background.addImage(new BodyImage("data/youbeijing.png", 20f));
        background.setPosition(new Vec2(0, 0));
    }

    // ── 战斗流程 / Combat sequence ────────────────────────────────────────

    @Override
    public void startCombat(Ran ran, UserInterface ui) {
        // 战斗开始前短暂延迟 / brief delay before combat begins
        Timer startDelay = managedTimer(1500, e -> {
            ui.showMeme = true; // 显示鼬meme背景 / show Itachi meme background
            SoundManager.playBGM(getCombatBGM());
            ui.combatPhase = 1;

            // 每700ms生成一只追踪乌鸦 / spawn a tracking crow every 700ms
            final Timer[] crowTimer = {managedTimer(700, ec -> {
                float x = (float) (Math.random() * 6 - 3);
                new CrowBall(this, ran, x, 52f);
            })};
            crowTimer[0].start();

            // StepListener：每帧更新乌鸦追踪 + 检查柱子伤害 + 火焰边框伤害
            // StepListener: update crow AI, check pillar damage, and fire border damage each frame
            addManagedStepListener(new StepListener() {
                @Override
                public void preStep(StepEvent e) {
                    // 乌鸦追踪逻辑 / crow AI tracking
                    for (DynamicBody b : getDynamicBodies()) {
                        if (b instanceof CrowBall) {
                            ((CrowBall) b).chase();
                        }
                    }

                    // 火焰边框激活时：检测玩家是否超出战斗框边界
                    // When fire border is active: deal damage if player is outside combat box
                    if (sensor.isFireActive()) {
                        Vec2 pos = ran.getPosition();
                        long now = System.currentTimeMillis();
                        boolean nearEdge = pos.x < -3.5f || pos.x > 3.5f
                                || pos.y < 45.8f || pos.y > 52.5f;
                        if (nearEdge && now - lastPillarHitTime > 1000) {
                            lastPillarHitTime = now;
                            ran.decrementHealth();
                        }
                    }

                    // 柱子碰撞：StaticBody没有物理碰撞事件，改用手动距离检测
                    // Pillar collision: StaticBody has no collision events, so use manual distance check
                    for (StaticBody b : getStaticBodies()) {
                        if (b instanceof Pillar) {
                            ((Pillar) b).move();
                            float dx = b.getPosition().x - ran.getPosition().x;
                            float dy = b.getPosition().y - ran.getPosition().y;
                            float dist = (float) Math.sqrt(dx * dx + dy * dy);
                            if (dist < 0.5f) {
                                long now = System.currentTimeMillis();
                                if (now - lastPillarHitTime > 1000) {
                                    lastPillarHitTime = now;
                                    ran.decrementHealth();
                                }
                            }
                        }
                    }
                }

                @Override
                public void postStep(StepEvent e) {}
            });

            // 9秒后进入阶段二 / phase 2 begins after 9 seconds
            Timer phase1Timer = managedTimer(9000, e2 -> {
                ui.combatPhase = 2;
                crowTimer[0].stop();
                // 清除所有乌鸦 / clear all crows
                for (DynamicBody b : getDynamicBodies()) {
                    if (b instanceof CrowBall) b.destroy();
                }

                // 左右隐形墙，防止玩家飘出 / invisible side walls
                StaticBody wallLeft = new StaticBody(this, new BoxShape(0.2f, 5f));
                wallLeft.setPosition(new Vec2(-4.2f, 48f));
                wallLeft.setFillColor(new java.awt.Color(0, 0, 0, 0));
                wallLeft.setLineColor(new java.awt.Color(0, 0, 0, 0));

                StaticBody wallRight = new StaticBody(this, new BoxShape(0.2f, 5f));
                wallRight.setPosition(new Vec2(4.2f, 48f));
                wallRight.setFillColor(new java.awt.Color(0, 0, 0, 0));
                wallRight.setLineColor(new java.awt.Color(0, 0, 0, 0));

                // 切换蓝魂模式 / switch to blue-soul mode
                sensor.setBlueMode(true);
                ran.setGravityScale(2f);
                ran.setCombatHitbox(false);
                ran.removeAllImages();
                ran.setPosition(new Vec2(0, 45.5f));

                // 透明地面，触地时震动 / transparent floor with thud on contact
                StaticBody floor = new StaticBody(this, new BoxShape(4f, 0.2f));
                floor.setPosition(new Vec2(0, 45f));
                floor.setFillColor(new java.awt.Color(0, 0, 0, 0));
                floor.setLineColor(new java.awt.Color(0, 0, 0, 0));
                floor.addCollisionListener(new CollisionListener() {
                    @Override
                    public void collide(CollisionEvent e) {
                        if (e.getOtherBody() == ran) {
                            SoundManager.play("jumpland");
                            ui.triggerShake();
                        }
                    }
                });

                // 透明天花板 / transparent ceiling
                StaticBody ceiling = new StaticBody(this, new BoxShape(4f, 0.2f));
                ceiling.setPosition(new Vec2(0, 55f));
                ceiling.setFillColor(new java.awt.Color(0, 0, 0, 0));
                ceiling.setLineColor(new java.awt.Color(0, 0, 0, 0));
                ceiling.addCollisionListener(new CollisionListener() {
                    @Override
                    public void collide(CollisionEvent e) {
                        if (e.getOtherBody() == ran) {
                            SoundManager.play("jumpland");
                            ui.triggerShake();
                        }
                    }
                });

                // 交替从左右两侧生成移动柱子 / alternating pillars from left and right
                final boolean[] fromLeft = {true};
                final Timer[] pillarTimer = {managedTimer(700, ep -> {
                    float startX = fromLeft[0] ? -5f : 5f;
                    float spd    = fromLeft[0] ? 8f : -8f;
                    boolean tall = fromLeft[0]; // 左侧用高柱，右侧用矮柱 / tall from left, short from right
                    fromLeft[0]  = !fromLeft[0];
                    new Pillar(this, ran, startX, 47.3f, spd, tall);
                })};
                pillarTimer[0].start();

                // 6秒后进入阶段三 / phase 3 begins after 6 seconds
                Timer phase2Timer = managedTimer(6000, e3 -> {
                    pillarTimer[0].stop();
                    sensor.setBlueMode(false);
                    ran.setGravityScale(0);
                    ran.removeAllImages();
                    ran.addImage(new BodyImage("data/11xin.png", 1.5f));

                    // 清除所有柱子 / clear all pillars
                    for (StaticBody b : getStaticBodies()) {
                        if (b instanceof Pillar) b.destroy();
                    }

                    ui.combatPhase = 3;
                    sensor.setFireActive(true); // 激活火焰边框伤害 / activate fire border damage
                    ran.setCombatHitbox(true);
                    ran.removeAllImages();
                    ran.addImage(new BodyImage("data/11xin.png", 1.5f));

                    // 火焰演出：小火 → 大火 → 强制死亡结局
                    // Fire sequence: small fire → big fire → forced death ending
                    Timer fireGrowTimer = managedTimer(900, e4 -> {
                        ui.fireImg = new ImageIcon("data/shaoqilai.gif").getImage();
                        Timer fireBigTimer = managedTimer(300, e5 -> {
                            ui.fireImg = new ImageIcon("data/dahuoshao.gif").getImage();
                            // 强制死亡触发结局 / force death to trigger the ending
                            Timer deathTimer = managedTimer(100, ef -> {
                                ran.setForceDeath(true);
                                ran.setHealth(1);
                                ran.decrementHealth();
                            });
                            deathTimer.setRepeats(false);
                            deathTimer.start();
                        });
                        fireBigTimer.setRepeats(false);
                        fireBigTimer.start();
                    });
                    fireGrowTimer.setRepeats(false);
                    fireGrowTimer.start();

                    // 30秒保险定时器，防止阶段三无限延续 / safety timer to end phase 3 after 30s
                    Timer phase3Timer = managedTimer(30000, e4 -> sensor.setFireActive(false));
                    phase3Timer.setRepeats(false);
                    phase3Timer.start();
                });
                phase2Timer.setRepeats(false);
                phase2Timer.start();
            });
            phase1Timer.setRepeats(false);
            phase1Timer.start();
        });
        startDelay.setRepeats(false);
        startDelay.start();
    }

    // ── 接口实现 / Interface implementations ─────────────────────────────

    @Override public String[]      getTalkScript()      { return Dialogue.ITACHI_TALK; }
    @Override public String[]      getTalkAfterScript() { return Dialogue.ITACHI_TALK_AFTER; }
    @Override public String        getCombatBGM()       { return "data/youmeme.wav"; }
    @Override public NpcSensor     getSensor()          { return sensor; }
    @Override public String        getSceneBGM()        { return "data/Itachi.wav"; }
    @Override public String        getCombatImagePath() { return "data/you.png"; }
}