import city.cs.engine.*;

/**
 * Food — 场景中的饭团拾取物 / Rice ball pickup item placed in each level.
 *
 * 玩家走近后按 Enter 可恢复满血（由 Interaction 处理）。
 * When the player is nearby and presses Enter, health is fully restored (handled by Interaction).
 * 使用 StaticBody 保持固定位置，碰撞体为小方块与贴图对齐。
 * Uses StaticBody to stay in place; collision box is a small square aligned with the sprite.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Food extends StaticBody {

    /**
     * @param w 所属物理世界 / physics world
     */
    public Food(World w) {
        super(w, new BoxShape(0.5f, 0.5f));
        addImage(new BodyImage("data/11fantuan.png", 1.5f));
        // 命名用于在 Interaction 里通过 instanceof 之外的方式识别（保留兼容性）
        // Named for identification; class-based instanceof checks are preferred in logic
        setName("fantuan");
    }
}