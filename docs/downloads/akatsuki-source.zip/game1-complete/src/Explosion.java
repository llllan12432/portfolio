import org.jbox2d.common.Vec2;
import city.cs.engine.*;
import javax.swing.Timer;

/**
 * Explosion — 佩恩关卡（Level 2）的爆炸特效体 / Explosion visual effect used in Pain's level (Level 2).
 *
 * 使用 GhostlyFixture 而非 SolidFixture，使其只参与碰撞检测而不产生物理推力。
 * Uses a GhostlyFixture so it registers collision events without applying physical impulses.
 * 碰撞到玩家时扣一滴血并立即销毁自身，存活时间极短（400ms）。
 * On contact with the player, deals one damage and destroys itself; lifespan is 400ms.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Explosion extends DynamicBody {

    // 爆炸动画贴图 / Animated explosion GIF
    private static final BodyImage explodeImage = new BodyImage("data/baizha.gif", 6f);

    // 碰撞体形状（幽灵体，不产生推力）/ Collision shape (ghostly, no physical push)
    private static final Shape shape = new CircleShape(0.5f);

    /**
     * @param world 所属物理世界 / physics world
     * @param ran   玩家角色引用，用于碰撞扣血 / player reference for damage on collision
     * @param x     生成的X坐标（战斗框坐标系）/ spawn X position in combat coordinate space
     * @param y     生成的Y坐标（战斗框坐标系）/ spawn Y position in combat coordinate space
     */
    public Explosion(World world, Ran ran, float x, float y) {
        super(world); // 不带形状，之后用GhostlyFixture / no shape here; added as GhostlyFixture below
        new GhostlyFixture(this, shape); // 只检测碰撞，不产生物理推力 / collision only, no physical force

        // 无重力，固定悬浮在生成位置 / no gravity, stays at spawn position
        setGravityScale(0);
        setPosition(new Vec2(x, y));
        setLinearVelocity(new Vec2(0, 0));
        addImage(explodeImage);

        // 碰撞到玩家时扣血并销毁 / deal damage and destroy on player contact
        addCollisionListener(new CollisionListener() {
            @Override
            public void collide(CollisionEvent e) {
                if (e.getOtherBody() == ran) {
                    ran.decrementHealth();
                    destroy();
                }
            }
        });

        // 400ms 后自动消失，防止爆炸堆积 / auto-destroy after 400ms to prevent accumulation
        Timer lifeTimer = new Timer(400, e -> destroy());
        lifeTimer.setRepeats(false);
        lifeTimer.start();
    }
}