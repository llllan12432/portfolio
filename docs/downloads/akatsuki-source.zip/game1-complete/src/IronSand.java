import city.cs.engine.*;
import java.awt.Color;

/**
 * IronSand — 蝎（Sasori）战斗关卡的铁砂弹丸 / Iron sand projectile used in Sasori's combat.
 *
 * 无重力的动态体，由 Level1 的定时器生成并赋予初速度。
 * A gravity-free dynamic body spawned and given velocity by Level1's timers.
 * 支持两种模式：有伤害（默认）和无伤害（用于演出粒子效果）。
 * Supports two modes: damaging (default) and non-damaging (for visual-only particle effects).
 * 碰撞到玩家时扣一滴血并销毁自身。
 * On contact with the player, deals one damage and destroys itself.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class IronSand extends DynamicBody {

    // 铁砂贴图和碰撞体形状 / sprite and collision shape
    private static final BodyImage moshuImage = new BodyImage("data/ci2.png", 4f);
    private static final Shape shape = new CircleShape(0.2f);

    /**
     * 默认构造函数（有伤害）。
     * Default constructor (damaging mode).
     *
     * @param world   所属物理世界 / physics world
     * @param ran     玩家引用，用于碰撞扣血 / player reference for damage
     * @param startX  初始X坐标 / initial X position
     * @param startY  初始Y坐标 / initial Y position
     */
    public IronSand(World world, Ran ran, float startX, float startY) {
        this(world, ran, startX, startY, true);
    }

    /**
     * 完整构造函数，可选是否造成伤害。
     * Full constructor with optional damage mode.
     *
     * @param world      所属物理世界 / physics world
     * @param ran        玩家引用 / player reference
     * @param startX     初始X坐标 / initial X position
     * @param startY     初始Y坐标 / initial Y position
     * @param isDamaging 是否对玩家造成伤害 / whether this projectile damages the player
     */
    public IronSand(World world, Ran ran, float startX, float startY, boolean isDamaging) {
        super(world, shape);
        addImage(moshuImage);

        // 计算朝向战斗框中心(0,50)的角度，旋转贴图使尖端朝前
        // Calculate angle toward combat center (0,50) so the sprite points in the direction of travel
        double angle = Math.atan2(50 - startY, 0 - startX);
        setAngle((float) angle + (float) Math.PI);

        setGravityScale(0); // 无重力，在战斗框内直线飞行 / no gravity, travels in a straight line

        // 只有 isDamaging 为 true 时才注册碰撞扣血
        // Only register damage collision listener in damaging mode
        if (isDamaging) {
            addCollisionListener(new CollisionListener() {
                @Override
                public void collide(CollisionEvent e) {
                    if (e.getOtherBody() == ran) {
                        ran.decrementHealth();
                        destroy(); // 命中后销毁 / destroy on hit
                    }
                    // 铁砂之间互相忽略，不处理 / IronSand vs IronSand collisions are ignored
                }
            });
        }
    }
}