import org.jbox2d.common.Vec2;
import javax.swing.*;
import city.cs.engine.*;

/**
 * Level1 — 蝎（Sasori）关卡 / Sasori's level.
 *
 * 是游戏第一关，也是唯一有开场独白的关卡（isIntroLevel = true）。
 * This is the first level and the only one with an opening monologue (isIntroLevel = true).
 *
 * 战斗分三个阶段 / Combat has three phases:
 *   Phase 1: 四面八方铁砂（9秒）/ Iron sand from all directions (9s)
 *   Phase 2: 粒子聚集演出 + 顶部铁砂雨（9秒）/ Particle gather effect + rain from above (9s)
 *   Phase 3: 混合高速铁砂 + 列状攻击（7秒）/ Fast mixed sand + column attacks (7s)
 *
 *   @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Level1 extends GameLevel {

    private Sasori sasori;         // 蝎NPC体 / Sasori NPC body
    private SasoriSensor sensor;   // 蝎的接近传感器 / Sasori's proximity sensor
    private Timer sandTimer;       // 持续生成铁砂的定时器 / timer for continuous sand spawning

    // ── 节奏调整区：根据BGM修改这里 / Timing constants: adjust to match BGM ──
    private static final int PHASE1_DURATION    = 4000;  // 阶段一时长ms / phase 1 duration
    private static final int PHASE2_DURATION    = 4000;  // 阶段二时长ms / phase 2 duration
    private static final int PHASE3_DURATION    = 7000;  // 阶段三时长ms / phase 3 duration
    private static final int BLACKOUT_DURATION  = 500;   // 阶段切换黑屏时长ms / blackout between phases
    private static final int COMBAT_START_DELAY = 2000;  // 战斗开始前延迟ms / pre-combat delay

    // ── 场景构建 / Scene setup ────────────────────────────────────────────

    @Override
    public void populate() {
        // 蝎NPC及其传感器 / Sasori NPC with sensor
        sasori = new Sasori(this);
        sasori.setPosition(new Vec2(6, -5.3f));
        sensor = new SasoriSensor(sasori);

        StaticBody p1 = new StaticBody(this, new BoxShape(2.3f, 1.9f));
        p1.addImage(new BodyImage("data/xiedizhuan.png", 1f));
        p1.setPosition(new Vec2(-7f, -7f));

        StaticBody p2 = new StaticBody(this, new BoxShape(2.3f, 1.9f));
        p2.addImage(new BodyImage("data/xiedizhuan.png", 1f));
        p2.setPosition(new Vec2(1f, -5f));

        // 场景背景图 / scene background image
        StaticBody background = new StaticBody(this);
        background.addImage(new BodyImage("data/beijingxie2.png", 20f));
        background.setPosition(new Vec2(0, 0));


    }

    // ── 战斗流程 / Combat sequence ────────────────────────────────────────

    @Override
    public void startCombat(Ran ran, UserInterface ui) {
        // 开始前短暂延迟，让玩家做好准备 / brief delay before combat starts
        Timer startDelay = managedTimer(COMBAT_START_DELAY, e -> {
            ((Timer) e.getSource()).stop();
            startPhase1(ran, ui);
        });
        startDelay.setRepeats(false);
        startDelay.start();
    }

    /**
     * 阶段一：铁砂从四面八方飞向战斗框中心。
     * Phase 1: Iron sand flies toward the combat box center from all directions.
     */
    private void startPhase1(Ran ran, UserInterface ui) {
        ui.combatPhase = 1;
        sandTimer = managedTimer(220, e -> spawnSand(ran, 9f));
        sandTimer.start();

        Timer phase1End = managedTimer(PHASE1_DURATION, e -> {
            ((Timer) e.getSource()).stop();
            sandTimer.stop();
            clearSand();
            // 黑屏过渡后进入阶段二 / blackout transition then phase 2
            ui.playCombatBlackout(BLACKOUT_DURATION, () -> startPhase2(ran, ui));
        });
        phase1End.setRepeats(false);
        phase1End.start();
    }

    /**
     * 阶段二：粒子聚集演出 + 从上方砸下大波铁砂雨。
     * Phase 2: Particle gather visual + heavy iron sand rain from above.
     */
    private void startPhase2(Ran ran, UserInterface ui) {
        ui.combatPhase = 2;

        // 200个粒子从战斗框顶部飞向画面上方中心，制造聚集感
        // 200 particles fly from the top of the combat box toward the screen center above
        for (int i = 0; i < 200; i++) {
            float startX = (float) (Math.random() * 8f - 4f);
            float startY = 48f + (float) (Math.random() * 2f);
            CombatEffect fx = new CombatEffect(this, ran, startX, startY, false);
            float dx = 0 - startX;
            float dy = 60f - startY;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len > 0) fx.setVelocity(new Vec2(dx / len * 6f, dy / len * 6f));

            // 根据飞行距离计算停下时间，使粒子在中心汇聚
            // Stop each particle at a delay proportional to its travel distance
            float dist = len;
            int stopTime = (int) (dist / 6f * 7000);
            Timer stopTimer = managedTimer(stopTime, es -> {
                ((Timer) es.getSource()).stop();
                fx.setVelocity(new Vec2(0, 0));
            });
            stopTimer.setRepeats(false);
            stopTimer.start();
        }

        // 1秒后粒子微抖，然后一次性砸下30颗，再接连续雨
        // After 1s: particles jitter, then a burst of 30, then continuous rain
        Timer gatherTimer = managedTimer(1000, e -> {
            ((Timer) e.getSource()).stop();

            // 粒子原地微抖，暗示即将坠落 / particles jitter slightly before falling
            for (StaticBody b : getStaticBodies()) {
                if (b instanceof CombatEffect) {
                    ((CombatEffect) b).setVelocity(new Vec2(
                            (float) (Math.random() * 0.5f - 0.25f),
                            (float) (Math.random() * 0.3f - 0.15f)
                    ));
                }
            }

            Timer slamDelay = managedTimer(300, ed -> {
                ((Timer) ed.getSource()).stop();

                // 一次性冲击波：30颗从上方快速落下 / initial burst: 30 sand grains slam down
                for (int i = 0; i < 30; i++) {
                    float startX = (float) (Math.random() * 3 - 1.5f);
                    IronSand sand = new IronSand(this, ran, startX, 54f);
                    sand.setPosition(new Vec2(startX, 54f));
                    sand.setLinearVelocity(new Vec2((float) (Math.random() * 2 - 1), -14f));
                }

                // 0.5秒后切换为持续雨 / switch to continuous rain after 0.5s
                Timer rainDelay = managedTimer(500, er -> {
                    ((Timer) er.getSource()).stop();
                    sandTimer = managedTimer(200, ev -> {
                        for (int i = 0; i < 3; i++) {
                            float startX = (float) (Math.random() * 3 - 1.5f);
                            IronSand sand = new IronSand(this, ran, startX, 54f);
                            sand.setPosition(new Vec2(startX, 54f));
                            sand.setLinearVelocity(new Vec2((float) (Math.random() * 2 - 1), -12f));
                        }
                    });
                    sandTimer.start();
                });
                rainDelay.setRepeats(false);
                rainDelay.start();
            });
            slamDelay.setRepeats(false);
            slamDelay.start();

            Timer phase2End = managedTimer(PHASE2_DURATION, e2 -> {
                ((Timer) e2.getSource()).stop();
                sandTimer.stop();
                clearSand();
                ui.playCombatBlackout(BLACKOUT_DURATION, () -> startPhase3(ran, ui));
            });
            phase2End.setRepeats(false);
            phase2End.start();
        });
        gatherTimer.setRepeats(false);
        gatherTimer.start();
    }

    /**
     * 阶段三：混合高速铁砂（四面）+ 周期性从上方砸下列状攻击。
     * Phase 3: Fast sand from all directions + periodic column attacks from above.
     */
    private void startPhase3(Ran ran, UserInterface ui) {
        ui.combatPhase = 3;

        // 比阶段一更快的四面八方铁砂 / faster omnidirectional sand than phase 1
        sandTimer = managedTimer(180, e -> spawnSand(ran, 11f));
        sandTimer.start();

        // 每2秒从上方砸下一列8颗，制造额外压迫感
        // Every 2s, 8 grains drop straight down in a column for extra pressure
        Timer columnTimer = managedTimer(2000, e -> {
            for (int i = 0; i < 8; i++) {
                float startX = (float) (Math.random() * 2 - 1);
                IronSand sand = new IronSand(this, ran, startX, 55f);
                sand.setPosition(new Vec2(startX, 55f));
                sand.setLinearVelocity(new Vec2(0, -18f));
            }
        });
        columnTimer.start();

        Timer phase3End = managedTimer(PHASE3_DURATION, e -> {
            ((Timer) e.getSource()).stop();
            sandTimer.stop();
            columnTimer.stop();
            clearSand();
            clearAllEffects();

            // 战斗胜利：重置玩家状态，切回场景，播放战后对话
            // Combat won: reset player, return to scene, play post-combat dialogue
            sensor.setCombatActive(false);
            sensor.setCombatWon(true);
            ran.setGravityScale(1);
            ran.setCombatHitbox(false);
            ran.setPosition(new Vec2(6, -5f));
            ran.setLinearVelocity(new Vec2(0, 0));
            SoundManager.playBGM(getSceneBGM());
            sensor.resetDialogue();
            ui.playScript(Dialogue.XIE_TALK_AFTER);
        });
        phase3End.setRepeats(false);
        phase3End.start();
    }

    // ── 工具方法 / Utility methods ────────────────────────────────────────

    /**
     * 从四个方向之一生成铁砂，方向随机，速度可调。
     * Spawns iron sand from one of four directions at a given speed.
     *
     * @param ran   玩家引用（碰撞扣血）/ player reference (for damage)
     * @param speed 铁砂飞行速度 / projectile speed
     */
    private void spawnSand(Ran ran, float speed) {
        int direction = (int) (Math.random() * 4);
        float startX, startY, vx, vy;

        switch (direction) {
            case 0: // 从上往下 / top to bottom
                startX = (float) (Math.random() * 8 - 4);
                startY = 55f;
                vx = -startX * 0.5f; // 轻微内倾使弹道更有压迫感 / slight inward lean for pressure
                vy = -speed;
                break;
            case 1: // 从下往上 / bottom to top
                startX = (float) (Math.random() * 8 - 4);
                startY = 45f;
                vx = -startX * 0.5f;
                vy = speed;
                break;
            case 2: // 从左往右 / left to right
                startX = -4f;
                startY = (float) (Math.random() * 6 + 47f);
                vx = speed;
                vy = (50f - startY) * 0.5f; // 轻微朝中心收拢 / slight convergence toward center
                break;
            default: // 从右往左 / right to left
                startX = 4f;
                startY = (float) (Math.random() * 6 + 47f);
                vx = -speed;
                vy = (50f - startY) * 0.5f;
                break;
        }

        IronSand sand = new IronSand(this, ran, startX, startY);
        sand.setPosition(new Vec2(startX, startY));
        sand.setLinearVelocity(new Vec2(vx, vy));
    }

    /** 清除战斗框内所有铁砂 / Remove all iron sand projectiles from the combat box. */
    private void clearSand() {
        for (DynamicBody b : getDynamicBodies()) {
            if (b instanceof IronSand) b.destroy();
        }
    }

    /** 清除所有粒子特效 / Remove all CombatEffect particles. */
    private void clearAllEffects() {
        for (StaticBody b : getStaticBodies()) {
            if (b instanceof CombatEffect) b.destroy();
        }
    }

    // ── 接口实现 / Interface implementations ─────────────────────────────

    @Override public String[] getTalkScript()      { return Dialogue.XIE_TALK; }
    @Override public String[] getTalkAfterScript() { return Dialogue.XIE_TALK_AFTER; }
    @Override public String   getCombatBGM()       { return "data/xie.wav"; }
    @Override public String   getSceneBGM()        { return "data/xie.wav"; }
    @Override public String   getCombatImagePath() { return "data/xie.png"; }
    @Override public boolean  isIntroLevel()       { return true; } // Level1 独有开场独白 / only Level1 has opening monologue
    @Override public SasoriSensor getSensor()      { return sensor; }
}