import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * GameLevel — 所有关卡的抽象基类 / Abstract base class for all game levels.
 *
 * 继承自引擎的 World，提供玩家（Ran）、地面和通用生命周期方法。
 * Extends the engine's World class; provides the player (Ran), ground body,
 * and shared lifecycle utilities.
 *
 * 子类必须实现 populate()（放置场景元素）和 startCombat()（战斗逻辑）。
 * Subclasses must implement populate() (place scene elements) and startCombat() (combat logic).
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public abstract class GameLevel extends World {

    // 主角实例，在构造函数中创建 / player instance created in constructor
    private Ran ran;
    private final TimerRegistry timers = new TimerRegistry();

    protected javax.swing.Timer managedTimer(int delay, java.awt.event.ActionListener action) {
        return timers.create(delay, action);
    }
    public void pauseTimers() { timers.pause(); }
    public void resumeTimers() { timers.resume(); }

    // 由 addManagedStepListener 注册的监听器列表，用于关卡切换时统一清理
    // List of managed step listeners for clean removal on level transition
    private java.util.List<StepListener> stepListeners = new java.util.ArrayList<>();

    /**
     * 构造函数：创建玩家和透明地面。
     * Constructor: creates the player and the invisible ground platform.
     */
    public GameLevel() {
        // 创建主角并设置初始位置 / create player and set default spawn
        ran = new Ran(this);
        ran.setPosition(new Vec2(-12, -5.5f));

        // 宽阔的透明地面，防止玩家掉出世界 / wide transparent ground to prevent falling out
        Shape groundShape = new BoxShape(100, 0.5f);
        StaticBody ground = new StaticBody(this, groundShape);
        ground.setPosition(new Vec2(0, -8f));
        ground.setFillColor(new java.awt.Color(0, 0, 0, 0));
        ground.setLineColor(new java.awt.Color(0, 0, 0, 0));
    }

    // ── 抽象方法（子类必须实现）/ Abstract methods (must be implemented by subclasses) ──

    /** 放置背景、NPC、存档点等场景元素 / Place background, NPCs, save points, etc. */
    public abstract void populate();

    /** 战斗逻辑入口，由 Interaction 触发 / Combat logic entry point, triggered by Interaction. */
    public abstract void startCombat(Ran ran, UserInterface ui);

    /** 返回与NPC战斗前的对话脚本 / Returns the pre-combat dialogue script. */
    public abstract String[] getTalkScript();

    /** 返回战斗结束后的对话脚本 / Returns the post-combat dialogue script. */
    public abstract String[] getTalkAfterScript();

    /** 返回场景背景音乐路径 / Returns the scene background music path. */
    public abstract String getSceneBGM();

    /** 返回战斗阶段背景音乐路径 / Returns the combat background music path. */
    public abstract String getCombatBGM();

    /** 返回战斗立绘图片路径 / Returns the combat portrait image path. */
    public abstract String getCombatImagePath();

    /** 返回本关的NPC传感器 / Returns this level's NPC sensor. */
    public abstract NpcSensor getSensor();

    /**
     * 是否有开场独白（默认false）。
     * Whether this level has an opening monologue (default: false).
     * 目前只有 Level1 覆盖并返回 true。
     * Currently only Level1 overrides this to return true.
     */
    public boolean isIntroLevel() { return false; }

    // ── 工具方法 / Utility methods ────────────────────────────────────────

    /** 返回玩家引用 / Returns the player reference. */
    public Ran getRan() { return ran; }

    /**
     * 注册一个受管理的 StepListener，关卡切换时会自动移除。
     * Registers a managed StepListener that is automatically removed on level transition.
     *
     * @param listener 要注册的监听器 / listener to register
     */
    public void addManagedStepListener(StepListener listener) {
        stepListeners.add(listener);
        addStepListener(listener);
    }

    /**
     * 移除所有受管理的 StepListener，避免旧监听器在新关卡中残留。
     * Removes all managed StepListeners to prevent stale listeners leaking into new levels.
     */
    public void stopAllListeners() {
        timers.close();
        for (StepListener l : stepListeners) {
            removeStepListener(l);
        }
        stepListeners.clear();
    }
}