import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import javax.swing.Timer;

/**
 * Meteor — 佩恩关卡（Level 2）阶段一的陨石弹丸 / Meteor projectile in Pain's level (Level 2), phase 1.
 *
 * 从战斗框顶部生成，垂直向下飞，碰到玩家扣血后销毁。
 * Spawns at the top of the combat box, falls vertically, deals damage on contact then destroys.
 * 若2秒内未命中或飞出战斗框范围，自动销毁防止堆积。
 * Auto-destroys after 2s or when out of bounds to prevent accumulation.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Meteor extends DynamicBody {

    // 陨石贴图和碰撞体 / sprite and collision shape
    private static final BodyImage meteorImage = new BodyImage("data/yunshi.png", 4f);
    private static final Shape shape = new CircleShape(0.4f);

    // 边界检测定时器，需要持有引用以便在销毁时停止
    // Boundary check timer — held as a field so it can be stopped when the meteor is destroyed
    private Timer boundaryTimer;

    /**
     * @param world 所属物理世界 / physics world
     * @param ran   玩家引用，用于碰撞扣血 / player reference for damage
     * @param x     生成的X坐标（战斗框坐标系）/ spawn X in combat coordinate space
     */
    public Meteor(World world, Ran ran, float x) {
        super(world, shape);
        setGravityScale(0); // 无重力，手动控制速度 / no gravity, velocity is set manually
        setPosition(new Vec2(x, 53.5f)); // 从战斗框顶部生成 / spawn at the top of the combat box
        setLinearVelocity(new Vec2(0, -8f)); // 向下飞 / fly downward
        addImage(meteorImage);

        // 碰撞到玩家时扣血并销毁 / deal damage and destroy on contact with player
        addCollisionListener(new CollisionListener() {
            @Override
            public void collide(CollisionEvent e) {
                if (e.getOtherBody() == ran) {
                    ran.decrementHealth();
                    destroySafely(); // 停止所有计时器再销毁 / stop timers before destroying
                }
            }
        });

        // 2秒寿命定时器：超时未命中则销毁 / life timer: destroy if no hit within 2s
        Timer lifeTimer = new Timer(2000, e -> destroySafely());
        lifeTimer.setRepeats(false);
        lifeTimer.start();

        // 每16ms检查是否飞出战斗框边界 / check every 16ms if meteor has left combat box bounds
        boundaryTimer = new Timer(16, e -> {
            Vec2 pos = getPosition();
            if (pos.y < 46f || pos.y > 55f) {
                destroySafely(); // 超出边界立即销毁 / destroy immediately if out of bounds
            }
        });
        boundaryTimer.start();
    }

    /**
     * 停止所有关联计时器，再销毁物理体，防止计时器在已销毁的体上继续运行。
     * Stops all associated timers before destroying the body,
     * preventing timers from firing on an already-destroyed physics body.
     */
    private void destroySafely() {
        if (boundaryTimer != null) {
            boundaryTimer.stop(); // 先停计时器 / stop timer first
        }
        destroy(); // 再销毁体 / then destroy body
    }
}