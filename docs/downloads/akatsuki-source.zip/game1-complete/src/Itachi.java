import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Itachi — Level3 中的鼬静态NPC体 / Static NPC body for Itachi in Level 3.
 *
 * 使用 GhostlyFixture 使玩家可以穿过，仅作视觉展示。
 * Uses a GhostlyFixture so the player can walk through; purely decorative.
 * 实际交互通过附属的 ItachiSensor 传感器完成。
 * Actual interaction is handled by the attached ItachiSensor.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Itachi extends StaticBody {

    // 鼬立绘贴图 / Itachi character sprite
    private static final BodyImage itachiImage = new BodyImage("data/you.png", 8.5f);

    /**
     * @param world 所属物理世界 / physics world
     */
    public Itachi(World world) {
        super(world);
        new GhostlyFixture(this, new BoxShape(1, 6)); // 幽灵体，不阻挡玩家 / ghostly, player can pass through
        addImage(itachiImage);
    }
}