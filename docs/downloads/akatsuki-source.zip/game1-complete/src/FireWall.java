import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import javax.swing.Timer;

/**
 * FireWall — 可复用的火焰墙障碍物 / Reusable fire wall obstacle.
 *
 * 静态体，接触玩家时每秒扣一滴血，内置1秒冷却防止连续伤害。
 * Static body that deals one damage per second on contact with the player;
 * has a 1-second cooldown to prevent rapid repeated damage.
 * 尺寸和位置由调用方传入，可适配不同关卡布局。
 * Size and position are specified by the caller, making it adaptable to different level layouts.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class FireWall extends StaticBody {

    // 火焰动画贴图 / Animated fire GIF
    private static final BodyImage fireImage = new BodyImage("data/kaishishao.gif", 2f);

    // 防止同一碰撞重复扣血的冷却标志 / cooldown flag to prevent multiple damage from one collision
    private boolean hit = false;

    /**
     * @param world 所属物理世界 / physics world
     * @param ran   玩家角色引用 / player reference
     * @param x     中心X坐标 / center X position
     * @param y     中心Y坐标 / center Y position
     * @param w     半宽（BoxShape单位）/ half-width in BoxShape units
     * @param h     半高（BoxShape单位）/ half-height in BoxShape units
     */
    public FireWall(World world, Ran ran, float x, float y, float w, float h) {
        super(world, new BoxShape(w, h));
        setPosition(new Vec2(x, y));
        addImage(fireImage);

        addCollisionListener(new CollisionListener() {
            @Override
            public void collide(CollisionEvent e) {
                if (e.getOtherBody() == ran && !hit) {
                    hit = true;
                    ran.decrementHealth();
                    // 1秒冷却后可再次伤害 / allow damage again after 1 second cooldown
                    Timer cooldown = new Timer(1000, ce -> hit = false);
                    cooldown.setRepeats(false);
                    cooldown.start();
                }
            }
        });
    }
}