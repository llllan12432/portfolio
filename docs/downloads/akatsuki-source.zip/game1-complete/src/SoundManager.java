import javax.sound.sampled.*;
import java.io.File;
import java.util.HashMap;

/**
 * SoundManager — 音频管理的静态工具类 / Static utility class for all audio management.
 *
 * 音效（SFX）使用 javax.sound.sampled.Clip 加载 WAV 文件并缓存在 HashMap 中，
 * 支持随时播放而不需要重新读取磁盘。
 * Sound effects (SFX) use javax.sound.sampled.Clip to load WAV files and cache them in a HashMap,
 * allowing playback at any time without re-reading from disk.
 *
 * BGM 使用独立的 Clip 循环播放，并提供路径比对防止重复重启同一首曲目。
 * BGM uses a separate looping Clip; path comparison prevents restarting the same track.
 *
 * 音量范围 0.0f（静音）~ 1.0f（最大），内部转换为分贝值写入 MASTER_GAIN 控制器。
 * Volume range is 0.0f (mute) to 1.0f (max), converted internally to dB for MASTER_GAIN.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class SoundManager {

    // 音效缓存：名称 → Clip / SFX cache: name → Clip
    private static HashMap<String, Clip> clips = new HashMap<>();

    // BGM 相关状态 / BGM state
    private static Clip   bgmClip        = null;
    private static String currentBGMPath = "";

    // 默认音量 / default volumes
    private static float bgmVolume = 0.8f;
    private static float sfxVolume = 0.8f;

    // ── 初始化 / Initialisation ───────────────────────────────────────────

    /**
     * 预加载所有音效到内存，在游戏启动时调用一次。
     * Pre-loads all sound effects into memory; call once at game startup.
     * 加载完成后立即应用当前音效音量。
     * Applies the current SFX volume immediately after loading.
     */
    public static void loadAll() {
        loadClip("eat",       "data/eat.wav");
        loadClip("click",     "data/mc_click.wav");
        loadClip("run",       "data/run.wav");
        loadClip("start",     "data/ut_start.wav");
        loadClip("damage",    "data/ut_damage.wav");
        loadClip("save",      "data/ut_save.wav");
        loadClip("select",    "data/ut_select.wav");
        loadClip("jumpland",  "data/jumpland.wav");
        loadClip("death",     "data/ut_siwang.wav");
        // 加载完后统一应用当前音量设置 / apply current volume settings after loading
        setSfxVolume(sfxVolume);
    }

    /**
     * 加载单个音效 WAV 文件并缓存。
     * Loads a single WAV file and caches it.
     *
     * @param name 音效键名，用于 play() 调用 / key name used in play() calls
     * @param path 文件路径 / file path
     */
    private static void loadClip(String name, String path) {
        try {
            AudioInputStream ais = AudioSystem.getAudioInputStream(new File(path));
            Clip clip = AudioSystem.getClip();
            clip.open(ais);
            clips.put(name, clip);
        } catch (Exception e) {
            System.out.println("音效加载失败 / SFX load failed: " + name + " - " + e.getMessage());
        }
    }

    // ── 音效播放 / SFX playback ───────────────────────────────────────────

    /**
     * 从头播放指定音效（若正在播放则先停止重置）。
     * Plays the named sound effect from the start (stops and resets if already playing).
     *
     * @param name loadAll() 中注册的音效键名 / SFX key name registered in loadAll()
     */
    public static void play(String name) {
        Clip clip = clips.get(name);
        if (clip != null) {
            if (clip.isRunning()) clip.stop();
            clip.setFramePosition(0);
            clip.start();
        }
    }

    // ── BGM 播放 / BGM playback ───────────────────────────────────────────

    /**
     * 播放背景音乐；若指定路径与当前正在播放的相同则不重启，实现无缝延续。
     * Plays background music; if the path matches the currently playing track, does not restart
     * (enabling seamless continuation when the combat BGM equals the scene BGM).
     *
     * @param path WAV 文件路径 / WAV file path
     */
    public static void playBGM(String path) {
        if (path.equals(currentBGMPath) && bgmClip != null && bgmClip.isRunning()) {
            return; // 同一首曲目已在播放，不重启 / same track already playing, skip restart
        }
        stopBGM();
        currentBGMPath = path;
        try {
            AudioInputStream ais = AudioSystem.getAudioInputStream(new File(path));
            bgmClip = AudioSystem.getClip();
            bgmClip.open(ais);
            bgmClip.loop(Clip.LOOP_CONTINUOUSLY); // 无限循环 / loop indefinitely
            setBgmVolume(bgmVolume);               // 应用当前保存的音量 / apply saved volume
            bgmClip.start();
        } catch (Exception e) {
            System.out.println("BGM加载失败 / BGM load failed: " + e.getMessage());
        }
    }

    /** 停止并释放当前 BGM 资源 / Stops and releases the current BGM clip. */
    public static void stopBGM() {
        if (bgmClip != null && bgmClip.isRunning()) {
            bgmClip.stop();
            bgmClip.close();
        }
        currentBGMPath = ""; // 重置路径，防止后续 playBGM 误判为同一首 / reset path to avoid false match
    }

    // ── 音量控制 / Volume control ─────────────────────────────────────────

    /**
     * 设置 BGM 音量（0.0 ~ 1.0），实时生效。
     * Sets BGM volume (0.0 ~ 1.0), takes effect immediately.
     *
     * @param volume 新音量值 / new volume value
     */
    public static void setBgmVolume(float volume) {
        bgmVolume = volume;
        if (bgmClip != null) {
            applyVolume(bgmClip, volume);
        }
    }

    /**
     * 设置所有已加载音效的音量（0.0 ~ 1.0），实时生效。
     * Sets the volume of all loaded SFX clips (0.0 ~ 1.0), takes effect immediately.
     *
     * @param volume 新音量值 / new volume value
     */
    public static void setSfxVolume(float volume) {
        sfxVolume = volume;
        for (Clip clip : clips.values()) {
            applyVolume(clip, volume);
        }
    }

    /**
     * 将 0~1 的线性音量转换为分贝值并写入 Clip 的 MASTER_GAIN 控制器。
     * Converts a 0–1 linear volume to dB and writes it to the clip's MASTER_GAIN control.
     *
     * @param clip   目标 Clip / target clip
     * @param volume 线性音量（0.0 = 静音，1.0 = 最大）/ linear volume (0.0 = mute, 1.0 = max)
     */
    private static void applyVolume(Clip clip, float volume) {
        try {
            FloatControl fc = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
            float dB = (float) (Math.log10(Math.max(volume, 0.0001)) * 20); // 对数转换 / log conversion
            fc.setValue(Math.max(fc.getMinimum(), Math.min(dB, fc.getMaximum()))); // 钳位在合法范围内 / clamp to valid range
        } catch (Exception e) {
            System.out.println("音量设置失败 / Volume set failed: " + e.getMessage());
        }
    }

    // ── Getter / Setter ───────────────────────────────────────────────────

    public static float getBgmVolume() { return bgmVolume; }
    public static float getSfxVolume() { return sfxVolume; }
}