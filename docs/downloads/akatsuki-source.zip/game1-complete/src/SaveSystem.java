import java.io.*;

/**
 * SaveSystem — 存档读写的静态工具类 / Static utility class for saving and loading game state.
 *
 * 使用纯文本格式（CSV单行）持久化存档数据，简单易读便于调试。
 * Persists save data as a single CSV line in plain text — simple and easy to debug.
 *
 * 存档格式（逗号分隔）/ Save format (comma-separated):
 *   levelNum, health, combatWon, x, y
 *
 * 存档文件存放在项目根目录下的 save.txt。
 * The save file is stored as save.txt in the project root directory.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class SaveSystem {

    // 存档文件路径（项目根目录）/ save file path (project root)
    private static final String SAVE_FILE = "save.txt";

    /**
     * 将当前游戏状态写入存档文件，覆盖上次存档。
     * Writes the current game state to the save file, overwriting any previous save.
     *
     * @param levelNum  当前关卡编号 / current level number
     * @param health    当前血量 / current health
     * @param combatWon 战斗是否已胜利 / whether combat has been won
     * @param x         玩家X坐标 / player X position
     * @param y         玩家Y坐标 / player Y position
     */
    public static void save(int levelNum, int health, boolean combatWon, float x, float y) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(SAVE_FILE))) {
            // 写成逗号分隔的单行，与 load() 中的解析对应
            // Written as a comma-separated line; must match the parsing in load()
            writer.println(levelNum + "," + health + "," + combatWon + "," + x + "," + y);
            System.out.println("存档成功 / Save successful");
        } catch (IOException e) {
            System.out.println("存档失败 / Save failed: " + e.getMessage());
        }
    }

    /**
     * 从存档文件读取数据并返回 SaveData 对象；若无存档文件则返回 null。
     * Reads save data from the file and returns a SaveData object; returns null if no save exists.
     *
     * @return 存档数据，或 null（无存档时）/ save data, or null if no save file exists
     */
    public static SaveData load() {
        File file = new File(SAVE_FILE);
        if (!file.exists()) {
            System.out.println("没有存档 / No save file found");
            return null;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(SAVE_FILE))) {
            String line  = reader.readLine();
            if (line == null || line.isBlank()) return null;
            String[] parts = line.trim().split(",", -1);
            if (parts.length != 5) return null;
            for (int i = 0; i < parts.length; i++) parts[i] = parts[i].trim();
            if (!parts[2].equals("true") && !parts[2].equals("false")) return null;

            SaveData data    = new SaveData();
            data.levelNum    = Integer.parseInt(parts[0]);
            data.health      = Integer.parseInt(parts[1]);
            data.combatWon   = parts[2].equals("true"); // 直接解析布尔值 / parse boolean directly
            data.x           = Float.parseFloat(parts[3]);
            data.y           = Float.parseFloat(parts[4]);
            if (data.levelNum < 1 || data.levelNum > 3 || data.health < 1 || data.health > 5
                    || !Float.isFinite(data.x) || !Float.isFinite(data.y)) return null;
            return data;
        } catch (IOException | IllegalArgumentException e) {
            System.out.println("读档失败 / Load failed: " + e.getMessage());
            return null;
        }
    }

    /**
     * 检查存档文件是否存在（供主菜单判断是否启用"读取存档"按钮）。
     * Checks whether a save file exists (used by the main menu to enable/disable the load button).
     *
     * @return true = 存档存在 / save file exists
     */
    public static boolean hasSave() {
        return load() != null;
    }
}