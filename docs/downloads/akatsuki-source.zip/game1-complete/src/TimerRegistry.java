import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.Timer;

/** Owns level timers so a paused/disposed level cannot keep advancing combat. Use on the EDT. */
public final class TimerRegistry implements AutoCloseable {
    private final List<OwnedTimer> timers = new ArrayList<>();
    private boolean paused;
    private boolean closed;
    public Timer create(int delay, ActionListener action) {
        if (closed) throw new IllegalStateException("Level timers have been disposed");
        OwnedTimer timer = new OwnedTimer(delay, action);
        timers.add(timer);
        return timer;
    }
    public void pause() {
        if (paused || closed) return;
        paused = true;
        for (OwnedTimer timer : timers) timer.suspend();
    }
    public void resume() {
        if (!paused || closed) return;
        paused = false;
        for (OwnedTimer timer : timers) timer.restore();
    }
    public void close() {
        closed = true;
        for (OwnedTimer timer : timers) timer.stop();
        timers.clear();
    }
    private final class OwnedTimer extends Timer {
        private long due;
        private int remaining;
        private boolean waiting;
        OwnedTimer(int delay, ActionListener action) {
            super(delay, null);
            addActionListener(event -> {
                if (!closed && !paused) {
                    due = System.nanoTime() + getDelay() * 1_000_000L;
                    action.actionPerformed(event);
                }
            });
        }
        @Override public void start() {
            if (closed || isRunning() || waiting) return;
            remaining = getInitialDelay();
            due = System.nanoTime() + remaining * 1_000_000L;
            if (paused) waiting = true;
            else super.start();
        }
        @Override public void stop() { waiting = false; super.stop(); }
        void suspend() {
            if (!isRunning()) return;
            remaining = Math.max(1, (int)Math.ceil((due - System.nanoTime()) / 1_000_000.0));
            waiting = true;
            super.stop();
        }
        void restore() {
            if (!waiting) return;
            waiting = false;
            int initial = getInitialDelay();
            setInitialDelay(remaining);
            due = System.nanoTime() + remaining * 1_000_000L;
            super.start();
            setInitialDelay(initial);
        }
    }
}
