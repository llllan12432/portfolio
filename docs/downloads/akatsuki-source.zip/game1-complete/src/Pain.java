import org.jbox2d.common.Vec2;
import city.cs.engine.*;

/**
 * Pain — Level2 中的佩恩静态NPC体 / Static NPC body for Pain in Level 2.
 *
 * 使用 GhostlyFixture 使玩家可以穿过，仅作视觉展示。
 * Uses a GhostlyFixture so the player can walk through; purely decorative.
 * 实际交互通过附属的 PainSensor 传感器完成。
 * Actual interaction is handled by the attached PainSensor.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Pain extends StaticBody {

    // 佩恩立绘贴图 / Pain character sprite
    private static final BodyImage painImage = new BodyImage("data/pain.png", 8.5f);

    /**
     * @param world 所属物理世界 / physics world
     */
    public Pain(World world) {
        super(world);
        new GhostlyFixture(this, new BoxShape(1, 6)); // 幽灵体，玩家可穿过 / ghostly, player can pass through
        addImage(painImage);
    }
}