import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * Interaction — 玩家与NPC/食物/对话系统的键盘交互处理器。
 * Handles keyboard interactions for NPC dialogue, food pickup, and combat triggers.
 *
 * 只处理 Enter 键：推进对话、触发战斗、拾取食物。
 * Only handles the Enter key: advance dialogue, trigger combat, collect food.
 * 移动控制由 Ranrun 处理。
 * Movement controls are handled by Ranrun.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Interaction extends KeyAdapter {

    private NpcSensor sensor; // NPC传感器，检测玩家是否在范围内 / detects if player is near NPC
    private Ran ran;           // 玩家引用 / player reference
    private UserInterface ui;  // 视图引用，用于控制对话框显示 / view reference for dialogue control
    private GameLevel level;   // 当前关卡，用于访问脚本和食物 / current level for scripts and food

    /**
     * @param sensor NPC 传感器 / NPC proximity sensor
     * @param ran    玩家角色 / player character
     * @param ui     游戏视图 / game view
     * @param level  当前关卡 / current level
     */
    public Interaction(NpcSensor sensor, Ran ran, UserInterface ui, GameLevel level) {
        this.sensor = sensor;
        this.ran = ran;
        this.ui = ui;
        this.level = level;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();

        // ── 对话框开启时按 Enter 推进剧情 / Advance dialogue when box is open ──
        if (ui.showBox && !sensor.isCombatActive()) {
            if (code == KeyEvent.VK_ENTER) {
                if (ui.isTyping) {
                    // 打字机未打完：先跳到末尾，再按一次才翻页
                    // Typewriter still running: skip to end; next press will advance page
                    String fullText = ui.currentScript[ui.dialogueIndex];
                    String content = fullText.contains(":")
                            ? fullText.split(":", 2)[1] : fullText;
                    ui.typewriterIndex = content.length();
                    ui.isTyping = false;
                    ui.repaint();
                    return;
                }

                ui.dialogueIndex++;
                SoundManager.play("select"); // 翻页音效 / page-turn sound

                if (ui.dialogueIndex < ui.currentScript.length) {
                    // 还有台词：继续打字机 / more lines remain: continue typewriter
                    ui.startTypewriter();
                } else {
                    // 脚本播完：根据当前脚本类型决定下一步
                    // Script finished: decide next action based on which script just ended
                    if (ui.inStory()) {
                        // 开场独白结束，进入游戏 / opening monologue done, enter gameplay
                        ui.inStory = false;
                        ui.showBox = false;
                        ui.dialogueIndex = 0;
                    } else if (ui.currentScript == level.getTalkAfterScript()) {
                        // 战斗后对话结束，关闭对话框 / post-combat dialogue done, close box
                        ui.showBox = false;
                        ui.dialogueIndex = 0;
                        sensor.resetDialogue();
                    } else if (sensor.isShowDialogue()) {
                        // 战前对话结束，触发战斗 / pre-combat dialogue done, start combat
                        startCombat();
                    }
                }
            }
            return; // 对话框开启时拦截所有其他按键 / block all other keys while box is open
        }

        // ── 食物拾取：靠近时按 Enter 恢复满血 / Food pickup: press Enter when nearby ──
        if (!ui.showBox && code == KeyEvent.VK_ENTER && ui.nearFood) {
            for (StaticBody b : level.getStaticBodies()) {
                if (b instanceof Food) {
                    float dx = b.getPosition().x - ran.getPosition().x;
                    float dy = b.getPosition().y - ran.getPosition().y;
                    float dist = (float) Math.sqrt(dx * dx + dy * dy);
                    if (dist < 2.5f) {
                        if (ran.getHealth() < 5) {
                            ran.setHealth(5); // 恢复满血 / restore to full health
                            ui.showHealMessage();
                        }
                        b.destroy(); // 拾取后移除 / remove after pickup
                        SoundManager.play("eat");
                        ui.nearFood = false;
                        return;
                    }
                }
            }
        }

        // ── NPC 对话触发：靠近且未战胜时按 Enter 开始对话 / Trigger NPC dialogue ──
        if (!ui.showBox
                && sensor.isPlayerInside()
                && !sensor.isCombatWon()
                && code == KeyEvent.VK_ENTER) {
            ui.currentScript = level.getTalkScript();
            ui.dialogueIndex = 0;
            ui.showBox = true;
            ui.startTypewriter();
            sensor.toggleShowDialogue(); // 标记对话已开始 / mark dialogue as started
        }
    }

    /**
     * 正式开始战斗流程。
     * Begins the combat sequence.
     *
     * Level3 的 BGM 切换由其内部定时器控制，其他关卡战斗BGM与场景BGM相同，
     * playBGM 检测到同文件正在播就不重启，实现无缝衔接。
     * Level3 handles its own BGM internally. For Level1/2, combat and scene BGM are the same
     * file, so playBGM detects no change and continues seamlessly.
     */
    private void startCombat() {
        sensor.setCombatActive(true);
        ran.setPosition(new Vec2(0, 50));      // 传送到战斗框中心 / teleport to combat box
        ran.setLinearVelocity(new Vec2(0, 0));
        ran.setGravityScale(0);                // 战斗中无重力 / no gravity during combat
        ran.setCombatHitbox(true);             // 切换到小圆点碰撞体 / switch to small combat hitbox
        ui.showBox = false;

        SoundManager.play("start"); // 战斗开始音效 / battle start sound

        if (level instanceof Level3) {
            // Level3 需要先黑屏再切 BGM / Level3: blackout first, then switch BGM internally
            SoundManager.stopBGM();
            ui.playCombatBlackout(2000, () -> level.startCombat(ran, ui));
        } else {
            SoundManager.playBGM(level.getCombatBGM());
            level.startCombat(ran, ui);
        }
    }
}