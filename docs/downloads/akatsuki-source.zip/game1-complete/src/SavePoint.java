import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * SavePoint — 场景中的存档点 / Save point placed in the game scene.
 *
 * 玩家走入传感器范围后自动触发存档（重新进入时更新存档）。
 * Automatically saves the game when the player enters the sensor range (updates again on re-entry).
 * 触发后贴图从红色切换为蓝色，给玩家明确的视觉反馈。
 * Sprite switches from red to blue after activation for clear visual feedback.
 * 使用 Sensor 而非实体碰撞体，不阻挡玩家移动。
 * Uses a Sensor rather than a solid fixture, so it does not block movement.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class SavePoint extends StaticBody {

    // 未激活（红色）和已激活（蓝色）贴图 / inactive (red) and active (blue) sprites
    private static final BodyImage starImage          = new BodyImage("data/cundang.gif",  2f);
    private static final BodyImage starImageActivated = new BodyImage("data/cundang1.gif", 2f);

    private Sensor  sensor;             // 接近检测传感器 / proximity detection sensor
    private boolean activated = false;  // 是否显示激活贴图 / whether the activated sprite has been shown

    /**
     * @param world    所属物理世界 / physics world
     * @param ran      玩家引用，用于读取血量和位置 / player reference for health and position
     * @param levelNum 当前关卡编号，写入存档 / current level number written to save file
     */
    public SavePoint(World world, Ran ran, int levelNum) {
        super(world);
        new GhostlyFixture(this, new BoxShape(0.5f, 0.5f)); // 幽灵体，不阻挡玩家 / ghostly, doesn't block
        addImage(starImage); // 初始显示红色（未激活）/ initially red (inactive)

        // 比碰撞体略大的传感器，让玩家走近就能触发而不需要站在正上方
        // Sensor slightly larger than the body so it triggers on approach, not just exact overlap
        sensor = new Sensor(this, new BoxShape(1f, 1f));
        sensor.addSensorListener(new SensorListener() {
            @Override
            public void beginContact(SensorEvent e) {
                if (e.getContactBody() instanceof Ran && ran.getHealth() > 0) {
                    activated = true;

                    // 切换为已激活贴图（蓝色）/ switch to activated sprite (blue)
                    removeAllImages();
                    addImage(starImageActivated);

                    // 执行存档：写入关卡号、血量、战斗状态和当前坐标
                    // Save: write level number, health, combat state, and current position
                    SaveSystem.save(levelNum, ran.getHealth(),
                            world instanceof GameLevel && ((GameLevel) world).getSensor().isCombatWon(),
                            ran.getPosition().x, ran.getPosition().y);

                    SoundManager.play("save");    // 存档音效 / save sound
                    ran.notifySaved();             // 通知UI显示存档提示 / notify UI to show save message
                }
            }

            @Override
            public void endContact(SensorEvent e) {} // 离开范围时无操作 / no action on exit
        });
    }

    /** 存档点是否已被激活 / Whether this save point has been activated. */
    public boolean isActivated() { return activated; }

    /** 重置激活状态（供关卡重载使用）/ Reset activation state (for level reload). */
    public void reset() { activated = false; }
}