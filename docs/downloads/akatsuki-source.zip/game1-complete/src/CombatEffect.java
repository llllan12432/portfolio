import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import javax.swing.Timer;

/**
 *
 * CombatEffect — 战斗粒子特效 / Visual particle effect used during combat.
 * 继承StaticBody但通过Timer模拟移动，用于蝎战斗阶段的聚集/扩散演出。
 * Extends StaticBody and simulates movement via Timer, used in Sasori's combat phases.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class CombatEffect extends StaticBody {
    private Vec2 velocity;   // 当前移动速度 / current movement velocity
    private Timer moveTimer; // 每帧更新位置的计时器 / timer that updates position each frame

    /**
     * @param startX    初始X坐标 / initial X position
     * @param startY    初始Y坐标 / initial Y position
     * @param isDamaging 是否造成伤害（当前未使用，留作扩展）/ whether this deals damage (unused, reserved)
     */
    public CombatEffect(World world, Ran ran, float startX, float startY, boolean isDamaging) {
        super(world);
        // GhostlyFixture让粒子不参与物理碰撞 / ghostly fixture prevents physical collision
        new GhostlyFixture(this, new CircleShape(0.2f));
        setPosition(new Vec2(startX, startY));

        // StaticBody没有物理速度，用Timer手动移动位置
        // StaticBody has no physics velocity, so we manually update position via Timer
        this.velocity = new Vec2(0, 0);

        // 每16ms更新一次位置（约60fps）/ update position every 16ms (~60fps)
        moveTimer = new Timer(16, e -> {
            Vec2 pos = getPosition();
            setPosition(new Vec2(pos.x + velocity.x * 0.016f,
                    pos.y + velocity.y * 0.016f));
        });
        moveTimer.start();

        // 30秒后自动清除，防止堆积 / auto-destroy after 30s to prevent accumulation
        Timer lifeTimer = new Timer(30000, e -> {
            moveTimer.stop();
            destroy();
        });
        lifeTimer.setRepeats(false);
        lifeTimer.start();
    }

    // 设置粒子移动方向和速度 / set the movement direction and speed
    public void setVelocity(Vec2 v) {
        this.velocity = v;
    }
}