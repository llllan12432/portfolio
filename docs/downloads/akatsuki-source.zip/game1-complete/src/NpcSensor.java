import org.jbox2d.common.Vec2;
import city.cs.engine.*;

/**
 * NpcSensor — 所有NPC接近传感器的抽象基类 / Abstract base class for all NPC proximity sensors.
 *
 * 使用物理引擎的 Sensor 检测玩家进出范围，管理对话和战斗的状态标志。
 * Uses the physics engine's Sensor to detect when the player enters/exits range,
 * and manages state flags for dialogue and combat.
 *
 * 子类（SasoriSensor / PainSensor / ItachiSensor）只需传入对应的NPC体和传感器尺寸。
 * Subclasses (SasoriSensor / PainSensor / ItachiSensor) only need to pass in the NPC body and sensor size.
 *
 * blueMode 和 fireActive 是 Level3 独有的战斗状态，放在基类中是为了让
 * UserInterface 和 Ranrun 通过统一的 NpcSensor 接口访问，避免强制类型转换。
 * blueMode and fireActive are Level3-specific combat states kept here so that
 * UserInterface and Ranrun can access them through the common NpcSensor interface
 * without needing to cast to ItachiSensor.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class NpcSensor extends Sensor {

    // ── 通用状态标志 / Common state flags ─────────────────────────────────

    protected boolean playerInside   = false; // 玩家是否在传感器范围内 / whether player is in sensor range
    protected boolean showDialogue   = false; // 是否正在展示对话框 / whether dialogue box is active
    protected boolean isCombatActive = false; // 是否在战斗中 / whether combat is active
    protected boolean combatWon      = false; // 战斗是否已胜利 / whether combat has been won
    private   boolean hasTalked      = false; // NPC是否已经和玩家对话过 / whether NPC has talked to player

    // ── Level3 专用状态（统一接口，避免类型转换）/ Level3-specific states (unified interface) ──

    private boolean blueMode   = false; // 蓝魂模式：玩家变为蓝心并受重力影响 / blue-soul mode (gravity physics)
    private boolean fireActive = false; // 火焰边框激活：靠近边缘会受伤 / fire border active (edge damage)

    /**
     * @param npc   传感器附属的NPC静态体 / static NPC body this sensor is attached to
     * @param shape 传感器检测范围的形状 / sensor detection area shape
     */
    public NpcSensor(StaticBody npc, Shape shape) {
        super(npc, shape);
        addSensorListener(new SensorListener() {
            @Override
            public void beginContact(SensorEvent e) {
                // Walker 是玩家（Ran）的父类 / Walker is the parent class of Ran (the player)
                if (e.getContactBody() instanceof Walker) {
                    playerInside = true;
                }
            }
            @Override
            public void endContact(SensorEvent e) {
                if (e.getContactBody() instanceof Walker) {
                    playerInside  = false;
                    showDialogue  = false; // 离开范围时关闭对话 / close dialogue when player leaves
                }
            }
        });
    }

    // ── Getter / Setter ───────────────────────────────────────────────────

    /** 玩家是否在传感器范围内 / Whether the player is within sensor range. */
    public boolean isPlayerInside()   { return playerInside; }

    /** 是否正在显示对话框 / Whether the dialogue box is currently shown. */
    public boolean isShowDialogue()   { return showDialogue; }

    /** 开启对话标记（按Enter触发对话时调用）/ Mark dialogue as started (called on Enter). */
    public void toggleShowDialogue()  { showDialogue = true; }

    /** 重置对话标记（对话结束后调用）/ Reset dialogue flag (called after dialogue ends). */
    public void resetDialogue()       { showDialogue = false; }

    /** 是否在战斗中 / Whether combat is currently active. */
    public boolean isCombatActive()   { return isCombatActive; }
    public void setCombatActive(boolean b) { isCombatActive = b; }

    /** 战斗是否已胜利 / Whether combat has been won. */
    public boolean isCombatWon()      { return combatWon; }
    public void setCombatWon(boolean b)    { combatWon = b; }

    /** NPC是否已经对话过（用于防止重复触发）/ Whether NPC has already talked (prevents re-trigger). */
    public boolean hasTalked()        { return hasTalked; }
    public void setHasTalked(boolean b)    { hasTalked = b; }

    /** 蓝魂模式开关（Level3阶段二专用）/ Blue-soul mode toggle (Level3 phase 2). */
    public boolean isBlueMode()       { return blueMode; }
    public void setBlueMode(boolean b)     { blueMode = b; }

    /** 火焰边框伤害开关（Level3阶段三专用）/ Fire border damage toggle (Level3 phase 3). */
    public boolean isFireActive()     { return fireActive; }
    public void setFireActive(boolean b)   { fireActive = b; }
}