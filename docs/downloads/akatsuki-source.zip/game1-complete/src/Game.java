import org.jbox2d.common.Vec2;
import javax.swing.*;
import city.cs.engine.*;

/**
 * Game — 应用程序入口点 / Application entry point.
 *
 * 负责创建主窗口（JFrame）并将控制权交给 GameController。
 * Responsible for creating the main window (JFrame) and handing control to GameController.
 * 所有游戏状态、关卡切换、UI 管理均由 GameController 负责。
 * All game state, level transitions, and UI management are handled by GameController.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Game {

    /**
     * 初始化窗口并启动游戏控制器。
     * Initialises the window and starts the game controller.
     */
    public Game() {
        JFrame frame = new JFrame("Akatsuki");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        // GameController 接管窗口内容并显示主菜单
        // GameController takes ownership of the frame content and shows the main menu
        new GameController(frame);
    }

    /** 程序主入口 / Main entry point. */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Game::new);
    }
}