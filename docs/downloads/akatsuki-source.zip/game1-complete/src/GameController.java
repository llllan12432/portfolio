import org.jbox2d.common.Vec2;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import city.cs.engine.*;
import java.awt.Color;

/**
 * GameController — 游戏总控制器 / Central game controller.
 *
 * 管理关卡加载、主菜单、暂停菜单、死亡流程和结局演出。
 * Manages level loading, main menu, pause menu, death sequence, and ending cutscene.
 * 持有当前关卡、视图和玩家的引用，是各系统之间的协调中心。
 * Holds references to the current level, view, and player — acts as the coordinator between systems.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class GameController {

    private JFrame frame;
    private UserInterface view;
    private GameLevel currentLevel;
    private int currentLevelNum = 1;
    private Ran currentRan;

    // 死亡流程是否已处理（防止多次触发）/ ensures death sequence runs only once
    private boolean deathHandled = false;

    // 暂停状态标志 / whether the game is currently paused
    private boolean isPaused = false;

    // 结局场景的重绘计时器 / repaint timer used during the ending cutscene
    private Timer endingRenderTimer;

    /**
     * @param frame 主窗口，GameController 全程管理其内容 / main window managed by this controller
     */
    public GameController(JFrame frame) {
        this.frame = frame;
        SoundManager.loadAll(); // 预加载所有音效 / pre-load all sound effects
        showMainMenu();
    }

    // ── 死亡处理 / Death handling ─────────────────────────────────────────

    /**
     * 处理玩家死亡：播放心碎动画，然后显示 Game Over 或结局。
     * Handles player death: plays the heart-break animation, then shows Game Over or ending.
     *
     * @param world    当前关卡 / current level
     * @param levelNum 当前关卡编号 / current level number
     */
    private void handleDeath(GameLevel world, int levelNum) {
        currentRan.removeAllImages();
        if (deathHandled) return; // 防止重复触发 / prevent double-trigger
        deathHandled = true;
        currentLevel.stop();
        currentLevel.stopAllListeners();
        SoundManager.play("death");

        if (currentRan.isForceDeath()) {
            // 必死走结局，不显示 Game Over / forced death leads to ending, skip Game Over
            showEnding();
            return;
        }

        // 普通死亡：心碎动画 → Game Over 渐入
        // Normal death: heart-break animation → Game Over fade-in
        view.showHeartBreak = true;
        Timer heartGrow = new Timer(16, eh -> {
            view.heartBreakSize += 3;
            if (view.heartBreakSize > 80) {
                ((Timer) eh.getSource()).stop();
                Timer heartFade = new Timer(16, ef -> {
                    view.heartBreakAlpha -= 8;
                    if (view.heartBreakAlpha <= 0) {
                        ((Timer) ef.getSource()).stop();
                        view.showHeartBreak = false;
                        view.isGameOver = true;
                        SoundManager.playBGM("data/siwangbgm.wav");
                        startGameOverFade();
                    }
                });
                heartFade.start();
            }
        });
        heartGrow.start();
    }

    /**
     * 启动 GAME OVER 文字和副标题的渐入动画。
     * Starts the fade-in animation for the GAME OVER text and subtitle.
     */
    private void startGameOverFade() {
        Timer fadeTimer = new Timer(16, ef -> {
            view.gameOverAlpha += 5;
            if (view.gameOverAlpha >= 255) {
                ((Timer) ef.getSource()).stop();
                Timer subtitleDelay = new Timer(1500, es -> {
                    Timer subtitleFade = new Timer(16, esf -> {
                        view.subtitleAlpha += 3;
                        if (view.subtitleAlpha >= 255) {
                            ((Timer) esf.getSource()).stop();
                        }
                    });
                    subtitleFade.start();
                });
                subtitleDelay.setRepeats(false);
                subtitleDelay.start();
            }
        });
        fadeTimer.start();
    }

    // ── 菜单导航 / Menu navigation ────────────────────────────────────────

    /**
     * 返回主菜单：停止当前关卡、切换背景音乐、替换窗口内容。
     * Returns to the main menu: stops the current level, switches BGM, replaces window content.
     */
    public void showMainMenu() {
        isPaused = false;
        frame.getContentPane().removeAll();

        // 停止当前关卡和结局重绘计时器 / stop current level and ending repaint timer
        if (endingRenderTimer != null) {
            endingRenderTimer.stop();
            endingRenderTimer = null;
        }
        if (currentLevel != null) {
            currentLevel.stop();
            currentLevel.stopAllListeners();
            frame.remove(view);
        }

        SoundManager.playBGM("data/xie.wav");

        MainMenu menu = new MainMenu(this);
        frame.add(menu);
        frame.pack();
        frame.revalidate();
        frame.repaint();
    }

    /** 新游戏：从第一关满血开始 / New game: start level 1 with full health. */
    public void startGame() {
        frame.getContentPane().removeAll();
        SoundManager.play("click");
        loadLevel(1, 5); // 满血开始 / start with full health
    }

    /** 读档：从存档文件加载关卡、血量和位置 / Load game from save file. */
    public void loadGame() {
        SoundManager.loadAll();
        SoundManager.play("click");

        SaveData save = SaveSystem.load();
        if (save == null) return;

        frame.getContentPane().removeAll();
        loadLevel(save.levelNum, save.health, save.x, save.y);
        currentLevel.getSensor().setCombatWon(save.combatWon);
    }

    // ── 关卡加载重载 / Level loading overloads ───────────────────────────

    /**
     * 过关时调用：继承当前血量，玩家从关卡默认位置出生。
     * Called on level clear: carries over current health; player spawns at default position.
     *
     * @param levelNum 目标关卡编号 / target level number
     */
    public void loadLevel(int levelNum) {
        int currentHealth = (currentLevel != null) ? currentLevel.getRan().getHealth() : 5;
        loadLevel(levelNum, currentHealth, -12f, -5.5f);
    }

    /**
     * 新游戏时调用：指定血量，玩家从关卡默认位置出生。
     * Called for new game: specified health; player spawns at default position.
     *
     * @param levelNum 目标关卡编号 / target level number
     * @param health   初始血量 / initial health
     */
    public void loadLevel(int levelNum, int health) {
        loadLevel(levelNum, health, -12f, -5.5f);
    }

    /**
     * 完整版关卡加载：指定关卡、血量和出生坐标（读档时使用）。
     * Full load: specifies level, health, and spawn position (used when loading from save).
     *
     * @param levelNum 目标关卡编号 / target level number
     * @param health   初始血量 / initial health
     * @param x        出生X坐标 / spawn X position
     * @param y        出生Y坐标 / spawn Y position
     */
    public void loadLevel(int levelNum, int health, float x, float y) {
        this.currentLevelNum = levelNum;
        deathHandled = false;

        // 清理上一关 / clean up previous level
        if (currentLevel != null) {
            currentLevel.stop();
            currentLevel.stopAllListeners();
            frame.remove(view);
        }

        // 用工厂列表动态选择关卡，超出范围则通关回主菜单
        // Use factory list to pick the level; if out of range, game is complete → main menu
        java.util.List<java.util.function.Supplier<GameLevel>> levelFactories = new java.util.ArrayList<>();
        levelFactories.add(() -> new Level1());
        levelFactories.add(() -> new Level2());
        levelFactories.add(() -> new Level3());

        if (levelNum > levelFactories.size()) {
            showMainMenu();
            return;
        }

        // 创建关卡并设置主角 / create level and configure player
        GameLevel world = levelFactories.get(levelNum - 1).get();
        world.populate();

        Ran ran = world.getRan();
        ran.setHealth(health);
        ran.setPosition(new Vec2(x, y));
        currentRan = ran;
        currentRan.setForceDeath(false);

        // Level3 死亡强制走结局 / Level 3 death always leads to ending
        if (levelNum == 3) {
            ran.setDeathListener(() -> {
                ran.setForceDeath(true);
                handleDeath(world, levelNum);
                ran.setHealth(0);
            });
        } else {
            ran.setDeathListener(() -> handleDeath(world, levelNum));
        }

        // 注册 UI 回调 / register UI callbacks
        ran.setSaveListener(() -> view.showSaveMessage());
        ran.setDamageListener(() -> view.showDamageFlash());

        SoundManager.playBGM(world.getSceneBGM());

        // 创建并配置视图 / create and configure the view
        NpcSensor sensor = world.getSensor();
        view = new UserInterface(world, ran, sensor, 800, 600);
        view.setZoom(30);

        // 只有 Level1 有开场独白，其他关卡直接跳过剧情
        // Only Level 1 has an opening monologue; other levels skip it
        if (!world.isIntroLevel()) {
            view.inStory = false;
            view.showBox = false;
        }

        view.combatImage = new ImageIcon(world.getCombatImagePath()).getImage();
        view.addKeyListener(new Interaction(sensor, ran, view, world));
        view.addKeyListener(new Ranrun(ran, sensor, view, this, world));

        setupCamera(world, ran, sensor, view);
        currentLevel = world;
        world.start();

        // 显示窗口 / display window
        view.setFocusable(true);
        frame.add(view);
        frame.pack();
        frame.revalidate();
        frame.repaint();
        view.requestFocus();
        view.currentLevelNum = levelNum;
    }

    /** 返回当前关卡编号 / Returns the current level number. */
    public int getCurrentLevelNum() { return currentLevelNum; }

    // ── 摄像机 / Camera ───────────────────────────────────────────────────

    /**
     * 设置跟随摄像机：探索时跟随玩家，战斗时固定在战斗框中心。
     * Sets up the follow camera: tracks the player during exploration,
     * locks to the combat box center during combat.
     */
    private void setupCamera(GameLevel world, Ran ran, NpcSensor sensor, UserInterface view) {
        world.addManagedStepListener(new StepListener() {
            @Override
            public void preStep(StepEvent e) {}

            @Override
            public void postStep(StepEvent e) {
                if (!sensor.isCombatActive()) {
                    // 探索模式：摄像机跟随玩家，限制在地图边界内
                    // Exploration: camera follows the player, clamped to map bounds
                    Vec2 target = ran.getPosition();
                    float camX = Math.max(-4f, Math.min(4f, target.x));
                    float camY = 0f; // Y轴固定，视角往上抬 / Y is fixed with slight upward offset
                    view.setCentre(new Vec2(camX, camY));
                } else {
                    // 战斗模式：摄像机固定在战斗框中心 / combat: fixed at combat box center
                    view.setCentre(new Vec2(0, 50));
                }
            }
        });
    }

    // ── 结局演出 / Ending cutscene ────────────────────────────────────────

    /**
     * 触发游戏结局：停止BGM，启动结局渲染循环，开始播放独白。
     * Triggers the game ending: stops BGM, starts the render loop, begins narration.
     */
    private void showEnding() {
        SoundManager.stopBGM();
        view.isEnding = true;
        view.blinkAlpha = 255;

        // 结局期间持续重绘 / continuously repaint during the ending
        endingRenderTimer = new Timer(16, e -> view.repaint());
        endingRenderTimer.start();

        view.startEnding(Dialogue.ENDING);

        // 独白第一阶段播完后触发眨眼演出 / trigger blink sequence after first narration phase
        view.onEndingPhaseComplete = () -> startBlinking();
    }

    /**
     * 眨眼演出：睁眼 → 停顿 → 闭眼 → 再睁眼，完成后继续剩余对话。
     * Blink sequence: open eye → pause → close eye → reopen, then resume dialogue.
     */
    private void startBlinking() {
        Timer openEye = new Timer(16, eo -> {
            view.blinkAlpha -= 2;
            if (view.blinkAlpha <= 0) {
                view.blinkAlpha = 0;
                ((Timer) eo.getSource()).stop();
                Timer pause = new Timer(1000, ep -> {
                    ((Timer) ep.getSource()).stop();
                    Timer closeEye = new Timer(16, ec -> {
                        view.blinkAlpha += 4;
                        if (view.blinkAlpha >= 200) {
                            ((Timer) ec.getSource()).stop();
                            Timer openEye2 = new Timer(16, eo2 -> {
                                view.blinkAlpha -= 4;
                                if (view.blinkAlpha <= 0) {
                                    view.blinkAlpha = 0;
                                    ((Timer) eo2.getSource()).stop();
                                    view.blinkingDone = true;
                                    view.resumeEnding(); // 眨眼结束，继续对话 / blink done, resume dialogue
                                }
                            });
                            openEye2.start();
                        }
                    });
                    closeEye.start();
                });
                pause.setRepeats(false);
                pause.start();
            }
        });
        openEye.start();
    }

    // ── 暂停菜单 / Pause menu ─────────────────────────────────────────────

    /**
     * 显示暂停菜单（Modal Dialog）：关卡停止，关闭后自动恢复。
     * Shows the pause menu as a modal dialog; level stops and resumes when dialog closes.
     */
    public void showPauseMenu() {
        if (isPaused) return;
        isPaused = true;
        GameLevel pausedLevel = currentLevel;
        pausedLevel.stop();
        pausedLevel.pauseTimers();

        JDialog pauseDialog = new JDialog(frame, true); // modal = 自动拦截输入 / modal blocks input
        pauseDialog.setUndecorated(true);
        pauseDialog.setBackground(new Color(0, 0, 0, 0));

        PauseMenu pauseMenu = new PauseMenu(this, true, pauseDialog);
        pauseDialog.add(pauseMenu);
        pauseDialog.pack();
        pauseDialog.setLocationRelativeTo(frame);
        pauseDialog.setVisible(true); // 阻塞直到 dialog 关闭 / blocks until dialog is closed

        // dialog 关闭后自动恢复 / automatically resumes after dialog closes
        isPaused = false;
        if (currentLevel == pausedLevel && !deathHandled) {
            pausedLevel.resumeTimers();
            pausedLevel.start();
            view.requestFocus();
        }
    }

    /**
     * 显示设置界面（从主菜单进入）。
     * Shows the settings screen (accessible from the main menu).
     */
    public void showSettings() {
        frame.getContentPane().removeAll();
        PauseMenu settings = new PauseMenu(this, false, null);
        frame.add(settings);
        frame.revalidate();
        frame.repaint();
    }
}