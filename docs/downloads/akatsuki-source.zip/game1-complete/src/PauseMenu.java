import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * PauseMenu — 暂停菜单面板，同时用作设置页面 / Pause menu panel; also used as the settings screen.
 *
 * 通过 isInGame 标志区分两种使用场景：
 * Behaviour differs based on the isInGame flag:
 *   isInGame = true  → 游戏内 ESC 调出，显示"继续游戏"和"主菜单"按钮
 *                      In-game ESC: shows "Resume" and "Main Menu" buttons
 *   isInGame = false → 主菜单设置页，只显示"返回主菜单"按钮
 *                      Settings from main menu: shows only "Return to Main Menu"
 *
 * 音量滑块直接读写 SoundManager 的静态字段，实时生效。
 * Volume sliders read/write SoundManager's static fields and take effect immediately.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class PauseMenu extends JPanel {

    private GameController controller; // 控制器引用，用于导航 / controller reference for navigation
    private boolean isInGame;          // 区分游戏内暂停和主菜单设置 / distinguishes in-game pause from settings

    /**
     * @param controller 游戏总控制器 / central game controller
     * @param isInGame   是否在游戏内（true=ESC暂停，false=主菜单设置）/ true if in-game pause
     * @param dialog     若从游戏内打开则传入对话框引用以便关闭，否则传 null
     *                   Pass the parent JDialog to close on resume, or null from the main menu
     */
    public PauseMenu(GameController controller, boolean isInGame, JDialog dialog) {
        this.controller = controller;
        this.isInGame = isInGame;
        setPreferredSize(new Dimension(800, 600));
        setBackground(new Color(0, 0, 0, 180));
        setLayout(null);

        // 标题：游戏暂停 / 设置 / Title: "Game Paused" or "Settings"
        JLabel title = new JLabel(isInGame ? "Paused" : "Settings");
        title.setFont(new Font("Verdana", Font.BOLD, 36));
        title.setForeground(Color.WHITE);
        title.setBounds(330, 100, 200, 50);
        add(title);

        // BGM 音量滑块 / BGM volume slider
        JLabel bgmLabel = new JLabel("BGM Volume");
        bgmLabel.setFont(new Font("Verdana", Font.PLAIN, 18));
        bgmLabel.setForeground(Color.WHITE);
        bgmLabel.setBounds(200, 200, 120, 30);
        add(bgmLabel);

        JSlider bgmSlider = new JSlider(0, 100, (int) (SoundManager.getBgmVolume() * 100));
        bgmSlider.setBounds(330, 200, 250, 40);
        bgmSlider.addChangeListener(e -> SoundManager.setBgmVolume(bgmSlider.getValue() / 100f));
        add(bgmSlider);

        // 音效音量滑块 / SFX volume slider
        JLabel sfxLabel = new JLabel("SFX Volume");
        sfxLabel.setFont(new Font("Verdana", Font.PLAIN, 18));
        sfxLabel.setForeground(Color.WHITE);
        sfxLabel.setBounds(200, 270, 120, 30);
        add(sfxLabel);

        JSlider sfxSlider = new JSlider(0, 100, (int) (SoundManager.getSfxVolume() * 100));
        sfxSlider.setBounds(330, 270, 250, 40);
        sfxSlider.addChangeListener(e -> SoundManager.setSfxVolume(sfxSlider.getValue() / 100f));
        add(sfxSlider);

        // 主按钮：继续游戏 / 返回主菜单 / Primary button: Resume / Return to Main Menu
        JButton backBtn = createButton(isInGame ? "Resume" : "Back to Menu");
        backBtn.setBounds(300, 380, 200, 45);
        backBtn.addActionListener(e -> {
            if (dialog != null) {
                dialog.dispose(); // 关闭 Modal Dialog，游戏自动恢复 / close modal dialog, game resumes
            } else {
                controller.showMainMenu();
            }
        });
        add(backBtn);

        // 游戏内暂停时额外显示"主菜单"按钮 / In-game pause also shows a "Main Menu" button
        if (isInGame) {
            JButton menuBtn = createButton("Main Menu");
            menuBtn.setBounds(300, 440, 200, 45);
            menuBtn.addActionListener(e -> {
                if (dialog != null) dialog.dispose();
                controller.showMainMenu();
            });
            add(menuBtn);
        }
    }

    /**
     * 创建统一样式的菜单按钮（悬停变金色）。
     * Creates a consistently styled menu button (gold text on hover).
     *
     * @param text 按钮文字 / button label
     * @return 配置好的 JButton / configured JButton
     */
    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Verdana", Font.BOLD, 16));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(40, 40, 40));
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setForeground(new Color(255, 215, 0)); }
            public void mouseExited(MouseEvent e)  { btn.setForeground(Color.WHITE); }
        });
        return btn;
    }

    @Override
    protected void paintComponent(Graphics g) {
        // 半透明黑色背景遮罩 / semi-transparent black overlay
        g.setColor(new Color(0, 0, 0, 180));
        g.fillRect(0, 0, 800, 600);
    }
}