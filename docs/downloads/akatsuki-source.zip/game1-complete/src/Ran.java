import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import javax.swing.Timer;

/**
 * Ran — 玩家角色 / Player character.
 *
 * 继承引擎的 Walker，管理移动、跳跃、冲刺、血量、碰撞体切换和各类回调接口。
 * Extends the engine's Walker; manages movement, jumping, dashing, health,
 * hitbox switching, and callback interfaces.
 *
 * 使用三个内部接口（DeathListener / SaveListener / DamageListener）
 * 将游戏事件通知给 GameController 和 UserInterface，保持解耦。
 * Three inner interfaces (DeathListener / SaveListener / DamageListener) notify
 * GameController and UserInterface of game events, keeping classes decoupled.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Ran extends Walker {

    // ── 贴图 / Sprites ────────────────────────────────────────────────────
    public static final BodyImage jingzhi   = new BodyImage("data/zhanli.png",     8f); // 站立 / idle
    public static final BodyImage runRight  = new BodyImage("data/111youpao.gif",  8f); // 向右跑 / run right
    public static final BodyImage runLeft   = new BodyImage("data/111zuopao.gif",  8f); // 向左跑 / run left
    public static final BodyImage jumpRight = new BodyImage("data/11youtiao.png",  8f); // 向右跳 / jump right
    public static final BodyImage jumpLeft  = new BodyImage("data/11zuotiao.png",  8f); // 向左跳 / jump left
    public static final BodyImage fallRight = new BodyImage("data/youluo.png",     8f); // 向右下落 / fall right
    public static final BodyImage fallLeft  = new BodyImage("data/zuoluo.png",     8f); // 向左下落 / fall left
    public static final BodyImage dashRight = new BodyImage("data/youchong.png",   8f); // 向右冲刺 / dash right
    public static final BodyImage dashLeft  = new BodyImage("data/zuochong.png",   8f); // 向左冲刺 / dash left

    // ── 血量 / Health ─────────────────────────────────────────────────────
    private int health = 5; // 初始血量5，最大也是5 / initial and max health is 5

    // ── 碰撞体 / Hitboxes ─────────────────────────────────────────────────
    private Fixture currentFixture;
    private final Shape walkShape   = new BoxShape(1, 2);      // 探索模式：大方块 / exploration: large box
    private final Shape combatShape = new CircleShape(0.2f);   // 战斗模式：小圆点，更难被击中 / combat: small circle, harder to hit

    // ── 食物检测 / Food detection ─────────────────────────────────────────
    private Food nearbyFood = null; // 碰撞检测到的附近食物 / nearby food detected by collision listener

    // ── 冲刺状态 / Dash state ─────────────────────────────────────────────
    private boolean canDash    = true; // 冲刺是否可用 / whether dash is available
    private int     dashCooldown = 0;  // 冷却剩余秒数，用于HUD显示 / remaining cooldown seconds for HUD
    private boolean isDashing    = false; // 是否正在冲刺中（防止跑步贴图覆盖冲刺贴图）/ true while dash animation is active

    // ── 强制死亡标志 / Forced death flag ──────────────────────────────────
    // Level3 结局用：跳过Game Over，直接进入结局演出
    // Used in Level3 ending: skips Game Over and triggers the ending cutscene
    private boolean forceDeath = false;

    // ── 回调接口 / Callback interfaces ───────────────────────────────────

    /** 死亡时通知 GameController / Notifies GameController when the player dies. */
    public interface DeathListener  { void onDeath(); }
    public boolean isDashing()   { return isDashing; }

    /** 存档时通知 UserInterface 显示提示 / Notifies UserInterface to show the save indicator. */
    public interface SaveListener   { void onSaved(); }

    /** 受伤时通知 UserInterface 触发红色闪烁 / Notifies UserInterface to trigger the damage flash. */
    public interface DamageListener { void onDamage(); }

    private DeathListener  deathListener;
    private SaveListener   saveListener;
    private DamageListener damageListener;

    // ─────────────────────────────────────────────────────────────────────

    /**
     * @param world 所属物理世界 / physics world
     */
    public Ran(World world) {
        super(world, new BoxShape(1, 2));
        addImage(jingzhi);

        // 检测附近的食物（记录引用，供 Interaction 使用）
        // Detect nearby food and record a reference for use by Interaction
        addCollisionListener(new CollisionListener() {
            @Override
            public void collide(CollisionEvent e) {
                if (e.getOtherBody() instanceof Food) {
                    nearbyFood = (Food) e.getOtherBody();
                }
            }
        });
    }

    // ── 移动控制 / Movement controls ─────────────────────────────────────

    /**
     * 开始向左或向右行走并切换奔跑贴图。
     * Starts walking left or right and switches to the running sprite.
     *
     * @param speed 正值向右，负值向左 / positive = right, negative = left
     */
    public void moveRan(float speed) {
        startWalking(speed);
        removeAllImages();
        addImage(speed > 0 ? runRight : runLeft);
    }

    /**
     * 停止行走，清除X轴速度，切回站立贴图。
     * Stops walking, clears horizontal velocity, and switches to idle sprite.
     */
    public void stopRan() {
        stopWalking();
        setLinearVelocity(new Vec2(0, getLinearVelocity().y));
        removeAllImages();
        addImage(jingzhi);
    }

    /**
     * 若当前静止则执行跳跃，提高重力使下落更有重量感。
     * Executes a jump if currently grounded; increases gravity scale for weightier feel.
     *
     * @param force 跳跃力度 / jump force
     */
    public void jumpRan(float force) {
        setGravityScale(2f); // 加大重力，下落更快 / increased gravity for faster fall
        Vec2 v = getLinearVelocity();
        if (Math.abs(v.y) < 0.01f) { // 只有接近静止（在地面上）才能跳 / only jump when grounded
            jump(force);
            removeAllImages();
            addImage(v.x < 0 ? jumpLeft : jumpRight);
        }
    }

    /**
     * 向左或向右冲刺：短时间内高速移动，结束后5秒冷却。
     * Dash left or right: short burst of high speed, followed by a 5-second cooldown.
     *
     * @param goRight true = 向右冲刺，false = 向左冲刺 / true = dash right, false = dash left
     */
    public void dash(boolean goRight) {
        if (!canDash) return;
        canDash = false;
        dashCooldown = 5;
        isDashing = true; // 进入冲刺状态 / mark dash as active

        float dashSpeed = 30f;
        setLinearVelocity(new Vec2(goRight ? dashSpeed : -dashSpeed, 0));
        removeAllImages();
        addImage(goRight ? dashRight : dashLeft);

        // 400ms 后停止冲刺速度 / stop dash velocity after 400ms
        Timer dashTimer = new Timer(400, e -> {
            setLinearVelocity(new Vec2(0, getLinearVelocity().y));
            stopWalking();
            isDashing = false; //退出冲刺状态 / mark dash as finished
            removeAllImages();
            addImage(jingzhi);
        });
        dashTimer.setRepeats(false);
        dashTimer.start();

        // 每秒倒计时，到0时恢复冲刺 / countdown per second; restore dash when it reaches 0
        Timer[] countdownTimer = {null};
        countdownTimer[0] = new Timer(1000, e -> {
            dashCooldown--;
            if (dashCooldown <= 0) {
                dashCooldown = 0;
                canDash = true;
                countdownTimer[0].stop();
            }
        });
        countdownTimer[0].start();
    }

    // ── 战斗碰撞体切换 / Combat hitbox switching ─────────────────────────

    /**
     * 在探索碰撞体（大方块）和战斗碰撞体（小圆点）之间切换。
     * Switches between the exploration hitbox (large box) and combat hitbox (small circle).
     *
     * @param isCombat true = 战斗小圆点，false = 探索大方块 / true = small combat circle, false = large walk box
     */
    public void setCombatHitbox(boolean isCombat) {
        if (!getFixtureList().isEmpty()) {
            getFixtureList().get(0).destroy(); // 移除当前碰撞体 / remove current fixture
        }
        currentFixture = new SolidFixture(this, isCombat ? combatShape : walkShape);
    }

    // ── 血量管理 / Health management ─────────────────────────────────────

    public int  getHealth()       { return health; }
    public void setHealth(int h)  { health = h; }

    /**
     * 扣一滴血并触发受伤回调；血量归零时触发死亡回调。
     * Decrements health by one and fires the damage callback; fires the death callback at zero.
     */
    public void decrementHealth() {
        health--;
        notifyDamage();
        SoundManager.play("damage");
        if (health <= 0) {
            health = 0;
            if (deathListener != null) deathListener.onDeath();
        }
    }

    // ── 强制死亡 / Forced death ───────────────────────────────────────────

    public boolean isForceDeath()          { return forceDeath; }
    public void    setForceDeath(boolean b){ forceDeath = b; }

    // ── 食物引用 / Food reference ─────────────────────────────────────────

    public Food getNearbyFood()        { return nearbyFood; }
    public void setNearbyFood(Food f)  { nearbyFood = f; }

    // ── 冲刺状态查询 / Dash state queries ────────────────────────────────

    public boolean canDash()        { return canDash; }
    public int     getDashCooldown(){ return dashCooldown; }

    // ── 回调注册与触发 / Callback registration and firing ─────────────────

    public void setDeathListener(DeathListener l)   { deathListener  = l; }
    public void setSaveListener(SaveListener l)     { saveListener   = l; }
    public void setDamageListener(DamageListener l) { damageListener = l; }

    /** 由 SavePoint 调用，通知 UI 显示存档提示 / Called by SavePoint to show the save notification. */
    public void notifySaved()  { if (saveListener   != null) saveListener.onSaved();   }

    /** 受伤时调用，通知 UI 触发红色闪烁 / Called on damage to trigger the red damage flash. */
    public void notifyDamage() { if (damageListener != null) damageListener.onDamage(); }
}