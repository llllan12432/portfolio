/**
 * SaveData — 存档数据的简单容器类（Plain Old Java Object）/ Plain data container for save file data.
 *
 * 由 SaveSystem.load() 填充并返回，由 GameController.loadGame() 读取。
 * Populated and returned by SaveSystem.load(); consumed by GameController.loadGame().
 *
 * 字段使用 public 直接访问，避免引入不必要的 getter/setter 样板代码。
 * Fields are public for direct access, avoiding unnecessary getter/setter boilerplate
 * in a simple data-transfer object like this.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class SaveData {
    public int   levelNum;   // 存档时所在的关卡编号 / level number at time of save
    public int   health;     // 存档时的血量 / player health at time of save
    public boolean combatWon; // 该关卡的战斗是否已胜利 / whether combat was won in this level
    public float x;          // 存档时玩家的X坐标 / player X position at time of save
    public float y;          // 存档时玩家的Y坐标 / player Y position at time of save
}