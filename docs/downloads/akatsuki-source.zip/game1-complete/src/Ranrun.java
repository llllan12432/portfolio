import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import city.cs.engine.*;
import org.jbox2d.common.Vec2;

/**
 * Ranrun — 玩家移动控制器 / Player movement controller.
 *
 * 同时实现 KeyAdapter（响应键盘事件）和 StepListener（每帧更新逻辑）。
 * Implements both KeyAdapter (keyboard events) and StepListener (per-frame update logic).
 *
 * 负责管理：移动/跳跃/冲刺、战斗模式移动、蓝魂模式移动、
 * 食物检测、落地音效、贴图切换、关卡边界检测、ESC暂停和Game Over处理。
 * Responsible for: movement/jump/dash, combat movement, blue-soul movement,
 * food detection, landing sounds, sprite switching, level boundary checks,
 * ESC pause, and Game Over handling.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Ranrun extends KeyAdapter implements StepListener {

    private Ran ran;
    private NpcSensor sensor;
    private UserInterface view;
    private GameController controller;

    // 四个方向键是否被按住（用于战斗模式的持续移动）
    // Whether each direction key is held (for continuous combat movement)
    private boolean upPressed, downPressed, leftPressed, rightPressed;

    // 跳跃/落地状态检测 / jump and landing state detection
    private boolean isJumping  = false; // 是否处于空中 / whether the player is airborne
    private boolean wasFalling = false; // 上一帧是否在下落 / whether the player was falling last frame

    /**
     * @param ran        玩家角色 / player character
     * @param sensor     NPC传感器 / NPC proximity sensor
     * @param view       游戏视图 / game view
     * @param controller 游戏总控制器 / game controller
     * @param level      当前关卡（用于注册受管理的StepListener）/ current level (for managed StepListener)
     */
    public Ranrun(Ran ran, NpcSensor sensor, UserInterface view, GameController controller, GameLevel level) {
        this.ran        = ran;
        this.sensor     = sensor;
        this.view       = view;
        this.controller = controller;
        level.addManagedStepListener(this); // 注册受管理的监听器，关卡切换时自动移除 / auto-removed on level transition
    }

    // ── 键盘按下 / Key pressed ────────────────────────────────────────────

    @Override
    public void keyPressed(KeyEvent e) {
        // ESC 打开暂停菜单（结局和Game Over期间禁用）
        // ESC opens pause menu (disabled during ending and Game Over)
        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
            if (!view.isGameOver && !view.isEnding) {
                controller.showPauseMenu();
            }
            return;
        }

        // Game Over：满足条件后按任意键返回主菜单 / Any key returns to main menu after Game Over
        if (view.isGameOver) {
            if (view.gameOverAlpha >= 255 && view.subtitleAlpha >= 255) {
                view.isGameOver       = false;
                view.gameOverAlpha    = 0;
                view.subtitleAlpha    = 0;
                view.heartBreakSize   = 14;
                view.heartBreakAlpha  = 255;
                controller.showMainMenu();
            }
            return; // Game Over 期间拦截所有其他按键 / block all other keys during Game Over
        }

        // 开场独白期间和对话窗口期间禁止移动 / block movement during monologue and dialogue
        if (view.inStory()) return;
        if (view.showBox && !sensor.isCombatActive()) return;

        int code = e.getKeyCode();
        // 记录方向键状态，供战斗模式持续移动使用
        // Track direction key state for continuous combat movement
        if (code == KeyEvent.VK_W) upPressed    = true;
        if (code == KeyEvent.VK_S) downPressed  = true;
        if (code == KeyEvent.VK_A) leftPressed  = true;
        if (code == KeyEvent.VK_D) rightPressed = true;

        if (sensor.isBlueMode() && sensor.isCombatActive()) {
            // 蓝魂模式：W键跳跃，方向随当前重力方向翻转
            // Blue-soul mode: W jumps; direction inverts with gravity
            if (code == KeyEvent.VK_W) {
                Vec2 pos = ran.getPosition();
                float jumpDir = ran.getGravityScale() > 0 ? 10f : -10f;
                if (ran.getGravityScale() > 0 && pos.y <= 47.6f) {
                    ran.setLinearVelocity(new Vec2(ran.getLinearVelocity().x, jumpDir));
                } else if (ran.getGravityScale() < 0 && pos.y >= 52.4f) {
                    ran.setLinearVelocity(new Vec2(ran.getLinearVelocity().x, jumpDir));
                }
            }
        } else if (sensor.isCombatActive()) {
            // 普通战斗模式：WASD 瞬间设速，speed 由 preStep 的持续检测接管
            // Normal combat: WASD sets velocity immediately; held-key movement handled in preStep
            float speed = 12f;
            if (code == KeyEvent.VK_W) ran.setLinearVelocity(new Vec2(0,  speed));
            else if (code == KeyEvent.VK_S) ran.setLinearVelocity(new Vec2(0, -speed));
            else if (code == KeyEvent.VK_A) ran.setLinearVelocity(new Vec2(-speed, 0));
            else if (code == KeyEvent.VK_D) ran.setLinearVelocity(new Vec2( speed, 0));
        } else {
            // 探索模式：A/D 行走，W 跳跃，K 冲刺
            // Exploration: A/D walk, W jump, K dash
            if (code == KeyEvent.VK_A)      { ran.moveRan(-30); }
            else if (code == KeyEvent.VK_D) { ran.moveRan(30); }
            else if (code == KeyEvent.VK_W) {
                ran.jumpRan(12);
                isJumping = true; // 只有跳跃键才标记为空中 / only W sets isJumping
            } else if (code == KeyEvent.VK_K) {
                // 冲刺方向跟随当前水平速度 / dash direction follows current horizontal velocity
                boolean goRight = ran.getLinearVelocity().x >= 0;
                ran.dash(goRight);
            }
        }
    }

    // ── 键盘松开 / Key released ───────────────────────────────────────────

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_W) upPressed    = false;
        if (code == KeyEvent.VK_S) downPressed  = false;
        if (code == KeyEvent.VK_A) leftPressed  = false;
        if (code == KeyEvent.VK_D) rightPressed = false;

        if (!sensor.isCombatActive()) {
            // 探索模式：松开左右键时停止行走 / stop walking when A or D is released
            if (code == KeyEvent.VK_A || code == KeyEvent.VK_D) {
                ran.stopRan();
            }
        } else if (!sensor.isBlueMode()) {
            // 普通战斗模式：所有方向键松开后停止 / stop when all direction keys are released
            if (!upPressed && !downPressed && !leftPressed && !rightPressed) {
                ran.setLinearVelocity(new Vec2(0, 0));
            }
        }
    }

    // ── 每帧逻辑 / Per-frame logic ────────────────────────────────────────

    @Override
    public void preStep(StepEvent e) {

        // 食物检测：每帧扫描是否在饭团2.5单位内 / scan every frame whether within 2.5 units of food
        view.nearFood = false;
        for (StaticBody b : ran.getWorld().getStaticBodies()) {
            if (b instanceof Food) {
                float dx = b.getPosition().x - ran.getPosition().x;
                float dy = b.getPosition().y - ran.getPosition().y;
                if (Math.sqrt(dx * dx + dy * dy) < 2.5f) {
                    view.nearFood = true;
                    break;
                }
            }
        }

        float mvy = ran.getLinearVelocity().y;
        float mvx = ran.getLinearVelocity().x;

        // 落地检测：从下落状态变为接近静止时播放落地音效
        // Landing detection: play sound when transitioning from falling to nearly still
        if (isJumping && wasFalling && mvy > -0.5f && !sensor.isCombatActive()) {
            isJumping = false;
            SoundManager.play("jumpland");
        }
        wasFalling = mvy < -1f; // 速度明显向下才算下落 / only count as falling if clearly moving downward

        // 探索模式贴图切换 / sprite switching in exploration mode
        if (!sensor.isCombatActive()) {
            if (isJumping && mvy > 0) {
                // 上升阶段：跳跃贴图 / ascending: jump sprite
                ran.removeAllImages();
                ran.addImage(mvx >= 0 ? Ran.jumpRight : Ran.jumpLeft);
            } else if (isJumping && mvy < 0) {
                // 下落阶段：落地贴图 / descending: fall sprite
                ran.removeAllImages();
                ran.addImage(mvx >= 0 ? Ran.fallRight : Ran.fallLeft);
            } else if (!isJumping && !ran.isDashing()) {
                // 地面且非冲刺：跑步或站立贴图 / grounded and not dashing: run or idle
                // 冲刺期间跳过此块，防止跑步贴图覆盖冲刺贴图
                // Skip during dash to prevent run sprite overriding dash sprite
                ran.removeAllImages();
                if      (mvx >  0.5f) ran.addImage(Ran.runRight);
                else if (mvx < -0.5f) ran.addImage(Ran.runLeft);
                else                  ran.addImage(Ran.jingzhi);
            }
        }

        // 战斗模式移动 / combat movement
        if (sensor.isCombatActive()) {
            if (sensor.isBlueMode()) {
                // 蓝魂模式：仅允许左右移动，Y轴由物理重力控制
                // Blue-soul: only horizontal movement; Y is controlled by gravity
                float vx = 0;
                if (leftPressed)  vx = -8f;
                if (rightPressed) vx =  8f;

                Vec2 pos  = ran.getPosition();
                float newX = Math.max(-3.8f, Math.min(3.8f, pos.x)); // 限制在战斗框内 / clamp to combat box
                ran.setLinearVelocity(new Vec2(vx, ran.getLinearVelocity().y));
                if (newX != pos.x) ran.setPosition(new Vec2(newX, pos.y));

                // 防止穿透地面和天花板 / prevent clipping through floor and ceiling
                if (pos.y <= 45.5f) {
                    ran.setLinearVelocity(new Vec2(vx, 0));
                    ran.setPosition(new Vec2(newX, 45.5f));
                }
                if (pos.y > 52.8f) {
                    ran.setLinearVelocity(new Vec2(vx, 0));
                    ran.setPosition(new Vec2(pos.x, 52.8f));
                }
            } else {
                // 普通战斗模式：全方向自由移动 / normal combat: free movement in all directions
                float vx = 0, vy = 0, speed = 15f;
                if (upPressed)    vy += speed;
                if (downPressed)  vy -= speed;
                if (leftPressed)  vx -= speed;
                if (rightPressed) vx += speed;
                ran.setLinearVelocity(new Vec2(vx, vy));

                // 限制在战斗框内 / clamp to combat box bounds
                Vec2 pos  = ran.getPosition();
                float newX = Math.max(-3.8f, Math.min(3.8f, pos.x));
                float newY = Math.max(47.2f, Math.min(52.8f, pos.y));
                if (newX != pos.x || newY != pos.y) {
                    ran.setPosition(new Vec2(newX, newY));
                }
            }
        } else {
            // 探索模式边界检测 / exploration boundary checks
            if (view.showBox || sensor.isShowDialogue()) {
                ran.stopRan(); // 对话期间强制停止 / force stop during dialogue
            } else {
                Vec2 pos = ran.getPosition();
                if (pos.x < -15.5f) {
                    ran.setPosition(new Vec2(-15.5f, pos.y)); // 左边界 / left boundary
                } else if (pos.x > 15.5f) {
                    if (sensor.isCombatWon()) {
                        // 战斗胜利后走到右边界则进入下一关 / proceed to next level at right boundary after victory
                        controller.loadLevel(controller.getCurrentLevelNum() + 1);
                    } else {
                        ran.setPosition(new Vec2(15.5f, pos.y)); // 右边界 / right boundary
                    }
                }
            }
        }
    }

    @Override
    public void postStep(StepEvent e) {}
}