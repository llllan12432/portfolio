import city.cs.engine.*;

/**
 * Sasori — Level1 中的蝎静态NPC体 / Static NPC body for Sasori in Level 1.
 *
 * 使用 GhostlyFixture 使玩家可以穿过，仅作视觉展示。
 * Uses a GhostlyFixture so the player can walk through; purely decorative.
 * 实际交互通过附属的 SasoriSensor 传感器完成。
 * Actual interaction is handled by the attached SasoriSensor.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class Sasori extends StaticBody {

    // 蝎立绘贴图 / Sasori character sprite
    private static final BodyImage xietu = new BodyImage("data/xie.png", 8.5f);

    /**
     * @param world 所属物理世界 / physics world
     */
    public Sasori(World world) {
        super(world);
        new GhostlyFixture(this, new BoxShape(1, 6)); // 幽灵体，玩家可穿过 / ghostly, player can pass through
        addImage(xietu);
    }
}