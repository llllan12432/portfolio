import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * MainMenu — 游戏主菜单面板 / Game main menu panel.
 *
 * 使用绝对定位（null layout）手动排列按钮，在 paintComponent 中绘制背景和标题。
 * Uses absolute positioning (null layout) to arrange buttons; background and title
 * are drawn manually in paintComponent.
 * 按钮悬停时变金色，提供视觉反馈。
 * Buttons turn gold on hover for visual feedback.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class MainMenu extends JPanel {

    private Image background = new ImageIcon("data/caidan.png").getImage(); // 主菜单背景图 / main menu background
    private GameController controller; // 控制器引用，用于触发游戏事件 / controller reference for game events

    /**
     * @param controller 游戏总控制器 / central game controller
     */
    public MainMenu(GameController controller) {
        this.controller = controller;
        setPreferredSize(new Dimension(800, 600));
        setLayout(null); // 绝对定位，手动指定每个按钮位置 / absolute layout: positions set manually

        // 开始游戏按钮 / new game button
        JButton startBtn = createButton("New Game");
        startBtn.setBounds(80, 280, 180, 45);
        startBtn.addActionListener(e -> controller.startGame());
        add(startBtn);

        // 读取存档按钮 / load save button
        JButton loadBtn = createButton("Load Game");
        loadBtn.setBounds(80, 340, 180, 45);
        loadBtn.addActionListener(e -> controller.loadGame());
        add(loadBtn);

        // 设置按钮（音量控制）/ settings button (volume control)
        JButton settingsBtn = createButton("Settings");
        settingsBtn.setBounds(80, 400, 180, 45);
        settingsBtn.addActionListener(e -> controller.showSettings());
        add(settingsBtn);

        // 退出游戏按钮 / quit button
        JButton exitBtn = createButton("Quit");
        exitBtn.setBounds(80, 460, 180, 45);
        exitBtn.addActionListener(e -> System.exit(0));
        add(exitBtn);
    }

    /**
     * 创建统一样式的菜单按钮（深色背景，白色文字，悬停变金色）。
     * Creates a consistently styled menu button (dark background, white text, gold on hover).
     *
     * @param text 按钮文字 / button label
     * @return 配置好的 JButton / configured JButton
     */
    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Verdana", Font.BOLD, 16));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(0, 0, 0, 150));
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        // 悬停变金色，离开恢复白色 / gold on hover, white on exit
        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) { btn.setForeground(new Color(255, 215, 0)); }
            @Override
            public void mouseExited(MouseEvent e)  { btn.setForeground(Color.WHITE); }
        });
        return btn;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(background, 0, 0, 800, 600, this); // 绘制背景 / draw background

        // 绘制标题（先画阴影再画主文字，产生立体感）
        // Draw title with shadow for a 3D effect
        g.setFont(new Font("Verdana", Font.BOLD, 60));
        g.setColor(new Color(0, 0, 0, 150));
        g.drawString("Akatsuki", 68, 203); // 阴影偏移3px / shadow offset by 3px
        g.setColor(Color.WHITE);
        g.drawString("Akatsuki", 65, 200);
    }
}