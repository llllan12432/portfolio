import city.cs.engine.*;

/**
 * ItachiSensor — 鼬NPC的接近传感器 / Proximity sensor for the Itachi NPC.
 *
 * 继承 NpcSensor，传入鼬实体和传感器尺寸。
 * Extends NpcSensor, passing in the Itachi body and sensor dimensions.
 * 检测玩家靠近后开启对话流程。
 * Detects when the player enters range and initiates the dialogue sequence.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class ItachiSensor extends NpcSensor {

    /**
     * @param npc 鼬的静态体实例 / Itachi's static body instance
     */
    public ItachiSensor(Itachi npc) {
        super(npc, new BoxShape(1.5f, 1.5f));
    }
}