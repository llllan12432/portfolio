import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import javax.swing.*;
import java.awt.*;

/**
 * UserInterface — 游戏的主视图类 / Main view class for the game.
 *
 * 继承引擎的 UserView，通过 paintBackground 和 paintForeground 覆盖绘制所有 UI 元素。
 * Extends UserView; overrides paintBackground and paintForeground to draw all UI elements.
 *
 * 负责绘制：对话框（打字机效果）、血条、HUD、战斗框及其内容、
 * 受伤闪烁、画面震动、Game Over 界面、结局演出。
 * Responsible for drawing: dialogue box (typewriter), health bar, HUD, combat box and contents,
 * damage flash, screen shake, Game Over screen, and ending cutscene.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class UserInterface extends UserView {

    // ── 核心引用 / Core references ────────────────────────────────────────
    public Ran ran;
    public NpcSensor sensor;

    // ── 对话系统 / Dialogue system ────────────────────────────────────────
    public String[] currentScript = Dialogue.START_STORY; // 当前剧本 / current script
    public int      dialogueIndex = 0;   // 当前台词索引 / current line index
    public boolean  inStory       = true; // 是否在开场独白中 / whether in opening monologue
    public boolean  showBox       = true; // 是否显示对话框 / whether dialogue box is visible
    public int      typewriterIndex = 0; // 打字机当前字符数 / typewriter character count
    public boolean  isTyping      = false; // 打字机是否正在运行 / whether typewriter is active

    // ── 食物检测 / Food detection ─────────────────────────────────────────
    public boolean nearFood = false; // 玩家是否在食物附近 / whether player is near food

    // ── 战斗系统 / Combat system ──────────────────────────────────────────
    public int combatPhase = 0; // 当前战斗阶段（0=未战斗）/ current combat phase (0 = none)
    public boolean combatBlackout = false; // 阶段切换黑屏标志 / combat blackout flag

    // ── 受伤效果 / Damage effect ──────────────────────────────────────────
    public int damageFlashAlpha = 0; // 受伤红色闪烁透明度 / damage flash alpha

    // ── 画面震动 / Screen shake ───────────────────────────────────────────
    public int shakeFrames = 0; // 剩余震动帧数 / remaining shake frames

    // ── Game Over ─────────────────────────────────────────────────────────
    public boolean isGameOver   = false;
    public int gameOverAlpha    = 0; // GAME OVER文字渐入透明度 / GAME OVER fade-in alpha
    public int subtitleAlpha    = 0; // 副标题渐入透明度 / subtitle fade-in alpha

    // ── 心碎动画 / Heart-break animation ─────────────────────────────────
    public boolean showHeartBreak   = false;
    public int     heartBreakSize   = 14;  // 当前心碎图片大小 / current heart-break image size
    public int     heartBreakAlpha  = 255; // 心碎图片透明度 / heart-break image alpha
    public int     lastHeartX       = 400; // 战斗框内心的最后X坐标（用于心碎动画定位）/ last heart X for break animation
    public int     lastHeartY       = 300;

    // ── 结局演出 / Ending cutscene ────────────────────────────────────────
    public boolean isEnding            = false;
    public int     blinkAlpha          = 255;   // 眨眼遮罩透明度 / blink overlay alpha
    public boolean blinkingDone        = false;  // 眨眼动画是否完成 / whether blink animation is done
    public boolean endingDone          = false;  // 结局对话是否全部播完 / whether all ending dialogue is done
    public Runnable onEndingPhaseComplete = null; // 独白第一阶段结束后的回调 / callback after first narration phase
    private String[] endingScript      = null;
    private int      endingLineIndex   = 0;
    private int      endingCharIndex   = 0;

    // ── 存档/HP恢复提示 / Save and heal message ───────────────────────────
    private int saveMessageAlpha  = 0; // 存档提示透明度 / save message alpha
    private int healMessageAlpha  = 0; // HP恢复提示透明度 / heal message alpha

    // ── Level3 专用 / Level3-specific ────────────────────────────────────
    public boolean showMeme = false; // 是否显示鼬meme背景 / whether to show Itachi meme background

    // ── 关卡标识（由GameController写入）/ Level number (set by GameController) ──
    public int currentLevelNum = 1;

    // ── 图片资源（在字段初始化，避免在渲染循环中重复加载）──────────────────
    // Image assets (initialised as fields to avoid repeated loading inside the render loop)
    public Image combatImage   = new ImageIcon("data/xie.png").getImage();
    public Image heart         = new ImageIcon("data/11xin.png").getImage();
    public Image spikeImg      = new ImageIcon("data/ci2.png").getImage();
    public Image explodeImg    = new ImageIcon("data/baizha.gif").getImage();
    public Image crowImg       = new ImageIcon("data/wuya.gif").getImage();
    public Image pillarImg     = new ImageIcon("data/pillar.png").getImage();
    public Image fireImg       = new ImageIcon("data/kaishishao.gif").getImage();
    public Image memeImg       = new ImageIcon("data/youmeme3.gif").getImage();
    public Image xieGif        = new ImageIcon("data/xie777.gif").getImage();
    public Image heartBreakImg = new ImageIcon("data/xinsui.gif").getImage();
    public Image endingBg      = new ImageIcon("data/jieju1.png").getImage();
    // 以下两张原本在渲染循环里 new ImageIcon，已移至此处避免每帧重新加载
    // These were previously created inside the render loop; moved here to prevent per-frame reloading
    public Image lanxinImg     = new ImageIcon("data/lanxin.png").getImage(); // 蓝魂心 / blue-soul heart
    public Image meteorImg     = new ImageIcon("data/yunshi.png").getImage(); // 陨石 / meteor

    // 关卡名称，按关卡编号索引（0位置留空，levelNum从1开始）
    // Level names indexed by level number (index 0 is a placeholder; levelNum starts at 1)
    private static final String[] LEVEL_NAMES = {
            "",
            "Chapter 1  · Sasori",
            "Chapter 2  · Pain",
            "Chapter 3  · Itachi"
    };

    /**
     * @param w      所属物理世界 / physics world
     * @param ran    玩家角色 / player character
     * @param s      NPC传感器 / NPC sensor
     * @param width  视图宽度（像素）/ view width in pixels
     * @param height 视图高度（像素）/ view height in pixels
     */
    public UserInterface(World w, Ran ran, NpcSensor s, int width, int height) {
        super(w, width, height);
        this.ran    = ran;
        this.sensor = s;
    }

    /** 当前是否在开场独白中 / Whether the opening monologue is currently playing. */
    public boolean inStory() { return inStory; }

    // ── 背景绘制 / Background rendering ──────────────────────────────────

    @Override
    public void paintBackground(Graphics2D g) {
        // 震动效果在 paintForeground 中统一处理，此处无需操作
        // Screen shake is handled in paintForeground; nothing needed here
    }

    // ── 前景绘制总入口 / Foreground rendering entry point ─────────────────

    @Override
    public void paintForeground(Graphics2D g) {
        // 画面震动：每帧随机偏移，倒计时减少 / screen shake: random offset per frame, decrement counter
        if (shakeFrames > 0) {
            int dx = (int) (Math.random() * 6 - 3);
            int dy = (int) (Math.random() * 6 - 3);
            g.translate(dx, dy);
            shakeFrames--;
        }

        // 结局演出：覆盖所有其他绘制 / ending cutscene: overrides all other drawing
        if (isEnding) {
            drawEnding(g);
            drawDamageFlash(g);
            return;
        }

        // 心碎动画（死亡过渡）/ heart-break animation (death transition)
        if (showHeartBreak) {
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, 800, 600);
            int hx = lastHeartX - heartBreakSize / 2;
            int hy = lastHeartY - heartBreakSize / 2;
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, heartBreakAlpha / 255f));
            g.drawImage(heartBreakImg, hx, hy, heartBreakSize, heartBreakSize, this);
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
            drawDamageFlash(g);
            return;
        }

        // Game Over 界面 / Game Over screen
        if (isGameOver) {
            drawGameOver(g);
            drawDamageFlash(g);
            return;
        }

        // 战斗模式：优先绘制战斗UI，防止与对话框冲突
        // Combat mode: draw combat UI first to prevent overlap with dialogue box
        if (sensor.isCombatActive()) {
            drawCombat(g);
            drawHealth(g);
            drawHUD(g);
            drawDamageFlash(g);
            return;
        }

        // 探索模式：开场独白时叠加半透明黑色遮罩
        // Exploration: overlay semi-transparent black during opening monologue
        if (inStory()) {
            g.setColor(new Color(0, 0, 0, 130));
            g.fillRect(0, 0, 800, 600);
        }

        if (showBox) {
            drawDialogueBox(g);
        }

        // 交互提示（食物优先级高于NPC）/ interaction prompt (food takes priority over NPC)
        if (!showBox && nearFood) {
            drawPrompt(g, true);
        } else if (!showBox && sensor.isPlayerInside()) {
            drawPrompt(g, false);
        }

        drawHealth(g);
        drawHUD(g);
        drawDamageFlash(g); // 探索中受伤也显示红光 / damage flash shown during exploration too
    }

    // ── 绘制子方法 / Drawing sub-methods ─────────────────────────────────

    /**
     * 绘制顶部血条（爱心图标）/ Draws the health bar (heart icons) at the top.
     */
    private void drawHealth(Graphics2D g) {
        for (int i = 0; i < ran.getHealth(); i++) {
            g.drawImage(heart, 20 + (i * 30), 20, 20, 20, this);
        }
    }

    /**
     * 绘制对话框（含打字机效果和说话者名字框）。
     * Draws the dialogue box with typewriter effect and speaker name tag.
     */
    private void drawDialogueBox(Graphics2D g) {
        if (dialogueIndex >= currentScript.length) {
            showBox = false;
            return;
        }

        String fullText = currentScript[dialogueIndex];
        String name    = "???";
        String content = fullText;

        // 按冒号拆分说话者和台词 / split on colon to extract speaker and content
        if (fullText.contains(":")) {
            String[] parts = fullText.split(":", 2);
            name    = parts[0];
            content = parts[1];
        }

        // 对话框主体 / dialogue box body
        g.setColor(new Color(255, 255, 255, 180));
        g.fillRoundRect(40, 480, 700, 110, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(40, 480, 700, 110, 20, 20);

        // 说话者名字框 / speaker name tag
        g.setColor(new Color(255, 255, 255, 180));
        g.fillRoundRect(50, 440, 110, 35, 20, 20);
        g.setColor(Color.BLACK);
        g.drawRoundRect(50, 440, 110, 35, 20, 20);

        g.setFont(new Font("Verdana", Font.BOLD, 18));
        g.drawString(name, 70, 465);

        // 打字机效果：只显示 typewriterIndex 个字符 / typewriter: show only typewriterIndex chars
        g.setFont(new Font("Verdana", Font.PLAIN, 20));
        String visible = content.substring(0, Math.min(typewriterIndex, content.length()));
        String[] visibleLines = visible.split("\\n", -1);
        int lineY = 515;
        for (String line : visibleLines) {
            g.drawString(line, 60, lineY);
            lineY += 28;
        }
    }

    /**
     * 绘制交互提示气泡（Enter键提示）。
     * Draws the interaction prompt bubble (Enter key hint).
     *
     * @param isFood true = 食物提示，false = NPC对话提示 / true = food prompt, false = NPC prompt
     */
    private void drawPrompt(Graphics2D g, boolean isFood) {
        String text = isFood ? "Enter to Eat" : "Press Enter";
        g.setColor(new Color(255, 255, 255, 180));
        g.fillRoundRect(320, 300, 160, 40, 20, 20);
        g.setFont(new Font("Verdana", Font.BOLD, 15));
        g.setColor(Color.BLACK);
        g.drawString(text, 345, 325);
    }

    /**
     * 绘制战斗界面：黑色背景 + 角色立绘 + 战斗框 + 所有弹幕和特效。
     * Draws the combat screen: black background, character portrait, combat box, and all projectiles.
     */
    private void drawCombat(Graphics2D g) {
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, 800, 600);

        // 阶段切换黑屏期间：Level3 显示光敏警告文字，其他关卡纯黑
        // During phase blackout: Level3 shows photosensitivity warning; others show plain black
        if (combatBlackout) {
            if (currentLevelNum == 3) {
                g.setFont(new Font("Verdana", Font.PLAIN, 14));
                g.setColor(new Color(200, 200, 200, 200));
                g.drawString("⚠ This sequence contains flashing lights.", 220, 280);
                g.drawString("It may affect players with photosensitive epilepsy.", 190, 310);
            }
            return;
        }

        // ── 背景/立绘 / Background and portrait ──────────────────────────
        if (currentLevelNum == 1) {
            // Level1：蝎GIF全屏背景，叠加半透明黑压暗 / Level1: Sasori GIF background, darkened
            g.drawImage(xieGif, 0, 0, 800, 600, this);
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.3f));
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, 800, 600);
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
        }
        if (currentLevelNum == 3 && showMeme) {
            // Level3：鼬meme GIF全屏背景 / Level3: Itachi meme GIF background
            g.drawImage(memeImg, 0, 0, 800, 600, this);
        }
        if (currentLevelNum == 2) {
            // Level2：佩恩静态立绘，等比缩放居中 / Level2: Pain portrait, scaled and centred
            int imgW = combatImage.getWidth(this);
            int imgH = combatImage.getHeight(this);
            float scale = 350f / imgH;
            int drawW = (int) (imgW * scale);
            int drawH = (int) (imgH * scale);
            g.drawImage(combatImage, 400 - drawW / 2, 50, drawW, drawH, this);
        }

        // ── 战斗框 / Combat box ───────────────────────────────────────────
        int shakeX = shakeFrames > 0 ? (int) (Math.random() * 14 - 7) : 0;
        int shakeY = shakeFrames > 0 ? (int) (Math.random() * 14 - 7) : 0;
        int boxX = 280 + shakeX, boxY = 350 + shakeY;
        int boxW = 240, boxH = 180;
        g.setColor(Color.WHITE);
        g.drawRect(boxX, boxY, boxW, boxH);

        // 火焰边框（Level3 阶段三）/ fire border (Level3 phase 3)
        if (sensor.isFireActive()) {
            g.drawImage(fireImg, boxX - 45, boxY - 40, boxW + 90, boxH + 60, this);
        }

        // ── 弹幕/特效绘制 / Projectile and effect rendering ──────────────
        for (DynamicBody b : getWorld().getDynamicBodies()) {
            // 将物理坐标映射到屏幕像素坐标 / map physics coordinates to screen pixel coordinates
            Vec2 sOffset = b.getPosition().sub(new Vec2(0, 50));
            int sx = (boxX + boxW / 2) + (int) (sOffset.x * 30);
            int sy = (boxY + boxH / 2) - (int) (sOffset.y * 30);

            if (b instanceof IronSand) {
                // 蝎的铁砂：旋转绘制 / Sasori's iron sand: draw with rotation
                Graphics2D g2 = (Graphics2D) g.create();
                g2.translate(sx, sy);
                g2.rotate(-b.getAngle());
                g2.drawImage(spikeImg, -10, -10, 10, 10, this);
                g2.dispose();
            } else if (b instanceof Explosion) {
                g.drawImage(explodeImg, sx - 20, sy - 20, 80, 80, this);
            } else if (b instanceof CrowBall) {
                g.drawImage(crowImg, sx - 20, sy - 20, 40, 40, this);
            } else if (b instanceof Meteor) {
                // 使用字段中预加载的陨石图片，不在循环内 new ImageIcon
                // Use pre-loaded field image; do NOT new ImageIcon inside the render loop
                g.drawImage(meteorImg, sx - 20, sy - 20, 40, 40, this);
            }
        }

        // 柱子（StaticBody）绘制 / Pillar (StaticBody) rendering
        for (StaticBody b : getWorld().getStaticBodies()) {
            if (b instanceof Pillar) {
                Vec2 sOffset = b.getPosition().sub(new Vec2(0, 50));
                int sx = (boxX + boxW / 2) + (int) (sOffset.x * 30);
                int sy = (boxY + boxH / 2) - (int) (sOffset.y * 30);
                g.drawImage(pillarImg, sx - 15, sy - 50, 20, 60, this);
            }
        }

        // 粒子特效（CombatEffect 圆点）/ particle effect (CombatEffect dots)
        for (StaticBody b : getWorld().getStaticBodies()) {
            if (b instanceof CombatEffect) {
                Vec2 sOffset = b.getPosition().sub(new Vec2(0, 50));
                int sx = (boxX + boxW / 2) + (int) (sOffset.x * 30);
                int sy = (boxY + boxH / 2) - (int) (sOffset.y * 30);
                g.setColor(new Color(60, 60, 60, 220));
                g.fillOval(sx - 2, sy - 2, 4, 4);
            }
        }

        // ── 玩家心形（战斗框内）/ Player heart inside the combat box ──────
        Vec2 offset = ran.getPosition().sub(new Vec2(0, 50));
        int hX = (boxX + boxW / 2) + (int) (offset.x * 30);
        int hY = (boxY + boxH / 2) - (int) (offset.y * 30);
        lastHeartX = hX;
        lastHeartY = hY;
        // 蓝魂模式用预加载的蓝心，普通模式用红心 / blue-soul: pre-loaded blue heart; normal: red heart
        Image currentHeart = sensor.isBlueMode() ? lanxinImg : heart;
        g.drawImage(currentHeart, hX - 7, hY - 7, 14, 14, this);
    }

    /**
     * 绘制 Game Over 界面：黑色背景 + 红色 GAME OVER 文字渐入 + 副标题。
     * Draws the Game Over screen: black background, red GAME OVER fade-in, and subtitle.
     */
    private void drawGameOver(Graphics2D g) {
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, 800, 600);

        if (gameOverAlpha > 50) {
            int textAlpha = Math.min((gameOverAlpha - 50) * 255 / 150, 255);
            g.setFont(new Font("Verdana", Font.BOLD, 64));
            g.setColor(new Color(150, 0, 0, textAlpha)); // 阴影 / shadow
            g.drawString("GAME OVER", 243, 283);
            g.setColor(new Color(255, 50, 50, textAlpha)); // 主文字 / main text
            g.drawString("GAME OVER", 240, 280);
        }

        if (gameOverAlpha >= 255 && subtitleAlpha > 0) {
            g.setFont(new Font("Verdana", Font.PLAIN, 18));
            g.setColor(new Color(200, 200, 200, Math.min(subtitleAlpha, 255)));
            g.drawString("Press any key to continue...", 270, 370);
        }
    }

    /**
     * 绘制结局演出：背景图 + 黑色眨眼遮罩 + 打字机台词。
     * Draws the ending cutscene: background image, blink overlay, and typewriter dialogue.
     */
    private void drawEnding(Graphics2D g) {
        g.drawImage(endingBg, 0, 0, 800, 600, this);

        // 黑色眨眼遮罩 / black blink overlay
        if (blinkAlpha > 0) {
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, blinkAlpha / 255f));
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, 800, 600);
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
        }

        if (endingScript == null || endingLineIndex >= endingScript.length) return;
        String fullLine = endingScript[endingLineIndex];

        if (fullLine.startsWith("DARK:")) {
            // DARK 行：白色斜体，绘制在遮罩层上方 / DARK line: white italic over the overlay
            String fullContent = fullLine.substring(5);
            int showChars = Math.max(0, endingCharIndex - 5);
            String show = fullContent.substring(0, Math.min(showChars, fullContent.length()));
            g.setFont(new Font("Georgia", Font.ITALIC, 24));
            g.setColor(new Color(255, 255, 255, 200));
            g.drawString(show, 300, 300);
        } else {
            // 非DARK行在眨眼完成前不绘制 / non-DARK lines are hidden until the blink animation finishes
            if (!blinkingDone) return;
            String name = "???", fullContent = fullLine;
            int contentChars = endingCharIndex;
            if (fullLine.contains(":")) {
                String[] parts = fullLine.split(":", 2);
                name         = parts[0];
                fullContent  = parts[1];
                contentChars = Math.max(0, endingCharIndex - name.length() - 1);
            }
            String content = fullContent.substring(0, Math.min(contentChars, fullContent.length()));

            // 普通对话框 / standard dialogue box
            g.setColor(new Color(255, 255, 255, 180));
            g.fillRoundRect(40, 480, 700, 110, 20, 20);
            g.setColor(Color.BLACK);
            g.drawRoundRect(40, 480, 700, 110, 20, 20);
            g.setColor(new Color(255, 255, 255, 180));
            g.fillRoundRect(50, 440, 110, 35, 20, 20);
            g.setColor(Color.BLACK);
            g.drawRoundRect(50, 440, 110, 35, 20, 20);
            g.setFont(new Font("Verdana", Font.BOLD, 18));
            g.drawString(name, 70, 465);
            g.setFont(new Font("Verdana", Font.PLAIN, 20));
            g.drawString(content, 60, 515);
        }

        // 结局全部播完时显示继续提示 / show "Press any key" when all ending dialogue is done
        if (endingDone) {
            g.setFont(new Font("Verdana", Font.PLAIN, 16));
            g.setColor(new Color(160, 160, 160, 200));
            g.drawString("Press any key...", 310, 560);
        }
    }

    /**
     * 绘制 HUD：左上角关卡名、冲刺冷却状态、战斗阶段、存档/HP恢复提示。
     * Draws the HUD: level name, dash cooldown, combat phase, save and heal messages.
     */
    private void drawHUD(Graphics2D g) {
        // 关卡名 / level name
        if (currentLevelNum > 0 && currentLevelNum < LEVEL_NAMES.length) {
            g.setFont(new Font("Verdana", Font.BOLD, 14));
            g.setColor(new Color(255, 255, 255, 180));
            g.drawString(LEVEL_NAMES[currentLevelNum], 20, 55);
        }

        // 冲刺冷却（只在探索模式下显示）/ dash cooldown (only shown in exploration mode)
        if (!sensor.isCombatActive()) {
            g.setFont(new Font("Verdana", Font.BOLD, 13));
            if (ran.canDash()) {
                g.setColor(new Color(100, 255, 100, 200));
                g.drawString("[K] DASH  ready", 20, 75);
            } else {
                g.setColor(new Color(255, 100, 100, 200));
                g.drawString("[K] DASH  ↻ " + ran.getDashCooldown() + "s", 20, 75);
            }
        }

        // 战斗阶段提示 / combat phase indicator
        if (sensor.isCombatActive() && combatPhase > 0) {
            g.setFont(new Font("Verdana", Font.BOLD, 13));
            g.setColor(new Color(255, 100, 100, 200));
            g.drawString("Phase " + combatPhase, 20, 75);
        }

        // 存档提示淡出 / save message fade-out
        if (saveMessageAlpha > 0) {
            g.setFont(new Font("Verdana", Font.BOLD, 16));
            g.setColor(new Color(255, 215, 0, saveMessageAlpha));
            g.drawString("✦ Game Saved", 340, 55);
            saveMessageAlpha -= 3;
        }

        // HP恢复提示淡出（绿色，与存档金色区分）/ heal message fade-out (green, distinct from gold save message)
        if (healMessageAlpha > 0) {
            g.setFont(new Font("Verdana", Font.BOLD, 16));
            g.setColor(new Color(100, 255, 150, healMessageAlpha));
            g.drawString("✦ HP Restored", 340, 75);
            healMessageAlpha -= 3;
        }
    }

    /**
     * 受伤红色闪烁效果：每帧减少透明度直到消失。
     * Damage red flash: alpha decrements each frame until it fades out.
     */
    private void drawDamageFlash(Graphics2D g) {
        if (damageFlashAlpha > 0) {
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, damageFlashAlpha / 255f));
            g.setColor(Color.RED);
            g.fillRect(0, 0, 800, 600);
            g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
            damageFlashAlpha -= 15;
        }
    }

    // ── 公开触发方法 / Public trigger methods ────────────────────────────

    /** 触发存档提示（由 SavePoint 通过 Ran.notifySaved 回调）/ Trigger save notification. */
    public void showSaveMessage()  { saveMessageAlpha = 255; }

    /** 触发HP恢复提示（由 Interaction 在拾取食物后调用）/ Trigger heal notification. */
    public void showHealMessage()  { healMessageAlpha = 255; }

    /** 触发受伤红色闪烁 / Trigger the damage flash. */
    public void showDamageFlash()  { damageFlashAlpha = 180; }

    /**
     * 触发画面震动效果，持续约16帧（≈0.27秒）。
     * Triggers a screen shake lasting approximately 16 frames (~0.27 seconds).
     */
    public void triggerShake() {
        shakeFrames = 16;
        // 强制每帧重绘直到震动结束 / force repaint each frame until shake ends
        Timer shakeTimer = new Timer(16, e -> {
            if (shakeFrames <= 0) ((Timer) e.getSource()).stop();
            repaint();
        });
        shakeTimer.start();
    }

    // ── 对话/剧本控制 / Dialogue and script control ───────────────────────

    /**
     * 播放指定剧本（战斗后对话、战后独白等），从头开始打字机效果。
     * Plays a given script (post-combat dialogue, monologue, etc.) from the start with typewriter.
     *
     * @param script 要播放的对话数组 / dialogue array to play
     */
    public void playScript(String[] script) {
        currentScript  = script;
        dialogueIndex  = 0;
        showBox        = true;
        startTypewriter();
    }

    /**
     * 启动打字机效果，从第0个字符开始逐字显示当前台词。
     * Starts the typewriter effect, displaying the current line character by character.
     */
    public void startTypewriter() {
        typewriterIndex = 0;
        isTyping        = true;
        tickTypewriter();
    }

    /**
     * 打字机递归定时器：每40ms增加一个字符，打完后标记 isTyping = false。
     * Typewriter recursive timer: adds one character every 40ms; sets isTyping = false when done.
     */
    private void tickTypewriter() {
        if (dialogueIndex >= currentScript.length) return;
        String fullText = currentScript[dialogueIndex];
        String content  = fullText.contains(":") ? fullText.split(":", 2)[1] : fullText;

        if (typewriterIndex < content.length()) {
            Timer t = new Timer(40, e -> {
                ((Timer) e.getSource()).stop();
                typewriterIndex++;
                repaint();
                tickTypewriter();
            });
            t.setRepeats(false);
            t.start();
        } else {
            isTyping = false; // 本行打完 / line complete
        }
    }

    /**
     * 战斗阶段切换黑屏过渡：黑屏持续 duration 毫秒后执行回调。
     * Combat phase blackout transition: shows black for 'duration' ms then runs callback.
     *
     * @param duration   黑屏时长（毫秒）/ blackout duration in ms
     * @param onComplete 黑屏结束后执行的逻辑 / logic to run after blackout
     */
    public void playCombatBlackout(int duration, Runnable onComplete) {
        combatBlackout = true;
        repaint();
        Timer fadeOut = new Timer(duration, e -> {
            ((Timer) e.getSource()).stop();
            combatBlackout = false;
            repaint();
            if (onComplete != null) onComplete.run();
        });
        fadeOut.setRepeats(false);
        fadeOut.start();
    }

    // ── 结局演出控制 / Ending cutscene control ────────────────────────────

    /**
     * 启动结局演出，从第0行开始逐字播放。
     * Starts the ending cutscene, playing line by line from index 0.
     *
     * @param script 结局对话数组 / ending dialogue array
     */
    public void startEnding(String[] script) {
        endingScript    = script;
        endingLineIndex = 0;
        endingCharIndex = 0;
        isEnding        = true;
        endingDone      = false;
        tickEnding();
    }

    /**
     * 结局打字机递归定时器：处理 DARK 行与普通对话行的不同节奏。
     * Ending typewriter recursive timer: handles different timing for DARK lines vs dialogue lines.
     */
    private void tickEnding() {
        if (endingLineIndex >= endingScript.length) {
            endingDone = true;
            repaint();
            return;
        }
        String line = endingScript[endingLineIndex];

        // 遇到非DARK行时暂停，等待 GameController 的眨眼回调完成
        // Pause on non-DARK lines and wait for the GameController blink callback
        if (!line.startsWith("DARK:") && onEndingPhaseComplete != null) {
            Runnable cb = onEndingPhaseComplete;
            onEndingPhaseComplete = null; // 只触发一次 / fire only once
            cb.run();
            return;
        }

        if (endingCharIndex < line.length()) {
            Timer t = new Timer(80, e -> {
                ((Timer) e.getSource()).stop();
                endingCharIndex++;
                repaint();
                tickEnding();
            });
            t.setRepeats(false);
            t.start();
        } else {
            // 本行播完后停顿再换行（DARK行停顿更长）/ pause after each line (longer for DARK lines)
            int pause = line.startsWith("DARK:") ? 2000 : 1500;
            Timer pauseTimer = new Timer(pause, e -> {
                ((Timer) e.getSource()).stop();
                endingLineIndex++;
                endingCharIndex = 0;
                repaint();
                tickEnding();
            });
            pauseTimer.setRepeats(false);
            pauseTimer.start();
        }
    }

    /**
     * 眨眼完成后从暂停处继续播放结局对话。
     * Resumes ending dialogue from where it paused, after the blink animation finishes.
     */
    public void resumeEnding() {
        tickEnding();
    }
}