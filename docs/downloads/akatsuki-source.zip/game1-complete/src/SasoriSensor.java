import city.cs.engine.*;

/**
 * SasoriSensor — 蝎NPC的接近传感器 / Proximity sensor for the Sasori NPC.
 *
 * 继承 NpcSensor，传入蝎实体和传感器尺寸。
 * Extends NpcSensor, passing in the Sasori body and sensor dimensions.
 * 检测玩家靠近后开启对话流程，对话结束后触发战斗。
 * Detects when the player enters range, initiates dialogue, then triggers combat.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class SasoriSensor extends NpcSensor {

    /**
     * @param npc 蝎的静态体实例 / Sasori's static body instance
     */
    public SasoriSensor(Sasori npc) {
        super(npc, new BoxShape(1.5f, 1.5f));
    }
}