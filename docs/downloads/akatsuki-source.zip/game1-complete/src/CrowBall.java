import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import javax.swing.Timer;

/**
 * CrowBall — 鼬战斗阶段一的追踪乌鸦 / Tracking crow used in Itachi's combat phase 1.
 * 实现两段式AI：先追踪玩家，进入近距离后锁定方向直线冲刺。
 * Two-phase AI: tracks the player, then locks direction and charges in a straight line.
 *
 * @author Lan
 * @version 2.0
 * @since 1.0
 */
public class CrowBall extends DynamicBody {
    private static final BodyImage crowImage = new BodyImage("data/wuya.gif", 3f);
    private static final Shape shape = new CircleShape(0.3f);
    private Ran ran;
    private boolean straightMode = false;   // 是否已切换到直线冲刺模式 / whether straight-line mode is active
    private Vec2 straightVelocity = new Vec2(0, 0); // 锁定的冲刺方向 / locked charge direction

    public CrowBall(World world, Ran ran, float x, float y) {
        super(world, shape);
        this.ran = ran;
        setGravityScale(0); // 无重力，在战斗框内自由飞行 / no gravity, free movement in combat box
        setPosition(new Vec2(x, y));
        addImage(crowImage);

        // 碰撞到玩家时扣血并销毁 / deal damage and destroy on contact with player
        addCollisionListener(new CollisionListener() {
            @Override
            public void collide(CollisionEvent e) {
                if (e.getOtherBody() == ran) {
                    ran.decrementHealth();
                    destroy();
                }
            }
        });

        // 5秒后自动销毁，防止乌鸦堆积 / auto-destroy after 5s to prevent accumulation
        Timer lifeTimer = new Timer(5000, e -> destroy());
        lifeTimer.setRepeats(false);
        lifeTimer.start();
    }

    /**
     * 每帧由Level3的StepListener调用，实现追踪逻辑。
     * Called every frame by Level3's StepListener to update movement.
     *
     * 两段式AI / Two-phase AI:
     * 1. 追踪模式：持续朝玩家当前位置移动 / Tracking: continuously moves toward player
     * 2. 直线模式：进入2单位内时锁定方向，不再转向 / Straight: locks direction within 2 units, no more turning
     *    这样近距离时有冲刺感，玩家可以通过预判躲避。
     *    This gives a "charge" feel at close range that the player can dodge by anticipating.
     */
    public void chase() {
        Vec2 crowPos = getPosition();
        Vec2 ranPos = ran.getPosition();

        // 计算到玩家的方向向量 / calculate direction vector toward player
        float dx = ranPos.x - crowPos.x;
        float dy = ranPos.y - crowPos.y;
        float length = (float) Math.sqrt(dx * dx + dy * dy);

        if (length < 0.3f) return; // 已经非常接近，停止计算 / already very close, stop

        float speed = 6f;

        // 首次进入2单位范围内，切换到直线模式并锁定当前方向
        // First time within 2 units: switch to straight mode and lock current direction
        if (!straightMode && length < 2f) {
            straightMode = true;
            straightVelocity = new Vec2(
                    dx / length * speed,
                    dy / length * speed
            );
        }

        if (straightMode) {
            // 直线冲刺：用锁定的速度方向，不再跟踪 / straight charge: use locked velocity, no more tracking
            setLinearVelocity(straightVelocity);
            float angle = (float) Math.atan2(straightVelocity.y, straightVelocity.x);
            setAngle(angle);
        } else {
            // 追踪模式：每帧重新计算朝向玩家的方向 / tracking: recalculate direction toward player each frame
            float angle = (float) Math.atan2(dy, dx);
            setAngle(angle);
            setLinearVelocity(new Vec2(dx / length * speed, dy / length * speed));
        }
    }
}