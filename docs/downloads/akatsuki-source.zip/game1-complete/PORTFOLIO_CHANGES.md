# October 2026 portfolio maintenance

The final April coursework version had 32 Java source files. The reviewed copy adds TimerRegistry plus save/timer regressions and repairs described in REVIEW.md. Codex assisted this maintenance. The original university submission and its assessment result have not been altered.

The public source download is a review artifact, not a self-contained licensed game release: course engine and third-party media are omitted. Existing recorded gameplay belongs to the earlier coursework build.
