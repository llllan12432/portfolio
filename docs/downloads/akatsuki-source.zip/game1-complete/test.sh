#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
checkdir=$(mktemp -d)
trap 'rm -rf "$checkdir"' EXIT HUP INT TERM
mkdir "$checkdir/classes"
javac -encoding UTF-8 -d "$checkdir/classes" "$root/src/SaveData.java" "$root/src/SaveSystem.java" "$root/src/TimerRegistry.java" "$root/tests/RegressionTests.java"
cd "$checkdir"
java -Djava.awt.headless=true -cp classes RegressionTests
