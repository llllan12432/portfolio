Place CityEngine.jar here. Obtain the course library from City St George's Moodle. The engine is not redistributed because its redistribution licence has not been verified.
