@echo off
cd /d "%~dp0"
if not exist lib\CityEngine.jar (echo Missing lib\CityEngine.jar. See README.md. & exit /b 1)
if not exist build\classes mkdir build\classes
javac -encoding UTF-8 -cp lib\CityEngine.jar -d build\classes src\*.java
if errorlevel 1 exit /b 1
java -cp "build\classes;lib\CityEngine.jar" Game
