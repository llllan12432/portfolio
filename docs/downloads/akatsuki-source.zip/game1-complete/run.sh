#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ ! -f lib/CityEngine.jar ]; then
  echo "Missing lib/CityEngine.jar. See README.md." >&2
  exit 1
fi
mkdir -p build/classes
javac -encoding UTF-8 -cp lib/CityEngine.jar -d build/classes src/*.java
java -cp "build/classes:lib/CityEngine.jar" Game
