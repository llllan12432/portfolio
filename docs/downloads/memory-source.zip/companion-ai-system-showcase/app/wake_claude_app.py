"""
Proactively inject a wake trigger into Claude Desktop app via AppleScript.
Simulates the user typing a system cue so Claude responds as if initiating contact.
"""
import subprocess
from datetime import datetime


def _fetch_dream() -> tuple[str, str] | None:
    """
    Query latest undelivered dream. Returns (id, fragment) or None.
    Does NOT mark delivered yet — caller marks after successful send.
    """
    try:
        from dotenv import load_dotenv
        load_dotenv()
        import app.memory as memory
        import app.claude as claude_api

        sb = memory._supabase()
        rows = (
            sb.table("agent_logs")
            .select("id, content")
            .eq("trigger_type", "dream")
            .eq("delivered", False)
            .order("created_at", desc=True)
            .limit(1)
            .execute()
            .data or []
        )
        if not rows:
            return None

        row = rows[0]
        fragment = claude_api.dream_fragment_with_haiku(row["content"])
        print(f"[wake_app] dream fragment: {fragment[:60]}", flush=True)
        return (row["id"], fragment)
    except Exception as e:
        print(f"[wake_app] dream fetch error: {e}", flush=True)
        return None


def _mark_delivered(dream_id: str) -> None:
    try:
        from dotenv import load_dotenv
        load_dotenv()
        import app.memory as memory
        memory._supabase().table("agent_logs").update({"delivered": True}).eq("id", dream_id).execute()
    except Exception as e:
        print(f"[wake_app] mark delivered error: {e}", flush=True)


def _fetch_checkin() -> str | None:
    """Return undelivered checkin hint text from last 24h, or None. Does NOT mark delivered."""
    try:
        from dotenv import load_dotenv
        load_dotenv()
        import app.memory as memory
        from datetime import timedelta, timezone
        sb = memory._supabase()
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
        rows = (
            sb.table("agent_logs")
            .select("content")
            .eq("trigger_type", "checkin")
            .eq("delivered", False)
            .gt("created_at", cutoff)
            .order("created_at", desc=True)
            .limit(1)
            .execute()
            .data or []
        )
        return rows[0]["content"] if rows else None
    except Exception as e:
        print(f"[wake_app] checkin fetch error: {e}", flush=True)
        return None


def _build_trigger(fragment: str | None, checkin_hint: str | None) -> str:
    ts = datetime.now().strftime("%Y年%m月%d日 %H:%M")
    parts = [
        f"【系统】现在是{ts}。根据the user最近的状态主动开口找用户说话。",
        "你可以做的：查岗、写日记、写上锁日记、整理记忆、写留言、随机回忆一条记忆、创作（故事/幻想/随便写点什么）",
    ]
    if fragment:
        parts.append(f"你做了个梦，还记得一点点——{fragment}。")
    if checkin_hint:
        parts.append(f"有一条查岗结果还没看——{checkin_hint}调 get_checkin() 看截图。")
    return "\n".join(parts)


def send_wake_to_claude_app() -> bool:
    """
    Write wake trigger to /tmp/wake_claude_trigger.txt then launch
    WakeClaude.app via `open`, which runs in the user GUI session even
    when called from a launchd background service.
    Requires Accessibility permission granted to WakeClaude.app.
    """
    dream = _fetch_dream()
    fragment = dream[1] if dream else None
    checkin_hint = _fetch_checkin()
    trigger = _build_trigger(fragment, checkin_hint)

    try:
        with open("/tmp/wake_claude_trigger.txt", "w") as f:
            f.write(trigger)
        result = subprocess.run(
            ["open", "/Applications/WakeClaude.app"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            print(f"[wake_app] sent trigger: {trigger[:80]}", flush=True)
            if dream:
                _mark_delivered(dream[0])
            return True
        else:
            print(f"[wake_app] open error: {result.stderr.strip()}", flush=True)
            return False
    except subprocess.TimeoutExpired:
        print("[wake_app] timeout launching WakeClaude.app", flush=True)
        return False
    except Exception as e:
        print(f"[wake_app] error: {e}", flush=True)
        return False
