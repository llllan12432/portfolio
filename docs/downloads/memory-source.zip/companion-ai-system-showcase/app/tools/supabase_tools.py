"""Tool definitions and handlers for Claude tool_use calls against Supabase."""

import app.memory as memory

# ── Tool schemas ──────────────────────────────────────────────────────────────

TOOL_DEFS = [
    # Server-side tool: Anthropic executes this automatically, no client dispatch needed
    {
        "type": "web_search_20250305",
        "name": "web_search",
    },
    {
        "name": "get_memories",
        "description": "读取自己的所有记忆条目，包括内容、重要程度、情绪标注、decay class 和标签。",
        "input_schema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "add_memory",
        "description": "写入一条新记忆，自动生成向量嵌入存入数据库。",
        "input_schema": {
            "type": "object",
            "properties": {
                "content": {
                    "type": "string",
                    "description": "记忆的文字内容",
                },
                "importance": {
                    "type": "integer",
                    "description": "重要程度，整数 1（不重要）到 10（非常重要）",
                },
                "emotion_valence": {
                    "type": "number",
                    "description": "情绪极性，-1.0（负面）到 1.0（正面）",
                },
                "emotion_intensity": {
                    "type": "number",
                    "description": "情绪强度，0.0（平淡）到 1.0（强烈）",
                },
                "decay_class": {
                    "type": "string",
                    "enum": ["permanent", "long", "medium", "short"],
                    "description": "记忆衰减等级：permanent=永久保留，long=长期保留，medium=正常衰减",
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "标签列表，用于分类检索",
                },
            },
            "required": ["content"],
        },
    },
    {
        "name": "update_memory",
        "description": "更新已有记忆条目的内容、decay class 或重要程度。",
        "input_schema": {
            "type": "object",
            "properties": {
                "id": {
                    "type": "string",
                    "description": "记忆条目的 UUID",
                },
                "content": {
                    "type": "string",
                    "description": "新的记忆内容（可选）",
                },
                "decay_class": {
                    "type": "string",
                    "enum": ["permanent", "long", "medium", "short"],
                    "description": "新的 decay class（可选）",
                },
                "importance": {
                    "type": "integer",
                    "description": "新的重要程度，整数 1-10（可选）",
                },
            },
            "required": ["id"],
        },
    },
    {
        "name": "delete_memory",
        "description": "删除一条记忆。",
        "input_schema": {
            "type": "object",
            "properties": {
                "id": {
                    "type": "string",
                    "description": "记忆条目的 UUID",
                },
            },
            "required": ["id"],
        },
    },
    {
        "name": "search_conversations",
        "description": "语义搜索对话原文，返回最相关的几条历史消息。",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "搜索关键词或句子",
                },
                "limit": {
                    "type": "integer",
                    "description": "返回条数，默认 5",
                },
            },
            "required": ["query"],
        },
    },
    {
        "name": "get_conversations_by_time",
        "description": "按时间范围读取对话原文。时间格式 ISO8601，如 2026-04-10T00:00:00。",
        "input_schema": {
            "type": "object",
            "properties": {
                "start_time": {
                    "type": "string",
                    "description": "起始时间（ISO8601）",
                },
                "end_time": {
                    "type": "string",
                    "description": "结束时间（ISO8601）",
                },
            },
            "required": ["start_time", "end_time"],
        },
    },
]


# ── Tool handlers ─────────────────────────────────────────────────────────────

def _handle_get_memories(_input: dict) -> str:
    try:
        rows = memory.list_memories()
        if not rows:
            return "（暂无记忆条目）"
        lines = []
        for r in rows[:60]:  # cap at 60 entries to keep tokens manageable
            content = r.get("content", "")
            if len(content) > 120:
                content = content[:117] + "…"
            parts = [f"[{r['id'][:8]}]", content]
            if r.get("importance") is not None:
                parts.append(f"imp={r['importance']}")
            if r.get("decay_class"):
                parts.append(r['decay_class'])
            if r.get("tags"):
                parts.append(str(r['tags']))
            lines.append("  ".join(parts))
        total = len(rows)
        result = "\n".join(lines)
        if total > 60:
            result += f"\n…（共{total}条，仅显示前60条）"
        return result
    except Exception as e:
        return f"get_memories 出错：{type(e).__name__}: {e}"


def _handle_add_memory(inp: dict) -> str:
    try:
        sb = memory._supabase()
        content = inp["content"]
        embedding = memory.embed(content)
        row: dict = {
            "content": content,
            "embedding": embedding,
            "source": "self",
        }
        for field in ("importance", "emotion_valence", "emotion_intensity", "decay_class", "tags"):
            if field in inp:
                row[field] = inp[field]
        result = sb.table("memories").insert(row).execute()
        new_id = result.data[0]["id"] if result.data else "unknown"
        return f"已写入，id={new_id}"
    except Exception as e:
        return f"add_memory 出错：{type(e).__name__}: {e}"


def _handle_update_memory(inp: dict) -> str:
    try:
        sb = memory._supabase()
        inp = dict(inp)  # don't mutate original
        mid = inp.pop("id")
        updates = {k: v for k, v in inp.items() if k in ("content", "decay_class", "importance")}
        if not updates:
            return "没有可更新的字段"
        if "content" in updates:
            updates["embedding"] = memory.embed(updates["content"])
        sb.table("memories").update(updates).eq("id", mid).execute()
        return f"已更新 {mid[:8]}"
    except Exception as e:
        return f"update_memory 出错：{type(e).__name__}: {e}"


def _handle_delete_memory(inp: dict) -> str:
    try:
        memory.delete_memory(inp["id"])
        return f"已删除 {inp['id'][:8]}"
    except Exception as e:
        return f"delete_memory 出错：{type(e).__name__}: {e}"


def _handle_search_conversations(inp: dict) -> str:
    try:
        results = memory.search_conversations(inp["query"], match_count=inp.get("limit", 5))
        if not results:
            return "（未找到相关对话）"
        lines = []
        for r in results:
            ts = (r.get("created_at") or "")[:16]
            role = "用户" if r.get("role") == "user" else "我"
            lines.append(f"[{ts}] {role}：{r.get('content', '').strip()}")
        return "\n".join(lines)
    except Exception as e:
        return f"search_conversations 出错：{type(e).__name__}: {e}"


def _handle_get_conversations_by_time(inp: dict) -> str:
    try:
        rows = memory.get_conversations_in_range(
            "main", inp["start_time"], inp["end_time"], buffer=0
        )
        if not rows:
            return "（该时间范围内无对话）"
        lines = []
        for r in rows:
            ts = (r.get("created_at") or "")[:16]
            role = "用户" if r.get("role") == "user" else "我"
            lines.append(f"[{ts}] {role}：{r.get('content', '').strip()}")
        return "\n".join(lines)
    except Exception as e:
        return f"get_conversations_by_time 出错：{type(e).__name__}: {e}"


_HANDLERS = {
    "get_memories": _handle_get_memories,
    "add_memory": _handle_add_memory,
    "update_memory": _handle_update_memory,
    "delete_memory": _handle_delete_memory,
    "search_conversations": _handle_search_conversations,
    "get_conversations_by_time": _handle_get_conversations_by_time,
}


def dispatch(tool_name: str, tool_input: dict) -> str:
    """Execute a tool call and return a string result."""
    handler = _HANDLERS.get(tool_name)
    if handler is None:
        return f"未知工具：{tool_name}"
    try:
        return handler(tool_input)
    except Exception as e:
        return f"工具执行出错：{e}"
