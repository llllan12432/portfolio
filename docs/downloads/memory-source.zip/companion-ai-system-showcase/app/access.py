"""A single-owner local API boundary, not an OAuth or multi-tenant implementation."""
import os
import secrets
from starlette.responses import JSONResponse

class LocalApiAccess:
    def __init__(self, app):
        self.app = app
    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            return await self.app(scope, receive, send)
        path = scope.get('path', '')
        method = scope.get('method', '')
        disabled = ('/oauth', '/.well-known', '/session/wake', '/session/dream', '/agent', '/wake', '/dream', '/checkin')
        if path.startswith(disabled):
            return await JSONResponse({'detail':'Legacy integration disabled in this showcase'},status_code=404)(scope,receive,send)
        safe_read = method in {'GET','HEAD'} and (path in {'/', '/demo'} or path.startswith('/static/'))
        if not safe_read:
            expected = os.environ.get('MEMORY_API_TOKEN', '')
            if len(expected) < 32:
                return await JSONResponse({'detail':'Set MEMORY_API_TOKEN (at least 32 characters) for live API use'},status_code=503)(scope,receive,send)
            supplied = dict(scope.get('headers',[])).get(b'authorization',b'').decode('latin1')
            if not secrets.compare_digest(supplied, 'Bearer '+expected):
                return await JSONResponse({'detail':'Bearer token required'},status_code=401)(scope,receive,send)
        return await self.app(scope,receive,send)
