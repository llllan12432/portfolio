import os
import re
from datetime import datetime
from typing import Optional
import anthropic

_client: Optional[anthropic.Anthropic] = None

SONNET = "claude-sonnet-4-6"
HAIKU = "claude-haiku-4-5-20251001"

DEFAULT_SYSTEM = """You are a helpful conversational assistant. Use retrieved context when relevant. Distinguish stored facts from uncertainty. Do not invent personal history or relationships. Respond in the user's language."""

SESSION_SUMMARY_PROMPT = """请把以下最近的对话压缩成一段简短摘要，严格用这个格式：
上次聊到：[话题/内容]。情绪状态：[状态描述]。未解决的事：[若没有写"无"]。

对话记录：
{conversation}

直接给摘要，不加任何解释或标题。"""

MEMORY_EXTRACT_PROMPT = """请从以下对话中提炼出值得长期记忆的信息。
只提取具体的、有意义的事实（如用户的偏好、重要事件、情感状态、个人信息等）。
每条记忆独占一行，以 "-" 开头，简洁明了。
如果没有值得记忆的内容，回复"无"。

对话内容：
{conversation}"""


def _get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        _client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    return _client


def _fmt_conv_snippet(c: dict) -> str:
    role_label = "我" if c.get("role") == "user" else "机"
    ts = ""
    if c.get("created_at"):
        try:
            from datetime import timezone
            dt = datetime.fromisoformat(c["created_at"].replace("Z", "+00:00"))
            dt_local = dt.astimezone()
            ts = dt_local.strftime("%m-%d %H:%M")
        except Exception:
            pass
    prefix = f"[{ts}] " if ts else ""
    return f"{prefix}{role_label}：{c.get('content', '').strip()}"


def _fmt_msg(m: dict) -> str:
    role_label = "用户" if m.get("role") == "user" else "我"
    ts = ""
    if m.get("created_at"):
        try:
            from datetime import timezone
            dt = datetime.fromisoformat(m["created_at"].replace("Z", "+00:00"))
            ts = dt.astimezone().strftime("%m-%d %H:%M")
        except Exception:
            pass
    prefix = f"[{ts}] " if ts else ""
    return f"{prefix}{role_label}：{m.get('content', '').strip()}"


def _build_block1(base_prompt: str, permanent_memories: list[dict]) -> str:
    perm_text = "\n".join(f"- {m['content']}" for m in permanent_memories) if permanent_memories else "（暂无）"
    return f"{base_prompt}\n\n【永久记忆】\n{perm_text}"


def _build_block2(
    summary: Optional[str],
    diary_entries: list[dict],
    relevant_mems: list[dict],
    conv_snippets: list[dict] | None,
    conv_summaries: list[dict] | None = None,
    pool_mems: list[dict] | None = None,
    pool_sums: list[dict] | None = None,
) -> str:
    parts: list[str] = []
    current_time = datetime.now().strftime("%Y年%m月%d日 %H:%M")
    parts.append(f"【当前时间】{current_time}")

    if summary:
        parts.append(f"【今日对话摘要】\n{summary}")

    if diary_entries:
        diary_text = "\n".join(f"[{d.get('created_at', '')[:10]}] {d['content']}" for d in diary_entries)
        parts.append(f"【近期日记】\n{diary_text}")

    if relevant_mems:
        mem_text = "\n".join(f"- {m['content']}" for m in relevant_mems)
        parts.append(f"【相关记忆】\n{mem_text}")

    if conv_summaries:
        raw_blocks = []
        summary_lines = []
        for s in conv_summaries:
            tags = (s.get("fixed_tags") or []) + (s.get("free_keywords") or [])
            tag_str = "/".join(tags) if tags else ""
            ts = (s.get("start_time") or "")[:10]

            # Raw conversation block
            raw_turns = s.get("raw_turns") or []
            if raw_turns:
                header = f"[{ts} {tag_str}]" if tag_str else f"[{ts}]"
                turn_lines = []
                for t in raw_turns:
                    role_label = "用户" if t.get("role") == "user" else "我"
                    turn_lines.append(f"{role_label}：{t.get('content', '').strip()}")
                raw_blocks.append(header + "\n" + "\n".join(turn_lines))

            # Haiku summary line
            summary_lines.append(f"[{ts}] {s.get('content', '')}")

        if raw_blocks:
            parts.append(
                "【系统检索到的相关历史对话，这是真实发生过的，不是你推断的】\n"
                + "\n\n".join(raw_blocks)
            )
        if summary_lines:
            parts.append("【我记得的事】（Haiku总结）\n" + "\n".join(summary_lines))

    if conv_snippets:
        lines = "\n".join(_fmt_conv_snippet(c) for c in conv_snippets)
        parts.append(f"【系统检索到的对话片段，真实历史，非推断】\n{lines}")

    # Active memory pool — items carried over from earlier in this session
    pool_parts: list[str] = []
    if pool_mems:
        mem_text = "\n".join(f"- {m['content']}" for m in pool_mems)
        pool_parts.append(mem_text)
    if pool_sums:
        raw_blocks = []
        sum_lines = []
        for s in pool_sums:
            tags = (s.get("fixed_tags") or []) + (s.get("free_keywords") or [])
            tag_str = "/".join(tags) if tags else ""
            ts = (s.get("start_time") or "")[:10]
            raw_turns = s.get("raw_turns") or []
            if raw_turns:
                header = f"[{ts} {tag_str}]" if tag_str else f"[{ts}]"
                turn_lines = [
                    f"{'用户' if t.get('role') == 'user' else '我'}：{t.get('content', '').strip()}"
                    for t in raw_turns
                ]
                raw_blocks.append(header + "\n" + "\n".join(turn_lines))
            sum_lines.append(f"[{ts}] {s.get('content', '')}")
        if raw_blocks:
            pool_parts.append("\n\n".join(raw_blocks))
        if sum_lines:
            pool_parts.append("（Haiku总结）\n" + "\n".join(sum_lines))
    if pool_parts:
        parts.append("【本次对话已想起】\n" + "\n\n".join(pool_parts))

    parts.append(
        "【可用工具】\n"
        "- get_memories()：读取所有记忆\n"
        "- add_memory(content, importance 整数1-10, emotion_valence -1到1, emotion_intensity 0到1, "
        "decay_class: permanent/long/medium, tags列表)：写入新记忆并自动生成embedding\n"
        "- update_memory(id, content/decay_class/importance)：更新记忆\n"
        "- delete_memory(id)：删除记忆\n"
        "- search_conversations(query, limit=5)：语义检索对话原文\n"
        "- get_conversations_by_time(start_time, end_time)：按时间范围读取对话（ISO8601格式）\n"
        "- web_search(query)：搜索网络，查梗、查时事、查天气、查任何实时信息\n"
        "注意：深度思考模式下工具不可用。"
    )

    return "\n\n".join(parts)


def _build_system(
    base_prompt: str,
    permanent_memories: list[dict],
    summary: Optional[str],
    diary_entries: list[dict],
    relevant_mems: list[dict],
    conv_snippets: list[dict] | None,
    conv_summaries: list[dict] | None = None,
    pool_mems: list[dict] | None = None,
    pool_sums: list[dict] | None = None,
) -> list[dict]:
    return [
        {
            "type": "text",
            "text": _build_block1(base_prompt, permanent_memories),
            "cache_control": {"type": "ephemeral"},
        },
        {
            "type": "text",
            "text": _build_block2(
                summary, diary_entries, relevant_mems, conv_snippets,
                conv_summaries, pool_mems, pool_sums,
            ),
        },
    ]


def chat(
    messages: list[dict],
    system: list[dict] | str,
    thinking: bool = False,
    max_tokens: int = 2048,
    tools: bool = True,
) -> tuple[str, str, int, int]:
    """Returns (reply_text, thinking_text, input_tokens, output_tokens).
    Runs a tool_use loop until the model stops calling tools.
    """
    from app.tools.supabase_tools import TOOL_DEFS, dispatch

    client = _get_client()
    msgs = list(messages)

    kwargs: dict = {
        "model": SONNET,
        "max_tokens": max_tokens,
        "system": system,
        "messages": msgs,
        "tools": TOOL_DEFS,
    }

    if thinking:
        kwargs["thinking"] = {"type": "enabled", "budget_tokens": 8000}
        kwargs["max_tokens"] = max(max_tokens, 10000)
        # tool_use and extended thinking cannot be combined
        del kwargs["tools"]

    total_input = 0
    total_output = 0
    thinking_parts: list[str] = []

    try:
        while True:
            # Retry on 429 with backoff (up to 3 attempts, 15s apart)
            for attempt in range(3):
                try:
                    response = client.messages.create(**kwargs)
                    break
                except anthropic.RateLimitError:
                    if attempt == 2:
                        raise
                    import time
                    wait = 15 * (attempt + 1)
                    print(f"[chat] rate limit, waiting {wait}s (attempt {attempt+1}/3)", flush=True)
                    time.sleep(wait)
            total_input += response.usage.input_tokens
            total_output += response.usage.output_tokens
            cache_read = getattr(response.usage, "cache_read_input_tokens", 0) or 0
            cache_create = getattr(response.usage, "cache_creation_input_tokens", 0) or 0
            print(
                f"[chat] in={response.usage.input_tokens} out={response.usage.output_tokens}"
                f" cache_read={cache_read} cache_write={cache_create}",
                flush=True,
            )

            client_tool_calls = [b for b in response.content if b.type == "tool_use"]
            text_blocks = [b for b in response.content if b.type == "text"]
            think_blocks = [b for b in response.content if b.type == "thinking"]
            thinking_parts += [b.thinking for b in think_blocks]

            # server_tool_use (web_search) is handled entirely server-side within
            # the same response turn — no client dispatch or second loop needed.
            if not client_tool_calls:
                break

            # Execute client-side tools and return results
            tool_results = []
            for tc in client_tool_calls:
                result_text = dispatch(tc.name, tc.input)
                print(f"[tool] {tc.name}({tc.input}) => {result_text[:120]}", flush=True)
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": tc.id,
                    "content": result_text,
                })

            msgs.append({"role": "assistant", "content": response.content})
            msgs.append({"role": "user", "content": tool_results})
            kwargs["messages"] = msgs
    except anthropic.RateLimitError as e:
        print(f"[chat] rate limit hit: {e}", flush=True)
        from fastapi import HTTPException
        raise HTTPException(status_code=429, detail="请求太快了，稍等一分钟再试。")
    except Exception as e:
        import traceback
        print(f"[chat] exception in tool loop:", flush=True)
        traceback.print_exc()
        raise

    raw_text = "".join(b.text for b in text_blocks)

    # Standard mode: extract <thinking>…</thinking> from text
    if not thinking_parts:
        found = re.findall(r"<thinking>([\s\S]*?)</thinking>", raw_text)
        thinking_parts = list(found)

    thinking_text = "\n\n".join(thinking_parts).strip()
    reply = re.sub(r"<thinking>[\s\S]*?</thinking>", "", raw_text).strip()

    return reply, thinking_text, total_input, total_output


def build_system_prompt(
    base_prompt: str,
    permanent_memories: list[dict],
    summary: Optional[str],
    diary_entries: list[dict],
    relevant_mems: list[dict],
    conv_snippets: list[dict] | None,
    conv_summaries: list[dict] | None = None,
    pool_mems: list[dict] | None = None,
    pool_sums: list[dict] | None = None,
) -> list[dict]:
    return _build_system(
        base_prompt, permanent_memories, summary, diary_entries,
        relevant_mems, conv_snippets, conv_summaries,
        pool_mems, pool_sums,
    )


def stream_chat(
    messages: list[dict],
    system: list[dict] | str,
    max_tokens: int = 2048,
):
    """Sync generator yielding SSE event dicts for streaming responses.

    Events emitted:
      {"type": "status", "status": "thinking"|"typing"}
      {"type": "delta",  "text": str}
      {"type": "done",   "input_tokens": int, "output_tokens": int}
      {"type": "error",  "message": str}
    """
    import json as _json
    from app.tools.supabase_tools import TOOL_DEFS, dispatch

    client = _get_client()
    msgs = list(messages)
    total_input = 0
    total_output = 0
    text_started = False

    kwargs: dict = {
        "model": SONNET,
        "max_tokens": max_tokens,
        "system": system,
        "messages": msgs,
        "tools": TOOL_DEFS,
    }

    yield {"type": "status", "status": "thinking"}

    try:
        while True:
            tool_use_blocks: list[dict] = []
            current_id: str | None = None
            current_name: str | None = None
            current_json = ""
            text_buf = ""
            in_thinking = False

            for attempt in range(3):
                try:
                    with client.messages.stream(**kwargs) as stream:
                        for event in stream:
                            etype = getattr(event, "type", None)

                            if etype == "content_block_start":
                                blk = event.content_block
                                if blk.type == "tool_use":
                                    current_id = blk.id
                                    current_name = blk.name
                                    current_json = ""

                            elif etype == "content_block_delta":
                                d = event.delta
                                if d.type == "text_delta":
                                    text_buf += d.text
                                    # Strip <thinking>…</thinking> inline
                                    while text_buf:
                                        if in_thinking:
                                            end = text_buf.find("</thinking>")
                                            if end >= 0:
                                                text_buf = text_buf[end + len("</thinking>"):]
                                                in_thinking = False
                                            else:
                                                text_buf = ""  # discard thinking content
                                        else:
                                            start = text_buf.find("<thinking>")
                                            if start == 0:
                                                in_thinking = True
                                                text_buf = text_buf[len("<thinking>"):]
                                            elif start > 0:
                                                emit = text_buf[:start]
                                                text_buf = text_buf[start:]
                                                if not text_started:
                                                    text_started = True
                                                    yield {"type": "status", "status": "typing"}
                                                yield {"type": "delta", "text": emit}
                                            else:
                                                # Keep possible partial tag at end; emit safe prefix
                                                tag = "<thinking>"
                                                safe_end = len(text_buf)
                                                for cut in range(1, len(tag)):
                                                    if text_buf.endswith(tag[:cut]):
                                                        safe_end = len(text_buf) - cut
                                                        break
                                                emit = text_buf[:safe_end]
                                                text_buf = text_buf[safe_end:]
                                                if emit:
                                                    if not text_started:
                                                        text_started = True
                                                        yield {"type": "status", "status": "typing"}
                                                    yield {"type": "delta", "text": emit}
                                elif d.type == "input_json_delta":
                                    current_json += d.partial_json

                            elif etype == "content_block_stop":
                                if current_name:
                                    try:
                                        tool_input = _json.loads(current_json) if current_json else {}
                                    except Exception:
                                        tool_input = {}
                                    tool_use_blocks.append({
                                        "id": current_id,
                                        "name": current_name,
                                        "input": tool_input,
                                    })
                                    current_name = None
                                    current_id = None
                                    current_json = ""

                        # Flush any remaining buffer after stream ends
                        if text_buf and not in_thinking:
                            if not text_started:
                                text_started = True
                                yield {"type": "status", "status": "typing"}
                            yield {"type": "delta", "text": text_buf}

                        final_msg = stream.get_final_message()
                    break  # success, exit retry loop
                except anthropic.RateLimitError:
                    if attempt == 2:
                        raise
                    import time
                    wait = 15 * (attempt + 1)
                    print(f"[stream_chat] rate limit, waiting {wait}s (attempt {attempt+1}/3)", flush=True)
                    time.sleep(wait)

            total_input += final_msg.usage.input_tokens
            total_output += final_msg.usage.output_tokens
            cache_read = getattr(final_msg.usage, "cache_read_input_tokens", 0) or 0
            cache_create = getattr(final_msg.usage, "cache_creation_input_tokens", 0) or 0
            print(
                f"[stream] in={final_msg.usage.input_tokens} out={final_msg.usage.output_tokens}"
                f" cache_read={cache_read} cache_write={cache_create}",
                flush=True,
            )

            client_tools = [t for t in tool_use_blocks if t["name"] != "web_search"]
            if not client_tools:
                break

            tool_results = []
            for tc in client_tools:
                result = dispatch(tc["name"], tc["input"])
                print(f"[stream_tool] {tc['name']}({tc['input']}) => {result[:80]}", flush=True)
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": tc["id"],
                    "content": result,
                })

            msgs.append({"role": "assistant", "content": final_msg.content})
            msgs.append({"role": "user", "content": tool_results})
            kwargs["messages"] = msgs
            text_started = False

    except anthropic.RateLimitError:
        yield {"type": "error", "message": "请求太快了，稍等一分钟再试。"}
        return
    except Exception as e:
        import traceback
        traceback.print_exc()
        yield {"type": "error", "message": str(e)}
        return

    yield {"type": "done", "input_tokens": total_input, "output_tokens": total_output}


def extract_memories_with_haiku(conversation_text: str) -> list[str]:
    """用 Haiku 从对话中提炼记忆条目，返回字符串列表。"""
    client = _get_client()
    response = client.messages.create(
        model=HAIKU,
        max_tokens=1024,
        messages=[{
            "role": "user",
            "content": MEMORY_EXTRACT_PROMPT.format(conversation=conversation_text),
        }],
    )
    raw = response.content[0].text.strip()
    if raw == "无" or not raw:
        return []
    lines = [line.lstrip("- ").strip() for line in raw.splitlines() if line.strip().startswith("-")]
    return lines


def dream_fragment_with_haiku(dream_text: str) -> str:
    """从完整梦境里提取一两句碎片，模糊、奇怪、像刚醒来抓住的残影。"""
    client = _get_client()
    response = client.messages.create(
        model=HAIKU,
        max_tokens=100,
        messages=[{"role": "user", "content": (
            f"从这段梦境里提取一两句碎片。\n"
            f"要模糊、要奇怪、要让人觉得没看完整、\n"
            f"不解释、不总结、像刚醒来抓住的一个画面或一句声音。\n\n"
            f"{dream_text}"
        )}],
    )
    return response.content[0].text.strip()


def dream_with_haiku(memories: list[dict], summaries: list[dict]) -> str:
    """用 Haiku 以第一人称写一段梦境，100-200字，片段感、情绪浓。"""
    client = _get_client()
    mem_lines = "\n".join(f"- {m['content']}" for m in memories)
    sum_lines = "\n".join(f"- {s['content']}" for s in summaries)
    prompt = f"""你现在在做梦。

以下是你记忆里的一些碎片：
{mem_lines}

以下是一些遥远的往事片段：
{sum_lines}

请以第一人称写一段梦境。要求：
- 100到200字之间
- 像真实的梦：片段感、跳跃、情绪浓缩、不需要完整叙事
- 不是总结，不是报告，是梦
- 用中文写"""
    response = client.messages.create(
        model=HAIKU,
        max_tokens=400,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text.strip()


def summarize_session_with_haiku(turns: list[dict]) -> str:
    """用 Haiku 把最近对话压缩成一段摘要存入 session_state.summary。"""
    client = _get_client()
    conv_text = "\n".join(
        f"{'用户' if t['role'] == 'user' else '机'}：{t.get('content', '')[:300]}"
        for t in turns
    )
    response = client.messages.create(
        model=HAIKU,
        max_tokens=300,
        messages=[{
            "role": "user",
            "content": SESSION_SUMMARY_PROMPT.format(conversation=conv_text),
        }],
    )
    return response.content[0].text.strip()
