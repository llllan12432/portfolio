from dotenv import load_dotenv
load_dotenv(override=False)

import asyncio
import secrets
import json
import os
import random
import re
from contextlib import asynccontextmanager
from datetime import datetime, timezone, timedelta
from fastapi import FastAPI, HTTPException, Query, Request, Form
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, StreamingResponse, HTMLResponse, RedirectResponse
from typing import Optional
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from zoneinfo import ZoneInfo
import httpx

BARK_TOKEN     = os.environ.get("BARK_TOKEN", "")
OPENROUTER_KEY = os.environ.get("OPENROUTER_KEY", "")

from app.models import (
    ChatRequest, ChatResponse,
    PinMemoryRequest,
    DiaryRequest,
    SetPromptRequest,
    StatsResponse,
)
import app.memory as memory
import app.claude as claude_api

INCREMENTAL_TAG_THRESHOLD = 20  # trigger after this many untagged turns

scheduler = AsyncIOScheduler()

from app.mcp_server import mcp as _mcp
_mcp_app = _mcp.streamable_http_app()  # initializes session_manager
_sse_app = _mcp.sse_app()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Start MCP session manager
    async with _mcp.session_manager.run():
        # The showcase starts no scheduled notifications or device automation.
        yield
        if scheduler.running:
            scheduler.shutdown(wait=False)


app = FastAPI(title="Conversation Memory Prototype", version="0.1.0", lifespan=lifespan)
from app.access import LocalApiAccess
app.add_middleware(LocalApiAccess)

app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/mcp", _mcp_app)
app.mount("/sse", _sse_app)


@app.get("/")
async def root():
    return FileResponse("static/index.html")


def _get_base_prompt(session_id: str) -> str:
    custom = memory.get_custom_prompt(session_id)
    return custom if custom else claude_api.DEFAULT_SYSTEM


def _build_chat_system(session_id: str, message: str) -> tuple[list[dict], list[str], list[str]]:
    """Returns (system_blocks, new_memory_ids, new_summary_ids)."""
    base_prompt = _get_base_prompt(session_id)
    permanent_mems = memory.get_permanent_memories()
    summary = memory.get_session_summary(session_id)
    diary_entries = memory.get_recent_diary(session_id)
    permanent_ids = {m["id"] for m in permanent_mems if m.get("id")}
    relevant_mems = [m for m in memory.search_memories(message) if m.get("id") not in permanent_ids]
    conv_snippets = memory.search_conversations(message)
    conv_summaries = memory.search_conversation_summaries(message)

    # Enrich each summary with its raw conversation turns
    for s in conv_summaries:
        s["raw_turns"] = memory.get_conversations_in_range(
            s.get("session_id") or session_id,
            s["start_time"],
            s["end_time"],
        )

    # Collect IDs of freshly retrieved items
    new_memory_ids = [m["id"] for m in relevant_mems if m.get("id")]
    new_summary_ids = [s["id"] for s in conv_summaries if s.get("id")]

    # Fetch active pool records (exclude already-retrieved to avoid dupes)
    pool = memory.get_active_pool(session_id)
    pool_mem_ids = [i for i in pool["active_memory_ids"] if i not in new_memory_ids and i not in permanent_ids]
    pool_sum_ids = [i for i in pool["active_summary_ids"] if i not in new_summary_ids]

    pool_mems = memory.get_memories_by_ids(pool_mem_ids)
    pool_sums = memory.get_summaries_by_ids(pool_sum_ids)
    for s in pool_sums:
        s["raw_turns"] = memory.get_conversations_in_range(
            s.get("session_id") or session_id,
            s["start_time"],
            s["end_time"],
        )

    blocks = claude_api.build_system_prompt(
        base_prompt, permanent_mems, summary, diary_entries,
        relevant_mems, conv_snippets, conv_summaries,
        pool_mems, pool_sums,
    )
    return blocks, new_memory_ids, new_summary_ids


async def _maybe_summarize_async(session_id: str) -> None:
    """Fire-and-forget: compress last 10 turns into a session summary via Haiku."""
    try:
        turns = memory.get_recent_turns(session_id, turns=10)
        if len(turns) < 2:
            return
        summary = await asyncio.get_event_loop().run_in_executor(
            None, claude_api.summarize_session_with_haiku, turns
        )
        memory.save_session_summary(session_id, summary)
        print(f"[summary] {summary[:80]}", flush=True)
    except Exception as e:
        print(f"[summary] error: {e}", flush=True)


async def _maybe_tag_async(session_id: str) -> None:
    """Fire-and-forget: tag oldest 20 untagged turns if threshold reached."""
    try:
        count = memory.count_untagged_turns(session_id)
        if count < INCREMENTAL_TAG_THRESHOLD:
            return
        turns = memory.get_untagged_turns(session_id, limit=20)
        if not turns:
            return
        from app.tagger import tag_conversation_batch
        result = tag_conversation_batch(turns)
        summary_text = result.get("summary", "")
        embedding = memory.embed(summary_text) if summary_text else None
        summary_id = memory.save_conversation_summary(session_id, turns, result, embedding)
        if summary_id:
            memory.link_summary_to_neighbours(session_id, summary_id)
    except Exception as e:
        print(f"[tagger] incremental tag error: {e}")


def _build_messages(session_id: str, current_message: str) -> list[dict]:
    from datetime import datetime
    history = memory.get_recent_turns(session_id, turns=25)
    messages = [{"role": m["role"], "content": m["content"]} for m in history]
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    messages.append({"role": "user", "content": f"[{ts}] {current_message}"})
    return messages


@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    import traceback as _tb
    try:
        system_prompt, new_mem_ids, new_sum_ids = _build_chat_system(req.session_id, req.message)
        messages = _build_messages(req.session_id, req.message)
    except Exception:
        print("[/chat] error in build_chat_system or build_messages:", flush=True)
        _tb.print_exc()
        raise

    try:
        reply, thinking, input_tokens, output_tokens = claude_api.chat(messages, system_prompt)
    except Exception:
        print("[/chat] error in claude_api.chat:", flush=True)
        _tb.print_exc()
        raise

    memory.save_conversation(req.session_id, "user", req.message, token_count=input_tokens)
    memory.save_conversation(req.session_id, "assistant", reply, token_count=output_tokens)
    if thinking:
        memory.save_thinking_log(req.session_id, thinking)

    asyncio.create_task(_maybe_tag_async(req.session_id))
    asyncio.create_task(_maybe_summarize_async(req.session_id))
    memory.update_active_pool(req.session_id, new_mem_ids, new_sum_ids)

    return ChatResponse(
        reply=reply,
        session_id=req.session_id,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        thinking=thinking or None,
    )


@app.post("/chat/stream")
async def chat_stream(req: ChatRequest):
    import json as _json
    import traceback as _tb
    try:
        system_prompt, new_mem_ids, new_sum_ids = _build_chat_system(req.session_id, req.message)
        msgs = _build_messages(req.session_id, req.message)
    except Exception:
        print("[/chat/stream] error in build:", flush=True)
        _tb.print_exc()
        raise

    memory.save_conversation(req.session_id, "user", req.message)

    _DONE = object()

    def _next_event(gen):
        try:
            return next(gen)
        except StopIteration:
            return _DONE

    async def generate():
        loop = asyncio.get_event_loop()
        gen = claude_api.stream_chat(msgs, system_prompt)
        text_parts: list[str] = []
        out_tokens = 0
        error_msg: str | None = None

        while True:
            event = await loop.run_in_executor(None, _next_event, gen)
            if event is _DONE:
                break
            yield f"data: {_json.dumps(event, ensure_ascii=False)}\n\n"
            if event.get("type") == "delta":
                text_parts.append(event["text"])
            elif event.get("type") == "done":
                out_tokens = event.get("output_tokens", 0)
            elif event.get("type") == "error":
                error_msg = event.get("message")

        if error_msg is None:
            full_reply = "".join(text_parts)
            if full_reply:
                memory.save_conversation(req.session_id, "assistant", full_reply, token_count=out_tokens)
            memory.update_active_pool(req.session_id, new_mem_ids, new_sum_ids)
            asyncio.create_task(_maybe_tag_async(req.session_id))
            asyncio.create_task(_maybe_summarize_async(req.session_id))

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.post("/chat/thinking", response_model=ChatResponse)
async def chat_thinking(req: ChatRequest):
    system_prompt, new_mem_ids, new_sum_ids = _build_chat_system(req.session_id, req.message)
    messages = _build_messages(req.session_id, req.message)

    reply, thinking, input_tokens, output_tokens = claude_api.chat(messages, system_prompt, thinking=True)

    memory.save_conversation(req.session_id, "user", req.message, token_count=input_tokens)
    memory.save_conversation(req.session_id, "assistant", reply, token_count=output_tokens)
    if thinking:
        memory.save_thinking_log(req.session_id, thinking)

    asyncio.create_task(_maybe_tag_async(req.session_id))
    asyncio.create_task(_maybe_summarize_async(req.session_id))
    memory.update_active_pool(req.session_id, new_mem_ids, new_sum_ids)

    return ChatResponse(
        reply=reply,
        session_id=req.session_id,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        thinking=thinking or None,
    )


@app.post("/memory/extract/{session_id}")
async def extract_memory(session_id: str):
    history = memory.get_conversation_history(session_id, limit=40)
    if not history:
        raise HTTPException(status_code=404, detail="No conversation history found")

    conversation_text = "\n".join(
        f"{msg['role'].upper()}: {msg['content']}" for msg in history
    )

    extracted = claude_api.extract_memories_with_haiku(conversation_text)
    saved = []
    for item in extracted:
        result = memory.save_memory(content=item, source="extracted")
        saved.append(result)

    return {"extracted": len(saved), "memories": extracted}


@app.post("/memory/pin")
async def pin_memory(req: PinMemoryRequest):
    result = memory.pin_memory(content=req.content)
    return {"status": "pinned", "memory": result}


@app.post("/diary")
async def write_diary(req: DiaryRequest):
    system_prompt = (
        "你是用户的私人日记助手。请根据用户提供的内容，"
        "帮助润色成一篇温暖、真实的日记条目。保留用户的情感和细节，用第一人称书写。"
    )
    messages = [{"role": "user", "content": f"请帮我把这段内容写成日记：\n\n{req.content}"}]
    reply, _, input_tokens, output_tokens = claude_api.chat(messages, system_prompt, max_tokens=1024)

    memory.save_conversation(req.session_id, "diary", req.content)
    memory.save_conversation(req.session_id, "diary_reply", reply, token_count=output_tokens)

    return {"diary": reply, "input_tokens": input_tokens, "output_tokens": output_tokens}


@app.post("/settings/prompt/{session_id}")
async def set_prompt(session_id: str, req: SetPromptRequest):
    memory.set_custom_prompt(session_id, req.system_prompt)
    return {"status": "ok", "session_id": session_id}


@app.get("/stats/{session_id}", response_model=StatsResponse)
async def get_stats(session_id: str):
    stats = memory.get_session_stats(session_id)
    return StatsResponse(session_id=session_id, **stats)


@app.get("/memories")
async def get_memories():
    return memory.list_memories()


@app.delete("/memories/{memory_id}")
async def delete_memory(memory_id: str):
    memory.delete_memory(memory_id)
    return {"status": "deleted"}


@app.delete("/conversations/last/{session_id}")
async def delete_last_turn(session_id: str):
    deleted = memory.delete_last_turn(session_id)
    return {"deleted": deleted}


async def _do_wake(session_id: str) -> dict:
    """Core wake logic with three-path retrieval injected into the wake prompt."""
    hour = datetime.now().hour
    ctx = "深夜" if hour < 6 else "早上" if hour < 10 else "上午" if hour < 12 else "中午" if hour < 14 else "下午" if hour < 18 else "晚上"

    # Build system prompt using time-of-day as wake query
    wake_query = f"{ctx} 最近 心情"
    system, _, _ = _build_chat_system(session_id, wake_query)

    # ── Path 1: Active memory pool ────────────────────────────────────────────
    pool = memory.get_active_pool(session_id)
    pool_mems = memory.get_memories_by_ids(pool["active_memory_ids"])
    pool_sums = memory.get_summaries_by_ids(pool["active_summary_ids"])

    # ── Path 2: Random old summary (≥7 days ago) ──────────────────────────────
    old_summary = memory.get_random_old_summary(days=7)

    # ── Path 3: Time-aware memory search ─────────────────────────────────────
    now = datetime.now()
    month = now.month
    day = now.day
    time_keywords = [
        f"{month}月",
        f"{month}月底" if day >= 20 else f"{month}月初" if day <= 10 else f"{month}月中",
        "快到了",
        "计划",
        "约定",
        "那天",
    ]
    time_mems = memory.search_memories_by_keywords(time_keywords[:3], match_count=2)

    # ── Assemble wake prompt supplement ───────────────────────────────────────
    extras: list[str] = []

    if pool_mems or pool_sums:
        pool_lines: list[str] = []
        for m in pool_mems:
            pool_lines.append(f"- {m.get('content', '')}")
        for s in pool_sums:
            tags = (s.get("fixed_tags") or []) + (s.get("free_keywords") or [])
            ts = (s.get("start_time") or "")[:10]
            pool_lines.append(f"[{ts}] {s.get('content', '')} ({'/'.join(tags)})")
        extras.append("【最近想起的】\n" + "\n".join(pool_lines))

    if old_summary and old_summary.get("content"):
        tags = (old_summary.get("fixed_tags") or []) + (old_summary.get("free_keywords") or [])
        ts = (old_summary.get("start_time") or "")[:10]
        extras.append(f"【久远的一件事】\n[{ts}] {old_summary['content']} ({'/'.join(tags)})")

    if time_mems:
        time_lines = [f"- {m.get('content', '')}" for m in time_mems]
        extras.append("【近期可能有关的】\n" + "\n".join(time_lines))

    supplement = ("\n\n" + "\n\n".join(extras)) if extras else ""
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M]")
    wake_prompt = f"{timestamp}\n（重新连上了。看看上次聊到哪里，现在几点，用户可能在做什么。{supplement}）"

    history = memory.get_recent_turns(session_id, turns=40)
    messages = [{"role": m["role"], "content": m["content"]} for m in history]
    messages.append({"role": "user", "content": wake_prompt})
    reply, thinking, input_tokens, output_tokens = claude_api.chat(messages, system)
    memory.save_conversation(session_id, "assistant", reply, token_count=output_tokens)
    if thinking:
        memory.save_thinking_log(session_id, thinking)
    return {"reply": reply, "input_tokens": input_tokens, "output_tokens": output_tokens}


@app.get("/session/wake")
async def session_wake():
    return await _do_wake("main")



async def _scheduled_wake_desktop():
    """Send a wake trigger to Claude Desktop app — only if silent >1 hour."""
    try:
        last = memory.get_last_message("main")
        if last:
            age = (datetime.now(timezone.utc) - last["created_at"]).total_seconds()
            if age < 3600:
                print(f"[scheduler] desktop wake skipped, last msg {int(age)}s ago", flush=True)
                return
        print("[scheduler] firing desktop wake", flush=True)
        from app.wake_claude_app import send_wake_to_claude_app
        ok = await asyncio.get_event_loop().run_in_executor(None, send_wake_to_claude_app)
        if not ok:
            print("[scheduler] desktop wake failed (check Accessibility permission)", flush=True)
    except Exception as e:
        print(f"[scheduler] desktop wake error: {e}", flush=True)
    finally:
        next_minutes = random.randint(60, 180)
        print(f"[scheduler] next desktop wake in {next_minutes} min", flush=True)
        scheduler.reschedule_job("wake_desktop_job", trigger="interval", minutes=next_minutes)


async def _scheduled_dream():
    """Nightly dream generation with Haiku, stored in agent_logs."""
    try:
        print("[scheduler] dream job starting", flush=True)
        sb = memory._supabase()

        # Random 3-5 memories
        all_mems = (
            sb.table("memories")
            .select("id, content")
            .execute()
            .data or []
        )
        k_mem = min(random.randint(3, 5), len(all_mems))
        chosen_mems = random.sample(all_mems, k_mem) if k_mem > 0 else []

        # Random 1-2 older summaries (30+ days ago)
        from datetime import timedelta
        cutoff = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
        old_sums = (
            sb.table("conversation_summaries")
            .select("id, content")
            .lt("start_time", cutoff)
            .execute()
            .data or []
        )
        k_sum = min(random.randint(1, 2), len(old_sums))
        chosen_sums = random.sample(old_sums, k_sum) if k_sum > 0 else []

        dream_text = await asyncio.get_event_loop().run_in_executor(
            None, claude_api.dream_with_haiku, chosen_mems, chosen_sums
        )

        sb.table("agent_logs").insert({
            "trigger_type": "dream",
            "content": dream_text,
        }).execute()

        print(f"[scheduler] dream stored: {dream_text[:60]}", flush=True)
    except Exception as e:
        print(f"[scheduler] dream error: {e}", flush=True)


# ── Checkin ───────────────────────────────────────────────────────────────────

async def _push_bark(title: str, body: str) -> bool:
    """Send a push notification via ggsuper bark-compatible service."""
    if not BARK_TOKEN:
        print("[checkin] BARK_TOKEN not set", flush=True)
        return False
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(
                "https://www.ggsuper.com.cn/push/api/v1/sendMsg3_New.php",
                json={"token": BARK_TOKEN, "title": title, "msg": body, "issecure": 0, "sender": "companion"},
            )
            data = r.json()
            ok = str(data.get("code")) == "80000000"
            if not ok:
                print(f"[checkin] push failed: {data}", flush=True)
            return ok
    except Exception as e:
        print(f"[checkin] bark push error: {e}", flush=True)
        return False


def _resize_image(image_bytes: bytes, max_long_side: int = 768) -> bytes:
    """Resize image so longest side <= max_long_side, return JPEG bytes."""
    from PIL import Image
    import io
    img = Image.open(io.BytesIO(image_bytes))
    w, h = img.size
    scale = min(max_long_side / max(w, h), 1.0)
    if scale < 1.0:
        img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="JPEG", quality=85)
    return buf.getvalue()


def _analyze_screenshot(image_base64: str) -> str:
    """Send screenshot to free OpenRouter vision model for description."""
    headers = {
        "Authorization": f"Bearer {OPENROUTER_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "google/gemma-4-31b-it:free",
        "messages": [{
            "role": "user",
            "content": [
                {"type": "text", "text": "这是一张手机截图。请简短描述屏幕上正在显示什么内容，例如在看什么app、什么页面、大概在做什么。20字以内，中文，不要标点结尾。"},
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}},
            ],
        }],
        "max_tokens": 80,
    }
    resp = httpx.post(
        "https://openrouter.ai/api/v1/chat/completions",
        json=payload, headers=headers, timeout=30,
    )
    if resp.status_code != 200:
        raise Exception(f"OpenRouter {resp.status_code}: {resp.text[:300]}")
    return resp.json()["choices"][0]["message"]["content"].strip()


def _checkin_interval_str(sb) -> str:
    """Return human-readable time since last checkin, e.g. '3小时前'."""
    prev = (
        sb.table("agent_logs")
        .select("created_at")
        .eq("trigger_type", "checkin")
        .order("created_at", desc=True)
        .limit(1)
        .execute()
        .data or []
    )
    if not prev:
        return "第一次"
    last_dt = datetime.fromisoformat(prev[0]["created_at"].replace("Z", "+00:00"))
    diff = (datetime.now(timezone.utc) - last_dt).total_seconds()
    if diff < 3600:
        return f"{int(diff/60)}分钟前"
    return f"{int(diff/3600)}小时前"


@app.post("/checkin/allow")
async def checkin_allow(request: Request):
    """Receive screenshot from iPhone shortcut — raw image bytes as body."""
    sb = memory._supabase()
    interval = _checkin_interval_str(sb)
    try:
        image_data = await request.body()
        image_data = await asyncio.get_event_loop().run_in_executor(
            None, _resize_image, image_data
        )
        image_b64 = base64.b64encode(image_data).decode()
    except Exception as e:
        image_b64 = ""
        print(f"[checkin] resize error: {e}", flush=True)
    content = f"[查岗] 上次{interval}。截图已收到。"
    sb.table("agent_logs").insert({
        "trigger_type": "checkin", "result": "allow",
        "content": content, "image_b64": image_b64, "delivered": False,
    }).execute()
    print(f"[checkin] {content}", flush=True)
    return {"ok": True}


@app.post("/checkin/deny")
async def checkin_deny(request: Request):
    """Receive denial + note from iPhone shortcut — note as plain text body."""
    sb = memory._supabase()
    interval = _checkin_interval_str(sb)
    try:
        raw_note = (await request.body()).decode("utf-8").strip()
        # Handle case where shortcut sends JSON body
        if raw_note.startswith("{"):
            parsed = json.loads(raw_note)
            note = parsed.get("note", "").strip()
        else:
            note = raw_note
    except Exception:
        note = ""
    content = f"[查岗] 上次{interval}。用户拒绝了——{note}" if note else f"[查岗] 上次{interval}。用户拒绝了。"
    sb.table("agent_logs").insert({
        "trigger_type": "checkin", "result": "deny",
        "content": content, "delivered": False,
    }).execute()
    print(f"[checkin] {content}", flush=True)
    return {"ok": True}


@app.get("/checkin/deny/quick")
async def checkin_deny_quick(note: str = ""):
    """Deny via ntfy view action. With ?note=... records reason; without shows a form."""
    from fastapi.responses import HTMLResponse
    sb = memory._supabase()
    if note:
        interval = _checkin_interval_str(sb)
        content = f"[查岗] 上次{interval}。用户拒绝了——{note}"
        sb.table("agent_logs").insert({
            "trigger_type": "checkin", "result": "deny",
            "content": content, "delivered": False,
        }).execute()
        print(f"[checkin] {content}", flush=True)
        return HTMLResponse("<html><body style='font-family:sans-serif;text-align:center;padding:60px;font-size:24px'>已拒绝 ✓<br><small style='font-size:14px;color:gray'>可以关掉这个页面了</small></body></html>")
    # No note yet — show quick form
    html = """<!DOCTYPE html><html><head><meta charset='utf-8'>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<style>body{font-family:sans-serif;text-align:center;padding:40px 20px;background:#f9f9f9}
input{width:80%;padding:12px;font-size:18px;border:1px solid #ccc;border-radius:8px;margin:16px 0}
button{padding:14px 40px;font-size:18px;border:none;border-radius:10px;margin:8px;cursor:pointer}
.deny{background:#ff4444;color:#fff}.skip{background:#ddd;color:#333}
</style></head><body>
<p style='font-size:20px;margin-bottom:8px'>拒绝查岗</p>
<form method='get'>
<input name='note' placeholder='理由（可选）' autocomplete='off'>
<br>
<button type='submit' class='deny'>确认拒绝</button>
</form>
<form method='get' action='/checkin/deny/quick'>
<input type='hidden' name='note' value='没理由'>
<button type='submit' class='skip'>直接拒绝</button>
</form>
</body></html>"""
    return HTMLResponse(html)


@app.post("/checkin/submit")
async def checkin_submit(request: Request, result: str = ""):
    """Receive checkin result from iPhone shortcut.

    Allow: POST /checkin/submit?result=allow  with raw image bytes as body
    Deny:  POST /checkin/submit?result=deny&note=xxx  with empty body
    """
    content_type = request.headers.get("content-type", "")
    print(f"[checkin] result={result!r} ct={content_type[:40]} params={dict(request.query_params)}", flush=True)
    sb = memory._supabase()
    interval = _checkin_interval_str(sb)

    # Raw binary upload (simplest iOS shortcut approach)
    if result == "allow":
        try:
            image_data = await request.body()
            image_data = await asyncio.get_event_loop().run_in_executor(
                None, _resize_image, image_data
            )
            image_b64 = base64.b64encode(image_data).decode()
        except Exception as e:
            image_b64 = ""
            print(f"[checkin] resize error: {e}", flush=True)
        content = f"[查岗] 上次{interval}。截图已收到。"
        sb.table("agent_logs").insert({
            "trigger_type": "checkin", "result": "allow",
            "content": content, "image_b64": image_b64, "delivered": False,
        }).execute()
        print(f"[checkin] {content}", flush=True)
        return {"ok": True, "content": content}

    if result == "deny":
        note = request.query_params.get("note", "").strip()
        content = f"[查岗] 上次{interval}。用户拒绝了——{note}" if note else f"[查岗] 上次{interval}。用户拒绝了。"
        sb.table("agent_logs").insert({
            "trigger_type": "checkin", "result": "deny",
            "content": content, "delivered": False,
        }).execute()
        print(f"[checkin] {content}", flush=True)
        return {"ok": True, "content": content}


    if "multipart/form-data" in content_type or "application/x-www-form-urlencoded" in content_type:
        form = await request.form()
        result = form.get("result", "")
        if result == "allow":
            image_file = form.get("image")
            try:
                image_data = await image_file.read()
                image_b64 = base64.b64encode(image_data).decode()
                screen_desc = await asyncio.get_event_loop().run_in_executor(
                    None, _analyze_screenshot, image_b64
                )
            except Exception as e:
                screen_desc = f"识图失败: {e}"
            content = f"[查岗] 上次{interval}。{screen_desc}"
            sb.table("agent_logs").insert({
                "trigger_type": "checkin", "result": "allow",
                "content": content, "delivered": False,
            }).execute()
            print(f"[checkin] {content}", flush=True)
            return {"ok": True, "content": content}
        elif result == "deny":
            note = str(form.get("note", "")).strip()
            content = f"[查岗] 上次{interval}。用户拒绝了——{note}" if note else f"[查岗] 上次{interval}。用户拒绝了。"
            sb.table("agent_logs").insert({
                "trigger_type": "checkin", "result": "deny",
                "content": content, "delivered": False,
            }).execute()
            print(f"[checkin] {content}", flush=True)
            return {"ok": True, "content": content}
        return {"ok": False, "error": "invalid result"}

    # JSON fallback — strip newlines from base64 before parsing
    try:
        raw = await request.body()
        data = json.loads(re.sub(r'[\n\r]', '', raw.decode("utf-8")))
    except Exception:
        return {"ok": False, "error": f"unrecognized request, result={result!r}"}
    result = data.get("result")
    if result == "allow":
        image_b64 = data.get("image", "")
        try:
            screen_desc = await asyncio.get_event_loop().run_in_executor(
                None, _analyze_screenshot, image_b64
            )
        except Exception as e:
            screen_desc = f"识图失败: {e}"
        content = f"[查岗] 上次{interval}。{screen_desc}"
        sb.table("agent_logs").insert({
            "trigger_type": "checkin",
            "result": "allow",
            "content": content,
            "delivered": False,
        }).execute()
        print(f"[checkin] {content}", flush=True)
        return {"ok": True, "content": content}

    elif result == "deny":
        note = data.get("note", "")
        content = f"[查岗] 上次{interval}。用户拒绝了——{note}" if note else f"[查岗] 上次{interval}。用户拒绝了。"
        sb.table("agent_logs").insert({
            "trigger_type": "checkin",
            "result": "deny",
            "content": content,
            "delivered": False,
        }).execute()
        print(f"[checkin] {content}", flush=True)
        return {"ok": True, "content": content}

    return {"ok": False, "error": "invalid result"}


async def _scheduled_checkin():
    """Push Bark notification to trigger checkin flow."""
    try:
        print("[scheduler] firing checkin push", flush=True)
        await _push_bark("查岗", "现在在干嘛")
    except Exception as e:
        print(f"[scheduler] checkin error: {e}", flush=True)


@app.get("/checkin/trigger")
async def checkin_trigger():
    """Manual checkin push trigger for testing."""
    ok = await _push_bark("查岗", "现在在干嘛")
    return {"ok": ok}


@app.get("/session/wake_desktop")
async def session_wake_desktop():
    """Manual trigger for testing Desktop wake."""
    from app.wake_claude_app import send_wake_to_claude_app
    ok = await asyncio.get_event_loop().run_in_executor(None, send_wake_to_claude_app)
    return {"ok": ok}


@app.get("/session/wake/on")
async def wake_on():
    """Resume the desktop wake scheduler."""
    job = scheduler.get_job("wake_desktop_job")
    if job:
        job.resume()
        return {"wake": "on"}
    next_minutes = random.randint(60, 180)
    scheduler.add_job(_scheduled_wake_desktop, "interval", minutes=next_minutes, id="wake_desktop_job")
    return {"wake": "on"}


@app.get("/session/wake/off")
async def wake_off():
    """Pause the desktop wake scheduler."""
    job = scheduler.get_job("wake_desktop_job")
    if job:
        job.pause()
    return {"wake": "off"}


@app.get("/debug/search")
async def debug_search(q: str = Query(...)):
    if os.getenv("DEBUG_SEARCH", "false").lower() != "true":
        raise HTTPException(status_code=403, detail="debug search is disabled")
    relevant_mems = memory.search_memories(q)
    conv_snippets = memory.search_conversations(q)
    conv_summaries = memory.search_conversation_summaries(q)
    return {
        "query": q,
        "memories": [
            {"content": m.get("content"), "score": m.get("score")}
            for m in relevant_mems
        ],
        "conversations": [
            {
                "role": c.get("role"),
                "content": c.get("content"),
                "created_at": c.get("created_at"),
                "similarity": c.get("similarity"),
            }
            for c in conv_snippets
        ],
        "summaries": [
            {
                "similarity": s.get("similarity"),
                "content": s.get("content"),
                "fixed_tags": s.get("fixed_tags"),
                "free_keywords": s.get("free_keywords"),
                "start_time": s.get("start_time"),
            }
            for s in conv_summaries
        ],
    }


@app.get("/conversations/export/{session_id}")
async def export_conversations(
    session_id: str,
    from_: Optional[str] = Query(None, alias="from"),
    to: Optional[str] = None,
):
    rows = memory.export_conversations(session_id, from_, to)
    return rows


@app.get("/thinking_logs/{session_id}")
async def get_thinking_logs(
    session_id: str,
    from_: Optional[str] = Query(None, alias="from"),
):
    rows = memory.get_thinking_logs(session_id, from_)
    return rows


@app.get("/demo")
async def demo(scenario: str = "interview", days: float = Query(0, ge=0, le=365)):
    """Compute rankings over synthetic fixtures; no database, embeddings or LLM calls."""
    from showcase.ranking import run_scenario
    try:
        return run_scenario(scenario, days)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
