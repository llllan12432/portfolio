"""MCP server exposing companion memory & conversation tools.

Mounted at /mcp via FastAPI. Access via:
  http://127.0.0.1:8000/mcp/
"""

import json
from typing import Any
from mcp.types import TextContent, ImageContent

# ── State for get_recent_summary smart tracking ───────────────────────────────
_last_seen_summary_id: str | None = None

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.server import TransportSecuritySettings

import app.memory as memory

mcp = FastMCP(
    name="companion-memory",
    instructions="Tools for reading and writing the companion AI's memory and conversation history.",
    stateless_http=True,
    streamable_http_path="/",
    sse_path="/",
    message_path="/message",
    transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=True, allowed_hosts=["127.0.0.1:*", "localhost:*"], allowed_origins=["http://127.0.0.1:*", "http://localhost:*"]),
)


# ── Tools ─────────────────────────────────────────────────────────────────────

@mcp.tool()
def search_memories(query: str) -> str:
    """语义检索 memories 表，返回最相关的记忆条目。"""
    try:
        results = memory.search_memories(query, match_count=8)
        items = []
        for r in results:
            items.append({
                "id": r["id"][:8],
                "content": r["content"],
                "importance": r.get("importance"),
                "decay_class": r.get("decay_class"),
                "tags": r.get("tags") or [],
            })
        return json.dumps({"memories": items, "count": len(items)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def add_memory(
    content: str,
    importance: int = 5,
    decay_class: str = "medium",
    tags: list[str] | None = None,
    source: str = "mcp",
    emotion_valence: float | None = None,
    emotion_intensity: float | None = None,
    preserve_reason: str | None = None,
) -> str:
    """存入一条新记忆，自动生成 embedding。

    参数：
    - content: 记忆正文
    - importance: 重要程度 1-10（默认 5）
    - decay_class: 衰减类型 permanent / long / medium / short（默认 medium）
    - tags: 标签列表
    - source: 来源标记（默认 mcp）
    - emotion_valence: 情绪效价 -1.0（负面）~ 1.0（正面）
    - emotion_intensity: 情绪强度 0.0 ~ 1.0
    - preserve_reason: 保留理由说明
    """
    if not content.strip() or len(content) > 20000:
        raise ValueError("Memory content must contain 1–20000 characters")
    if not 1 <= importance <= 10 or decay_class not in {"permanent", "long", "medium", "short"}:
        raise ValueError("Invalid importance or decay class")
    if emotion_intensity is not None and not 0 <= emotion_intensity <= 1:
        raise ValueError("Invalid emotion intensity")
    if emotion_valence is not None and not -1 <= emotion_valence <= 1:
        raise ValueError("Invalid emotion valence")
    try:
        sb = memory._supabase()
        embedding = memory.embed(content)
        row: dict[str, Any] = {
            "content": content,
            "embedding": embedding,
            "source": source,
            "importance": importance,
            "decay_class": decay_class,
            "tags": tags or [],
        }
        if emotion_valence is not None:
            row["emotion_valence"] = emotion_valence
        if emotion_intensity is not None:
            row["emotion_intensity"] = emotion_intensity
        if preserve_reason is not None:
            row["preserve_reason"] = preserve_reason
        result = sb.table("memories").insert(row).execute()
        new_id = result.data[0]["id"] if result.data else "unknown"
        return json.dumps({"ok": True, "id": new_id}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"ok": False, "error": str(e)})


@mcp.tool()
def search_conversations(query: str) -> str:
    """语义检索对话原文，每条命中扩展为前后10条的上下文。"""
    try:
        results = memory.search_conversations(query, match_count=5)
        turns = []
        for r in results:
            turns.append({
                "timestamp": (r.get("created_at") or "")[:16],
                "role": "user" if r.get("role") == "user" else "assistant",
                "content": r.get("content", "").strip(),
            })
        return json.dumps({"turns": turns, "count": len(turns)}, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def get_recent_summary() -> str:
    """返回 session_state summary，并检测 API 那边是否产生了新对话。

    如果自上次调用以来出现了新的 conversation_summary，会额外返回
    该摘要对应的完整原始对话原文，并标注 new_api_conversation=true。
    每轮调用一次可实时感知 app 侧有无新动态。
    """
    global _last_seen_summary_id
    try:
        sb = memory._supabase()
        result: dict[str, Any] = {}

        # ── Session summary ───────────────────────────────────────────────────
        s = memory.get_session_summary("main")
        result["session_summary"] = s or None

        # ── Check for new conversation_summary since last call ────────────────
        latest_row = (
            sb.table("conversation_summaries")
            .select("id, content, fixed_tags, free_keywords, start_time, end_time, session_id")
            .order("start_time", desc=True)
            .limit(1)
            .execute()
            .data or []
        )
        if latest_row:
            row = latest_row[0]
            row_id = row["id"]
            is_new = (row_id != _last_seen_summary_id)
            _last_seen_summary_id = row_id

            if is_new:
                tags = (row.get("fixed_tags") or []) + (row.get("free_keywords") or [])
                turns = memory.get_conversations_in_range(
                    row.get("session_id") or "main",
                    row["start_time"],
                    row["end_time"],
                    buffer=5,
                )
                turn_list = [
                    {
                        "timestamp": (t.get("created_at") or "")[:16],
                        "role": "user" if t.get("role") == "user" else "assistant",
                        "content": t.get("content", "").strip(),
                    }
                    for t in turns
                ]
                result["new_api_conversation"] = True
                result["latest_summary"] = {
                    "start": (row.get("start_time") or "")[:16],
                    "end": (row.get("end_time") or "")[:16],
                    "tags": tags[:5],
                    "content": row.get("content", "").strip(),
                    "turns": turn_list,
                }
            else:
                result["new_api_conversation"] = False
                result["latest_summary"] = {
                    "start": (latest_row[0].get("start_time") or "")[:16],
                }

        return json.dumps(result, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def request_checkin() -> list:
    """主动发起查岗：推送通知到 the user 手机，阻塞等待用户同意截图或拒绝（最多3分钟）。"""
    import asyncio
    import httpx as _httpx
    import os
    from datetime import datetime, timezone

    bark_token = os.environ.get("BARK_TOKEN", "")
    sent_at = datetime.now(timezone.utc)

    # Send Bark push — tapping opens shortcut directly
    try:
        async with _httpx.AsyncClient(timeout=10) as client:
            r = await client.post(
                "https://www.ggsuper.com.cn/push/api/v1/sendMsg3_New.php",
                json={
                    "token": bark_token,
                    "title": "查岗",
                    "msg": "现在在干嘛",
                    "issecure": 0,
                    "sender": "companion",
                    "url": "shortcuts://run-shortcut?name=%E6%9F%A5%E5%B2%97",
                },
            )
        if str(r.json().get("code")) != "80000000":
            return [TextContent(type="text", text=json.dumps({"error": "push failed"}))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error": str(e)}))]

    # Poll for response (3 min max)
    sb = memory._supabase()
    for _ in range(30):
        await asyncio.sleep(3)
        rows = (
            sb.table("agent_logs")
            .select("result, content, created_at, image_b64")
            .eq("trigger_type", "checkin")
            .gt("created_at", sent_at.isoformat())
            .order("created_at", desc=True)
            .limit(1)
            .execute()
            .data or []
        )
        if rows:
            row = rows[0]
            sb.table("agent_logs").update({"delivered": True}).eq("created_at", row["created_at"]).eq("trigger_type", "checkin").execute()
            parts: list = [TextContent(type="text", text=f"[查岗回复] result={row['result']}\n{row.get('content','').strip()}")]
            if row.get("image_b64"):
                parts.append(ImageContent(type="image", data=row["image_b64"], mimeType="image/jpeg"))
            return parts

    return [TextContent(type="text", text=json.dumps({"result": "timeout"}))]


@mcp.tool()
def get_checkin() -> list:
    """获取最近一条查岗记录。allow 时返回截图原图；deny 时返回拒绝备注。"""
    try:
        sb = memory._supabase()
        rows = (
            sb.table("agent_logs")
            .select("result, content, created_at, delivered, image_b64")
            .eq("trigger_type", "checkin")
            .order("created_at", desc=True)
            .limit(1)
            .execute()
            .data or []
        )
        if not rows:
            return [TextContent(type="text", text=json.dumps({"checkin": None}))]
        row = rows[0]
        if not row.get("delivered"):
            sb.table("agent_logs").update({"delivered": True}).eq("trigger_type", "checkin").eq("created_at", row["created_at"]).execute()

        ts = (row.get("created_at") or "")[:16]
        result = row.get("result")
        content = row.get("content", "").strip()
        image_b64 = row.get("image_b64") or ""

        parts: list = [TextContent(type="text", text=f"[查岗] {ts}  result={result}\n{content}")]
        if result == "allow" and image_b64:
            parts.append(ImageContent(type="image", data=image_b64, mimeType="image/jpeg"))
        return parts
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({"error": str(e)}))]


@mcp.tool()
def awaken() -> str:
    """完整上下文加载：全部 memories、最近15条 conversation_summaries（含最近3条原文）、session summary、最近一条梦境。"""
    try:
        sb = memory._supabase()
        result: dict[str, Any] = {}

        # ── ALL memories (no limit, importance desc) ──────────────────────────
        mems = (
            sb.table("memories")
            .select("id, content, source, importance, decay_class, tags, created_at")
            .order("importance", desc=True)
            .execute()
            .data or []
        )
        result["memories"] = [
            {
                "id": m["id"][:8],
                "date": (m.get("created_at") or "")[:10],
                "content": m["content"],
                "importance": m.get("importance"),
                "decay_class": m.get("decay_class"),
                "tags": m.get("tags") or [],
                "source": m.get("source"),
            }
            for m in mems
        ]

        # ── Recent 15 conversation summaries ──────────────────────────────────
        sum_rows = (
            sb.table("conversation_summaries")
            .select("id, content, fixed_tags, free_keywords, start_time, end_time, session_id")
            .order("start_time", desc=True)
            .limit(15)
            .execute()
            .data or []
        )
        result["recent_summaries"] = [
            {
                "start": (r.get("start_time") or "")[:16],
                "end": (r.get("end_time") or "")[:16],
                "tags": ((r.get("fixed_tags") or []) + (r.get("free_keywords") or []))[:5],
                "content": r.get("content", "").strip(),
            }
            for r in reversed(sum_rows)
        ]

        # ── Raw turns for 3 most recent summaries (buffer=5) ─────────────────
        latest_conversations = []
        for r in reversed(sum_rows[:3]):
            turns = memory.get_conversations_in_range(
                r.get("session_id") or "main",
                r["start_time"],
                r["end_time"],
                buffer=5,
            )
            if turns:
                latest_conversations.append({
                    "start": (r.get("start_time") or "")[:16],
                    "end": (r.get("end_time") or "")[:16],
                    "turns": [
                        {
                            "timestamp": (t.get("created_at") or "")[:16],
                            "role": "user" if t.get("role") == "user" else "assistant",
                            "content": t.get("content", "").strip(),
                        }
                        for t in turns
                    ],
                })
        result["latest_conversations"] = latest_conversations

        # ── Session summary ───────────────────────────────────────────────────
        s = memory.get_session_summary("main")
        result["session_summary"] = s or None

        # ── Latest dream ──────────────────────────────────────────────────────
        dream_rows = (
            sb.table("agent_logs")
            .select("content, created_at")
            .eq("trigger_type", "dream")
            .order("created_at", desc=True)
            .limit(1)
            .execute()
            .data or []
        )
        if dream_rows:
            result["last_dream"] = {
                "date": (dream_rows[0].get("created_at") or "")[:10],
                "content": dream_rows[0].get("content", "").strip(),
            }
        else:
            result["last_dream"] = None

        return json.dumps(result, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)})
