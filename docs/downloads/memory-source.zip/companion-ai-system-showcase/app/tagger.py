import json
from app.claude import HAIKU, _get_client

TAG_PROMPT = """Summarize this conversation objectively. Return JSON only:
{{"summary": "concise factual summary", "fixed_tags": ["technical", "planning", "learning", "daily"], "free_keywords": ["relevant keywords"], "confidence": 0.85, "needs_review": false, "is_continuous": true}}
Use only relevant tags; set needs_review when confidence is below 0.7.
Conversation:
{conversation}"""


def tag_conversation_batch(turns: list[dict]) -> dict:
    """
    turns: list of {"role": "user"|"assistant", "content": str}
    Returns parsed dict with summary, fixed_tags, free_keywords, confidence, needs_review.
    """
    lines = []
    for t in turns:
        role_label = "用户" if t.get("role") == "user" else "我"
        lines.append(f"{role_label}：{t.get('content', '').strip()}")
    conversation_text = "\n".join(lines)

    client = _get_client()
    response = client.messages.create(
        model=HAIKU,
        max_tokens=512,
        messages=[{
            "role": "user",
            "content": TAG_PROMPT.format(conversation=conversation_text),
        }],
    )
    raw = response.content[0].text.strip()

    # Strip markdown code fences if present
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.strip()

    result = json.loads(raw)
    if result.get("confidence", 1.0) < 0.7:
        result["needs_review"] = True
    return result
