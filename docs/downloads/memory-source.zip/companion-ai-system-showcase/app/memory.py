import os
import re
from datetime import datetime
from typing import Optional
from openai import OpenAI
from supabase import create_client, Client

_openai_client: Optional[OpenAI] = None
_supabase_client: Optional[Client] = None


def _openai() -> OpenAI:
    global _openai_client
    if _openai_client is None:
        _openai_client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    return _openai_client


def _supabase() -> Client:
    global _supabase_client
    if _supabase_client is None:
        _supabase_client = create_client(
            os.environ["SUPABASE_URL"],
            os.environ["SUPABASE_KEY"],
        )
    return _supabase_client


def embed(text: str) -> list[float]:
    resp = _openai().embeddings.create(
        model="text-embedding-3-small",
        input=text,
    )
    return resp.data[0].embedding


def search_memories(query: str, match_count: int = 5) -> list[dict]:
    """向量相似度检索记忆，调用 Supabase RPC match_memories。"""
    query_embedding = embed(query)
    result = _supabase().rpc(
        "match_memories",
        {
            "query_embedding": query_embedding,
            "match_count": match_count,
        },
    ).execute()
    return result.data or []


def search_conversations(query: str, match_count: int = 3) -> list[dict]:
    """向量相似度检索原始对话片段，每条命中扩展为前后各10条消息。"""
    query_embedding = embed(query)
    try:
        hits = _supabase().rpc(
            "match_conversations",
            {
                "query_embedding": query_embedding,
                "match_count": match_count,
            },
        ).execute().data or []
    except Exception:
        return []

    if not hits:
        return []

    sb = _supabase()
    seen_ids: set[str] = set()
    expanded: list[dict] = []

    for hit in hits:
        hit_time = hit.get("created_at")
        hit_id = hit.get("id", "")
        session = hit.get("session_id", "main")

        if not hit_time:
            if hit_id not in seen_ids:
                seen_ids.add(hit_id)
                expanded.append(hit)
            continue

        try:
            # 10 rows before the hit (fetch desc, then reverse for chronological order)
            before = list(reversed(
                sb.table("conversations")
                .select("id, role, content, created_at, session_id")
                .eq("session_id", session)
                .in_("role", ["user", "assistant"])
                .lt("created_at", hit_time)
                .order("created_at", desc=True)
                .limit(10)
                .execute()
                .data or []
            ))

            # The hit row itself
            hit_rows = (
                sb.table("conversations")
                .select("id, role, content, created_at, session_id")
                .eq("id", hit_id)
                .limit(1)
                .execute()
                .data or []
            )
            hit_row = hit_rows[0] if hit_rows else hit

            # 10 rows after the hit
            after = (
                sb.table("conversations")
                .select("id, role, content, created_at, session_id")
                .eq("session_id", session)
                .in_("role", ["user", "assistant"])
                .gt("created_at", hit_time)
                .order("created_at")
                .limit(10)
                .execute()
                .data or []
            )

            for row in before + [hit_row] + after:
                rid = row.get("id")
                if rid not in seen_ids:
                    seen_ids.add(rid)
                    if rid == hit_id:
                        row["similarity"] = hit.get("similarity")
                    expanded.append(row)
        except Exception:
            if hit_id not in seen_ids:
                seen_ids.add(hit_id)
                expanded.append(hit)
            continue

    return expanded


def get_permanent_memories() -> list[dict]:
    """获取永久记忆：decay_class='permanent' 或 source='pinned' 的条目。"""
    sb = _supabase()
    by_decay = (
        sb.table("memories")
        .select("id, content")
        .eq("decay_class", "permanent")
        .execute()
    ).data or []
    by_pinned = (
        sb.table("memories")
        .select("id, content")
        .eq("source", "pinned")
        .execute()
    ).data or []
    # Merge, deduplicate by id
    seen: set[str] = set()
    merged = []
    for row in by_decay + by_pinned:
        if row["id"] not in seen:
            seen.add(row["id"])
            merged.append(row)
    return merged


def save_memory(content: str, source: str = "chat", importance: Optional[float] = None) -> dict:
    """存储一条记忆（带向量）。"""
    embedding = embed(content)
    row: dict = {
        "content": content,
        "embedding": embedding,
        "source": source,
    }
    if importance is not None:
        row["importance"] = importance
    result = _supabase().table("memories").insert(row).execute()
    return result.data[0] if result.data else {}


def pin_memory(content: str) -> dict:
    """手动钉选一条永久记忆。"""
    return save_memory(content=content, source="pinned", importance=1.0)


def save_thinking_log(session_id: str, thinking_content: str) -> None:
    """Save a thinking block to thinking_logs (not surfaced in conversations)."""
    try:
        _supabase().table("thinking_logs").insert({
            "session_id": session_id,
            "thinking_content": thinking_content,
        }).execute()
    except Exception:
        pass


def get_thinking_logs(session_id: str, from_time: Optional[str] = None) -> list[dict]:
    """Fetch thinking_logs for a session, optionally filtered by created_at >= from_time."""
    try:
        q = (
            _supabase()
            .table("thinking_logs")
            .select("id, created_at, thinking_content")
            .eq("session_id", session_id)
            .order("created_at")
        )
        if from_time:
            q = q.gte("created_at", from_time)
        return q.execute().data or []
    except Exception:
        return []


def save_conversation(session_id: str, role: str, content: str, token_count: int = 0) -> None:
    """存档对话消息到 conversations 表。"""
    _supabase().table("conversations").insert({
        "session_id": session_id,
        "role": role,
        "content": content,
        "token_count": token_count or None,
    }).execute()


def get_conversation_history(session_id: str, limit: int = 20) -> list[dict]:
    """读取最近 N 条对话记录（只返回 user/assistant 消息）。"""
    result = (
        _supabase()
        .table("conversations")
        .select("role, content")
        .eq("session_id", session_id)
        .in_("role", ["user", "assistant"])
        .order("created_at", desc=True)
        .limit(limit)
        .execute()
    )
    rows = result.data or []
    return list(reversed(rows))


def get_session_stats(session_id: str) -> dict:
    result = (
        _supabase()
        .table("conversations")
        .select("role, token_count")
        .eq("session_id", session_id)
        .execute()
    )
    rows = result.data or []
    total_tokens = sum(r.get("token_count") or 0 for r in rows)
    return {
        "total_messages": len(rows),
        "total_input_tokens": total_tokens,
        "total_output_tokens": 0,
    }


def get_custom_prompt(session_id: str) -> Optional[str]:
    result = (
        _supabase()
        .table("session_settings")
        .select("custom_prompt")
        .eq("session_id", session_id)
        .limit(1)
        .execute()
    )
    if result.data:
        return result.data[0].get("custom_prompt")
    return None


def set_custom_prompt(session_id: str, system_prompt: str) -> None:
    _supabase().table("session_settings").upsert({
        "session_id": session_id,
        "custom_prompt": system_prompt,
    }).execute()


def list_memories() -> list[dict]:
    result = (
        _supabase()
        .table("memories")
        .select("id, content, source, importance, created_at")
        .order("created_at", desc=True)
        .execute()
    )
    return result.data or []


def delete_memory(memory_id: str) -> None:
    _supabase().table("memories").delete().eq("id", memory_id).execute()


def delete_last_turn(session_id: str) -> int:
    """Delete the last real user+assistant pair. Skips orphan wake-only assistant rows.
    Finds the last user message, then deletes it plus any assistant rows that follow it.
    Returns number of rows deleted. Does nothing if no user message exists.
    """
    sb = _supabase()
    # Find the last user message
    user_result = (
        sb.table("conversations")
        .select("id, created_at")
        .eq("session_id", session_id)
        .eq("role", "user")
        .order("created_at", desc=True)
        .limit(1)
        .execute()
    )
    user_rows = user_result.data or []
    if not user_rows:
        return 0

    last_user = user_rows[0]
    ids_to_delete = [last_user["id"]]

    # Find assistant rows that came after this user message
    asst_result = (
        sb.table("conversations")
        .select("id")
        .eq("session_id", session_id)
        .eq("role", "assistant")
        .gt("created_at", last_user["created_at"])
        .execute()
    )
    ids_to_delete += [r["id"] for r in (asst_result.data or [])]

    sb.table("conversations").delete().in_("id", ids_to_delete).execute()
    return len(ids_to_delete)


POOL_MAX = 10


def get_active_pool(session_id: str) -> dict:
    """Return {active_memory_ids: [...], active_summary_ids: [...]} for the session."""
    try:
        result = (
            _supabase()
            .table("session_state")
            .select("active_memory_ids, active_summary_ids")
            .eq("session_id", session_id)
            .limit(1)
            .execute()
        )
        if result.data:
            row = result.data[0]
            return {
                "active_memory_ids": row.get("active_memory_ids") or [],
                "active_summary_ids": row.get("active_summary_ids") or [],
            }
    except Exception:
        pass
    return {"active_memory_ids": [], "active_summary_ids": []}


def update_active_pool(
    session_id: str,
    new_memory_ids: list[str],
    new_summary_ids: list[str],
) -> None:
    """Merge new IDs into the active pool, deduplicate, trim to POOL_MAX (FIFO)."""
    try:
        current = get_active_pool(session_id)
        # Prepend new ids, deduplicate preserving order, trim to POOL_MAX
        def merge(existing: list, new: list) -> list:
            seen: set = set()
            merged = []
            for id_ in new + existing:
                if id_ not in seen:
                    seen.add(id_)
                    merged.append(id_)
            return merged[:POOL_MAX]

        mem_ids = merge(current["active_memory_ids"], new_memory_ids)
        sum_ids = merge(current["active_summary_ids"], new_summary_ids)

        _supabase().table("session_state").upsert({
            "session_id": session_id,
            "active_memory_ids": mem_ids,
            "active_summary_ids": sum_ids,
        }).execute()
    except Exception:
        pass


def get_memories_by_ids(ids: list[str]) -> list[dict]:
    """Fetch memory records by id list."""
    if not ids:
        return []
    try:
        result = (
            _supabase()
            .table("memories")
            .select("id, content, source")
            .in_("id", ids)
            .execute()
        )
        return result.data or []
    except Exception:
        return []


def get_summaries_by_ids(ids: list[str]) -> list[dict]:
    """Fetch conversation_summaries records by id list."""
    if not ids:
        return []
    try:
        result = (
            _supabase()
            .table("conversation_summaries")
            .select("id, content, fixed_tags, free_keywords, start_time, end_time, session_id")
            .in_("id", ids)
            .execute()
        )
        return result.data or []
    except Exception:
        return []


def get_random_old_summary(days: int = 7) -> Optional[dict]:
    """Return a random conversation_summary older than `days` days."""
    try:
        from datetime import timedelta, timezone
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        result = (
            _supabase()
            .rpc("get_random_old_summary", {"cutoff_time": cutoff})
            .execute()
        )
        rows = result.data or []
        return rows[0] if rows else None
    except Exception:
        return None


def search_memories_by_keywords(keywords: list[str], match_count: int = 3) -> list[dict]:
    """Search memories using multiple keyword queries, deduplicated by id."""
    seen: set[str] = set()
    results: list[dict] = []
    for kw in keywords:
        try:
            rows = search_memories(kw, match_count=match_count)
            for r in rows:
                if r.get("id") and r["id"] not in seen:
                    seen.add(r["id"])
                    results.append(r)
        except Exception:
            continue
    return results


def get_session_summary(session_id: str) -> Optional[str]:
    """读取 session_state 表中的摘要，不存在则返回 None。"""
    try:
        result = (
            _supabase()
            .table("session_state")
            .select("summary")
            .eq("session_id", session_id)
            .limit(1)
            .execute()
        )
        if result.data:
            return result.data[0].get("summary")
    except Exception:
        pass
    return None


def save_session_summary(session_id: str, summary: str) -> None:
    try:
        _supabase().table("session_state").upsert({
            "session_id": session_id,
            "summary": summary,
        }).execute()
    except Exception as e:
        print(f"[memory] save_session_summary error: {e}", flush=True)


def get_recent_diary(session_id: str, days: int = 3) -> list[dict]:
    """取最近 N 天内 role='diary' 的条目。"""
    try:
        from datetime import timezone, timedelta
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        result = (
            _supabase()
            .table("conversations")
            .select("content, created_at")
            .eq("session_id", session_id)
            .eq("role", "diary")
            .gte("created_at", cutoff)
            .order("created_at")
            .execute()
        )
        return result.data or []
    except Exception:
        return []


def get_last_turn(session_id: str) -> list[dict]:
    """取最后一轮完整对话（最新 user + 最新 assistant，按时间顺序）。"""
    try:
        result = (
            _supabase()
            .table("conversations")
            .select("role, content, created_at")
            .eq("session_id", session_id)
            .in_("role", ["user", "assistant"])
            .order("created_at", desc=True)
            .limit(2)
            .execute()
        )
        rows = result.data or []
        return list(reversed(rows))
    except Exception:
        return []


def get_last_message(session_id: str) -> dict | None:
    """Return the single most recent user or assistant message, with created_at as datetime."""
    try:
        from datetime import timezone
        result = (
            _supabase()
            .table("conversations")
            .select("role, content, created_at")
            .eq("session_id", session_id)
            .in_("role", ["user", "assistant"])
            .order("created_at", desc=True)
            .limit(1)
            .execute()
        )
        rows = result.data or []
        if not rows:
            return None
        row = rows[0]
        dt = datetime.fromisoformat(row["created_at"].replace("Z", "+00:00"))
        row["created_at"] = dt.astimezone(timezone.utc)
        return row
    except Exception:
        return None


def get_recent_turns(session_id: str, turns: int = 20) -> list[dict]:
    """取最近 N 条消息（user+assistant），按时间正序。"""
    try:
        result = (
            _supabase()
            .table("conversations")
            .select("role, content, created_at")
            .eq("session_id", session_id)
            .in_("role", ["user", "assistant"])
            .order("created_at", desc=True)
            .limit(turns)
            .execute()
        )
        rows = result.data or []
        return list(reversed(rows))
    except Exception:
        return []


def count_untagged_turns(session_id: str) -> int:
    """Count user/assistant rows with no summary_id yet."""
    try:
        result = (
            _supabase()
            .table("conversations")
            .select("id", count="exact")
            .eq("session_id", session_id)
            .in_("role", ["user", "assistant"])
            .is_("summary_id", "null")
            .execute()
        )
        return result.count or 0
    except Exception:
        return 0


def get_untagged_turns(session_id: str, limit: int = 20) -> list[dict]:
    """Fetch oldest untagged user/assistant rows for incremental tagging."""
    try:
        result = (
            _supabase()
            .table("conversations")
            .select("id, role, content, created_at")
            .eq("session_id", session_id)
            .in_("role", ["user", "assistant"])
            .is_("summary_id", "null")
            .order("created_at")
            .limit(limit)
            .execute()
        )
        return result.data or []
    except Exception:
        return []


def save_conversation_summary(
    session_id: str,
    turns: list[dict],
    tag_result: dict,
    embedding: list[float] | None,
) -> Optional[str]:
    """Insert a summary row and back-fill summary_id on source turns."""
    try:
        row = {
            "session_id": session_id,
            "start_time": turns[0]["created_at"],
            "end_time": turns[-1]["created_at"],
            "content": tag_result.get("summary", ""),
            "fixed_tags": tag_result.get("fixed_tags", []),
            "free_keywords": tag_result.get("free_keywords", []),
            "confidence": tag_result.get("confidence", 0.0),
            "needs_review": tag_result.get("needs_review", False),
            "is_continuous": tag_result.get("is_continuous", True),
            "embedding": embedding,
        }
        result = _supabase().table("conversation_summaries").insert(row).execute()
        summary_id = result.data[0]["id"] if result.data else None
        if summary_id:
            ids = [t["id"] for t in turns if t.get("id")]
            if ids:
                _supabase().table("conversations").update({"summary_id": summary_id}).in_("id", ids).execute()
        return summary_id
    except Exception:
        return None


def link_adjacent_summaries(session_id: str, summary_ids: list[str]) -> None:
    """Set prev/next links between a list of summaries ordered by start_time."""
    if len(summary_ids) < 2:
        return
    try:
        result = (
            _supabase()
            .table("conversation_summaries")
            .select("id, start_time")
            .in_("id", summary_ids)
            .order("start_time")
            .execute()
        )
        rows = result.data or []
        for i, row in enumerate(rows):
            update: dict = {}
            if i > 0:
                update["prev_summary_id"] = rows[i - 1]["id"]
            if i < len(rows) - 1:
                update["next_summary_id"] = rows[i + 1]["id"]
            if update:
                _supabase().table("conversation_summaries").update(update).eq("id", row["id"]).execute()
    except Exception:
        pass


def link_summary_to_neighbours(session_id: str, new_summary_id: str) -> None:
    """Find the summaries immediately before/after new_summary and wire up links."""
    try:
        new_row = (
            _supabase()
            .table("conversation_summaries")
            .select("id, start_time, end_time")
            .eq("id", new_summary_id)
            .limit(1)
            .execute()
        )
        if not new_row.data:
            return
        s = new_row.data[0]

        # Previous: latest summary whose end_time < our start_time
        prev = (
            _supabase()
            .table("conversation_summaries")
            .select("id")
            .eq("session_id", session_id)
            .lt("end_time", s["start_time"])
            .neq("id", new_summary_id)
            .order("end_time", desc=True)
            .limit(1)
            .execute()
        )
        prev_id = prev.data[0]["id"] if prev.data else None

        # Next: earliest summary whose start_time > our end_time
        nxt = (
            _supabase()
            .table("conversation_summaries")
            .select("id")
            .eq("session_id", session_id)
            .gt("start_time", s["end_time"])
            .neq("id", new_summary_id)
            .order("start_time")
            .limit(1)
            .execute()
        )
        next_id = nxt.data[0]["id"] if nxt.data else None

        update: dict = {}
        if prev_id:
            update["prev_summary_id"] = prev_id
        if next_id:
            update["next_summary_id"] = next_id
        if update:
            _supabase().table("conversation_summaries").update(update).eq("id", new_summary_id).execute()

        # Update the neighbours to point back
        if prev_id:
            _supabase().table("conversation_summaries").update({"next_summary_id": new_summary_id}).eq("id", prev_id).execute()
        if next_id:
            _supabase().table("conversation_summaries").update({"prev_summary_id": new_summary_id}).eq("id", next_id).execute()
    except Exception:
        pass


def search_conversation_summaries(query: str, match_count: int = 3) -> list[dict]:
    """Two-path retrieval: vector similarity + direct tag matching."""
    merged: dict = {}

    # Path 1: vector search
    try:
        query_embedding = embed(query)
        result = _supabase().rpc(
            "match_conversation_summaries",
            {"query_embedding": query_embedding, "match_count": match_count},
        ).execute()
        for r in (result.data or []):
            merged[r["id"]] = r
    except Exception:
        pass

    # Path 2: tag overlap — split query into tokens, match against fixed_tags
    try:
        keywords = [w for w in re.split(r"[\s，。？！、,!?]+", query) if w]
        if keywords:
            tag_result = (
                _supabase()
                .table("conversation_summaries")
                .select("id, session_id, content, fixed_tags, free_keywords, start_time, end_time")
                .overlaps("fixed_tags", keywords)
                .order("start_time", desc=True)
                .limit(match_count)
                .execute()
            )
            for r in (tag_result.data or []):
                if r["id"] not in merged:
                    r["similarity"] = 1.0  # tag exact match
                    merged[r["id"]] = r
    except Exception:
        pass

    return list(merged.values())


def get_conversations_in_range(
    session_id: str,
    start_time: str,
    end_time: str,
    buffer: int = 5,
) -> list[dict]:
    """Fetch turns exactly within start/end, plus `buffer` rows before and after."""
    try:
        sb = _supabase()
        base = (
            sb.table("conversations")
            .select("id, role, content, created_at")
            .eq("session_id", session_id)
            .in_("role", ["user", "assistant"])
        )
        # Core window
        core = base.gte("created_at", start_time).lte("created_at", end_time).order("created_at").execute().data or []
        # Buffer before: latest N rows before start_time
        before = (
            sb.table("conversations").select("id, role, content, created_at")
            .eq("session_id", session_id).in_("role", ["user", "assistant"])
            .lt("created_at", start_time).order("created_at", desc=True).limit(buffer).execute().data or []
        )
        # Buffer after: earliest N rows after end_time
        after = (
            sb.table("conversations").select("id, role, content, created_at")
            .eq("session_id", session_id).in_("role", ["user", "assistant"])
            .gt("created_at", end_time).order("created_at").limit(buffer).execute().data or []
        )
        # Merge, dedup by id, sort chronologically
        seen: set = set()
        merged = []
        for row in list(reversed(before)) + core + after:
            if row["id"] not in seen:
                seen.add(row["id"])
                merged.append(row)
        return sorted(merged, key=lambda r: r["created_at"])
    except Exception:
        return []


def export_conversations(session_id: str, from_date: Optional[str], to_date: Optional[str]) -> list[dict]:
    q = (
        _supabase()
        .table("conversations")
        .select("role, content, created_at")
        .eq("session_id", session_id)
        .order("created_at")
    )
    if from_date:
        q = q.gte("created_at", from_date)
    if to_date:
        q = q.lte("created_at", to_date + "T23:59:59Z")
    return q.execute().data or []
