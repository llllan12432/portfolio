from pydantic import BaseModel, Field
from typing import Optional


class ChatRequest(BaseModel):
    session_id: str = Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9_.:-]+$")
    message: str = Field(min_length=1, max_length=20000)
    user_id: Optional[str] = "default"


class ChatResponse(BaseModel):
    reply: str
    session_id: str = Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9_.:-]+$")
    input_tokens: int
    output_tokens: int
    thinking: Optional[str] = None


class MemoryExtractRequest(BaseModel):
    pass  # session_id comes from path param


class PinMemoryRequest(BaseModel):
    content: str = Field(min_length=1, max_length=20000)


class DiaryRequest(BaseModel):
    session_id: str = Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9_.:-]+$")
    content: str = Field(min_length=1, max_length=20000)
    user_id: Optional[str] = "default"


class SetPromptRequest(BaseModel):
    system_prompt: str = Field(min_length=1, max_length=20000)


class StatsResponse(BaseModel):
    session_id: str = Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9_.:-]+$")
    total_messages: int
    total_input_tokens: int
    total_output_tokens: int
