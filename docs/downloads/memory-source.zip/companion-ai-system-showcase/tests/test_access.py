import os
import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
from app.main import app
class AccessTests(unittest.TestCase):
 def setUp(self):
  # Middleware/validation tests do not start MCP transports; startup is tested separately.
  self.client=TestClient(app)
 def test_live_routes_fail_closed_without_configuration(self):
  with patch.dict(os.environ,{'MEMORY_API_TOKEN':''}):
   self.assertEqual(self.client.get('/memories').status_code,503)
   self.assertEqual(self.client.post('/chat',json={}).status_code,503)
   self.assertEqual(self.client.get('/demo').status_code,200)
 def test_token_required_on_api_and_mcp(self):
  with patch.dict(os.environ,{'MEMORY_API_TOKEN':'x'*32}):
   for path in ['/memories','/mcp/','/docs','/openapi.json']:
    self.assertEqual(self.client.get(path).status_code,401,path)
   self.assertEqual(self.client.get('/memories',headers={'Authorization':'Bearer bad'}).status_code,401)
   self.assertEqual(self.client.post('/chat',json={},headers={'Authorization':'Bearer '+'x'*32}).status_code,422)
 def test_legacy_oauth_and_automation_disabled(self):
  self.assertEqual(self.client.get('/oauth/authorize').status_code,404)
  self.assertEqual(self.client.post('/session/wake/main').status_code,404)
 def test_demo_validation(self):
  self.assertEqual(self.client.get('/demo?days=-1').status_code,422)
  self.assertEqual(self.client.get('/demo?scenario=missing').status_code,400)
  self.assertEqual(self.client.get('/demo?days=90').json()['days'],90)
