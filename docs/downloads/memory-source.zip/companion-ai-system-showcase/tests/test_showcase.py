import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
from app.main import app, scheduler, _build_chat_system
class ShowcaseTests(unittest.TestCase):
 def test_demo_without_background_jobs(self):
  with TestClient(app) as c:
   self.assertFalse(scheduler.running)
   self.assertEqual(c.get('/demo').json()['mode'],'synthetic')
   self.assertEqual(c.get('/').status_code,200)
 def test_context_deduplication(self):
  with patch('app.main.memory') as mem, patch('app.main.claude_api.build_system_prompt',return_value=['context']):
   mem.get_custom_prompt.return_value='Neutral prompt'
   mem.get_permanent_memories.return_value=[]
   mem.get_session_summary.return_value=None
   mem.get_recent_diary.return_value=[]
   mem.search_memories.return_value=[{'id':'m1'}]
   mem.search_conversations.return_value=[]
   mem.search_conversation_summaries.return_value=[]
   mem.get_active_pool.return_value={'active_memory_ids':['m1','m2'],'active_summary_ids':[]}
   mem.get_memories_by_ids.return_value=[{'id':'m2'}]
   mem.get_summaries_by_ids.return_value=[]
   blocks,ids,_=_build_chat_system('demo','question')
   mem.get_memories_by_ids.assert_called_once_with(['m2'])
   self.assertEqual(blocks,['context']);self.assertEqual(ids,['m1'])
 def test_permanent_memories_not_injected_again_from_retrieval_or_pool(self):
  with patch('app.main.memory') as mem, patch('app.main.claude_api.build_system_prompt',return_value=['context']) as build:
   mem.get_custom_prompt.return_value='Neutral prompt'
   mem.get_permanent_memories.return_value=[{'id':'p1','content':'Permanent preference'}]
   mem.get_session_summary.return_value=None;mem.get_recent_diary.return_value=[]
   mem.search_memories.return_value=[{'id':'p1'},{'id':'m1'}]
   mem.search_conversations.return_value=[];mem.search_conversation_summaries.return_value=[]
   mem.get_active_pool.return_value={'active_memory_ids':['p1','m1','m2'],'active_summary_ids':[]}
   mem.get_memories_by_ids.return_value=[{'id':'m2'}];mem.get_summaries_by_ids.return_value=[]
   _,ids,_=_build_chat_system('demo','question')
   mem.get_memories_by_ids.assert_called_once_with(['m2'])
   self.assertEqual(ids,['m1'])
   self.assertEqual(build.call_args.args[4],[{'id':'m1'}])
