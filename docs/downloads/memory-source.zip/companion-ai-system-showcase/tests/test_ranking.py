import unittest
from showcase.ranking import score,run_scenario
class RankingTests(unittest.TestCase):
 def test_half_lives_and_non_deletion(self):
  for label,days in [('short',5),('medium',21),('long',90)]:
   self.assertAlmostEqual(score(.8,.4,5,days,label)['decay'],.5,delta=.0001)
  self.assertEqual(len(run_scenario('interview',0)['hybrid']),len(run_scenario('interview',365)['hybrid']))
 def test_recent_interview_beats_expired_despite_lower_similarity(self):
  r=run_scenario();self.assertEqual(r['semantic'][0]['id'],'expired');self.assertEqual(r['hybrid'][0]['id'],'upcoming')
 def test_permanent_is_separate_and_irrelevance_is_filtered(self):
  for days in (0,30,180):
   r=run_scenario('interview',days)
   self.assertEqual([x['id'] for x in r['permanent']],['preference'])
   self.assertNotIn('groceries',[x['id'] for x in r['hybrid']])
   self.assertNotIn('preference',[x['id'] for x in r['hybrid']])
 def test_emotion_tradeoff_is_visible(self):
  r=run_scenario('career');self.assertEqual(r['semantic'][0]['id'],'backend')
  self.assertEqual(r['hybrid'][0]['id'],'game')
 def test_bad_inputs(self):
  for args in [(float('nan'),.4,5,3,'short'),(.8,2,5,3,'short'),(.8,.4,5,-1,'short'),(.8,.4,5,3,'fast')]:
   with self.assertRaises(ValueError):score(*args)
  for query,days in [('missing',0),('interview',-1),('interview',float('inf'))]:
   with self.assertRaises(ValueError):run_scenario(query,days)
