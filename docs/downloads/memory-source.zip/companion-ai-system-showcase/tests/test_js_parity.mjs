import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {execFileSync} from 'node:child_process';import assert from 'node:assert/strict';
import {run,score} from '../demo/ranking.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const fixture=JSON.parse(fs.readFileSync(path.join(root,'demo/fixtures.json'),'utf8'));
const expected=JSON.parse(execFileSync(process.env.PYTHON||'python3',['-c',"import json;from showcase.ranking import run_scenario;print(json.dumps([run_scenario(q,d) for q in ['interview','career','game'] for d in [0,5,90,180]]))"],{cwd:root,encoding:'utf8'}));
let checks=0;
for(const item of expected){const r=run(fixture,item.scenario,item.days);for(const k of ['hybrid','semantic','permanent','excluded']){assert.deepEqual(r[k].map(x=>x.id),item[k].map(x=>x.id));checks++;}for(let i=0;i<r.hybrid.length;i++)for(const k of ['score','decay']){assert.ok(Math.abs(r.hybrid[i][k]-item.hybrid[i][k])<1e-12);checks++;}}
const edge=structuredClone(fixture);edge.memories.push({...edge.memories[1],id:'threshold',similarities:{interview:.35,career:.35,game:.35}});assert.ok(run(edge,'interview',0).excluded.some(x=>x.id==='threshold'));checks++;assert.throws(()=>score(NaN,.5,5,0,'short'));checks++;
console.log(`PASS ${checks} Python/JavaScript parity and boundary assertions across ${expected.length} scenarios`);
