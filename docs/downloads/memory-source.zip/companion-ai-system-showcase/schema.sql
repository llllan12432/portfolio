-- Companion AI System - Database Schema
-- Exported: April 2026

-- Enable vector extension (required for embeddings)
CREATE EXTENSION IF NOT EXISTS vector;

-- Long-term memory storage
CREATE TABLE memories (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  content text NOT NULL,
  importance integer NOT NULL DEFAULT 5 CHECK (importance >= 1 AND importance <= 10),
  emotion_valence double precision CHECK (emotion_valence >= -1 AND emotion_valence <= 1),
  emotion_intensity double precision NOT NULL DEFAULT 0.5 CHECK (emotion_intensity >= 0 AND emotion_intensity <= 1),
  decay_class text NOT NULL DEFAULT 'medium' CHECK (decay_class = ANY (ARRAY['permanent','long','medium','short'])),
  tags text[] NOT NULL DEFAULT '{}',
  source text,
  preserve_reason text,
  embedding vector,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);

-- Full conversation log
CREATE TABLE conversations (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  session_id text NOT NULL,
  role text NOT NULL CHECK (role = ANY (ARRAY['user','assistant'])),
  content text NOT NULL,
  token_count integer,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  embedding vector,
  tags text[] DEFAULT '{}',
  summary_id uuid,
  PRIMARY KEY (id)
);

-- Auto-generated summaries (every 50 turns via Haiku)
CREATE TABLE conversation_summaries (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  session_id text,
  start_time timestamp with time zone,
  end_time timestamp with time zone,
  content text,
  fixed_tags text[],
  free_keywords text[],
  confidence double precision,
  needs_review boolean DEFAULT false,
  embedding vector,
  created_at timestamp with time zone DEFAULT now(),
  PRIMARY KEY (id)
);

-- Current session state
CREATE TABLE session_state (
  session_id text NOT NULL,
  summary text,
  mood text,
  pending text,
  last_topic text,
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (session_id)
);

-- Per-session custom configuration
CREATE TABLE session_settings (
  session_id text NOT NULL,
  custom_prompt text,
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (session_id)
);

-- Optional legacy diary table. This schema does not encrypt content.
CREATE TABLE diary (
  id uuid NOT NULL DEFAULT gen_random_uuid(),
  date date NOT NULL DEFAULT CURRENT_DATE,
  title text,
  content text NOT NULL,
  emotion_valence double precision CHECK (emotion_valence >= -1 AND emotion_valence <= 1),
  emotion_intensity double precision DEFAULT 0.5 CHECK (emotion_intensity >= 0 AND emotion_intensity <= 1),
  tags text[] NOT NULL DEFAULT '{}',
  embedding vector,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  PRIMARY KEY (id)
);
