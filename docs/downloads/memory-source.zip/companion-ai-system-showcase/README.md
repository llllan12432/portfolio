# Conversation Memory Prototype

A personal, AI-assisted experiment in persistent conversational context. Memories are ranked using semantic similarity, emotion, time and importance; permanent memory and a bounded active pool form separate context layers.

## Try it in one command

With Python 3.11 or newer, from this folder:

```sh
python3 -m showcase
```

Open http://127.0.0.1:8765. No packages, API keys or database are required for this synthetic ranking explorer. On Windows use `python -m showcase`. It serves only `demo/` on loopback; it does not start the original application or device automation.

Change the prompt or advance time. Both columns compute their rankings; similarities are fixed illustrative fixture values, not live embeddings. The browser code and Python reference implement the same formula as the original SQL. This is an executable policy demonstration, not a retrieval accuracy benchmark.

## What the policy does

After a semantic similarity threshold of 0.35, the score is:

`0.25 × similarity + 0.40 × emotional intensity + 0.25 × exp(-0.693 × age_days / half_life) + 0.10 × importance/10`

Half-lives: short 5 days, medium 21 days, long 90 days. Permanent memories are loaded separately. Decay lowers retrieval priority; it does not delete stored data. A visible counterexample shows that the large emotion weight can overpower relevance. The weights are a design hypothesis, not an established optimum.

## Original application architecture

Browser → FastAPI → Supabase/PostgreSQL retrieval → layered context → model API → SSE stream. Messages and summaries are persisted. The context builder combines permanent memory, newly retrieved items, retained active context and recent turns. MCP exposes memory tools.

The `app/`, `schema.sql` and `migrations/` files preserve the technical application snapshot, with October portfolio maintenance. The original private conversations, default persona, credentials and Git history are excluded. See `REVIEW.md` and `PORTFOLIO_CHANGES.md`.

## Tests

Dependency-free ranking tests:

```sh
python3 -m unittest discover -s tests -p test_ranking.py -v
```

Optional Python/JavaScript parity test (Node.js required):

```sh
node tests/test_js_parity.mjs
```

Full application tests require the packages in `requirements.txt`:

```sh
python3 -m venv .venv
# Activate .venv, then:
pip install -r requirements.txt
python -m unittest discover -s tests -v
```

The checks use synthetic inputs and mocked providers. They do not access private records or validate live embedding quality.

## Optional live API mode

The original provider-backed application is a separate mode, not needed for the explorer. It requires model credentials and an already-configured Supabase database. Existing SQL artifacts are not yet a complete verified fresh-install bootstrap; additional legacy RPCs/tables are referenced. Do not apply them blindly to an existing database.

Set `MEMORY_API_TOKEN` to a random value of at least 32 characters and use `Authorization: Bearer <token>` for live API and MCP requests. The application refuses those requests when the token is absent. Legacy OAuth discovery/approval and device/check-in automation routes are disabled. No scheduled jobs start automatically. This is a single-owner local API boundary, not multi-user OAuth or production security. The original browser UI is retained as legacy source; its API calls have not been adapted for this token workflow. Use the standalone explorer for the no-configuration demonstration.

```sh
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Do not expose this live mode publicly without completing database setup, authorization design, rate limiting and provider-failure handling. The public portfolio hosts static files only and never connects to this API or the personal database.

## Contribution

The original personal README documents the design evolution and architecture. AI assisted implementation. October 2026 showcase work used Codex to add the isolated explorer, regression checks, API guard and documentation. These later changes are not represented as part of an earlier assessed submission. No claim of independently handwriting every line, production deployment or measured retrieval improvement is made.
