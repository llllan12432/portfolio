"""
One-shot script: tag all historical conversations in batches of 50 turns.
Run: python batch_tag.py [session_id]
Default session_id: main
"""
import sys
import os
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

from supabase import create_client
from app.tagger import tag_conversation_batch
from app.memory import embed

BATCH_SIZE = 50  # turns per summary


def fetch_all_turns(sb, session_id: str) -> list[dict]:
    """Paginate through all untagged turns (Supabase max 1000 rows per request)."""
    PAGE = 1000
    rows = []
    offset = 0
    while True:
        result = (
            sb.table("conversations")
            .select("id, role, content, created_at")
            .eq("session_id", session_id)
            .in_("role", ["user", "assistant"])
            .is_("summary_id", "null")
            .order("created_at")
            .range(offset, offset + PAGE - 1)
            .execute()
        )
        page = result.data or []
        rows.extend(page)
        if len(page) < PAGE:
            break
        offset += PAGE
    return rows


def save_summary(sb, session_id: str, turns: list[dict], tag_result: dict) -> str:
    start_time = turns[0]["created_at"]
    end_time = turns[-1]["created_at"]

    summary_text = tag_result.get("summary", "")
    embedding = embed(summary_text) if summary_text else None

    row = {
        "session_id": session_id,
        "start_time": start_time,
        "end_time": end_time,
        "content": summary_text,
        "fixed_tags": tag_result.get("fixed_tags", []),
        "free_keywords": tag_result.get("free_keywords", []),
        "confidence": tag_result.get("confidence", 0.0),
        "needs_review": tag_result.get("needs_review", False),
        "is_continuous": tag_result.get("is_continuous", True),
        "embedding": embedding,
    }
    result = sb.table("conversation_summaries").insert(row).execute()
    summary_id = result.data[0]["id"] if result.data else None

    # Back-fill summary_id on the source rows
    if summary_id:
        ids = [t["id"] for t in turns if t.get("id")]
        if ids:
            sb.table("conversations").update({"summary_id": summary_id}).in_("id", ids).execute()

    return summary_id


def main(session_id: str):
    sb = create_client(os.environ["SUPABASE_URL"], os.environ["SUPABASE_KEY"])

    print(f"Fetching turns for session '{session_id}'...")
    turns = fetch_all_turns(sb, session_id)
    print(f"Total turns: {len(turns)}")

    batches = [turns[i:i + BATCH_SIZE] for i in range(0, len(turns), BATCH_SIZE)]
    print(f"Batches: {len(batches)} × up to {BATCH_SIZE} turns each\n")

    needs_review_count = 0
    created_ids: list[str] = []

    for idx, batch in enumerate(batches, 1):
        try:
            result = tag_conversation_batch(batch)
            summary_id = save_summary(sb, session_id, batch, result)
            if summary_id:
                created_ids.append(summary_id)
            flag = " ⚠ needs_review" if result.get("needs_review") else ""
            cont = "" if result.get("is_continuous", True) else " ↻ discontinuous"
            print(
                f"[{idx:3}/{len(batches)}] saved {(summary_id or 'ERR')[:8]}…  "
                f"conf={result.get('confidence', 0):.2f}  "
                f"tags={result.get('fixed_tags', [])}  "
                f"kw={result.get('free_keywords', [])}{flag}{cont}"
            )
            if result.get("needs_review"):
                needs_review_count += 1
        except Exception as e:
            print(f"[{idx:3}/{len(batches)}] ERROR: {e}")

    # Link adjacent summaries (prev/next)
    if created_ids:
        print("\nLinking adjacent summaries…", end=" ")
        from app.memory import link_adjacent_summaries
        link_adjacent_summaries(session_id, created_ids)
        print("done.")

    print(f"Done. {len(created_ids)} summaries created, {needs_review_count} flagged for review.")


if __name__ == "__main__":
    sid = sys.argv[1] if len(sys.argv) > 1 else "main"
    main(sid)
