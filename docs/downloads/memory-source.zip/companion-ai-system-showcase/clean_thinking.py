"""
Strip <thinking>...</thinking> blocks from all assistant messages in conversations table.
Run after creating thinking_logs table.
"""
import os, re
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))
from supabase import create_client

THINKING_RE = re.compile(r"<thinking>[\s\S]*?</thinking>", re.IGNORECASE)
PAGE = 500


def main():
    sb = create_client(os.environ["SUPABASE_URL"], os.environ["SUPABASE_KEY"])

    updated = skipped = errors = 0
    offset = 0

    while True:
        result = (
            sb.table("conversations")
            .select("id, content")
            .eq("role", "assistant")
            .range(offset, offset + PAGE - 1)
            .execute()
        )
        rows = result.data or []
        if not rows:
            break

        for row in rows:
            content = row.get("content") or ""
            if "<thinking>" not in content:
                skipped += 1
                continue
            cleaned = THINKING_RE.sub("", content).strip()
            try:
                sb.table("conversations").update({"content": cleaned}).eq("id", row["id"]).execute()
                updated += 1
            except Exception as e:
                print(f"  ERROR id={row['id']}: {e}")
                errors += 1

        print(f"  processed {offset + len(rows)} rows (updated so far: {updated})", end="\r")
        if len(rows) < PAGE:
            break
        offset += PAGE

    print(f"\nDone. updated={updated}, skipped={skipped}, errors={errors}")


if __name__ == "__main__":
    main()
