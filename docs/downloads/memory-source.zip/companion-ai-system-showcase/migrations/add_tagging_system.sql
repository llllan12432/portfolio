-- Step 1a: add columns to conversations
ALTER TABLE conversations ADD COLUMN IF NOT EXISTS tags text[] DEFAULT '{}';
ALTER TABLE conversations ADD COLUMN IF NOT EXISTS summary_id uuid;

-- Step 1b: create conversation_summaries table
CREATE TABLE IF NOT EXISTS conversation_summaries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text,
  start_time timestamptz,
  end_time timestamptz,
  content text,
  fixed_tags text[],
  free_keywords text[],
  confidence float,
  needs_review boolean DEFAULT false,
  embedding vector(1536),
  created_at timestamptz DEFAULT now()
);

-- Step 1c: index for vector search
CREATE INDEX IF NOT EXISTS conversation_summaries_embedding_idx
  ON conversation_summaries
  USING hnsw (embedding vector_cosine_ops);

-- Step 1d: RPC for semantic search over summaries
CREATE OR REPLACE FUNCTION match_conversation_summaries(
  query_embedding vector(1536),
  match_count int
)
RETURNS TABLE (
  id uuid,
  session_id text,
  content text,
  fixed_tags text[],
  free_keywords text[],
  confidence float,
  start_time timestamptz,
  end_time timestamptz,
  similarity float
)
LANGUAGE sql STABLE
AS $$
  SELECT
    s.id,
    s.session_id,
    s.content,
    s.fixed_tags,
    s.free_keywords,
    s.confidence,
    s.start_time,
    s.end_time,
    1 - (s.embedding <=> query_embedding) AS similarity
  FROM conversation_summaries s
  WHERE s.embedding IS NOT NULL
    AND (1 - (s.embedding <=> query_embedding)) > 0.30
  ORDER BY s.embedding <=> query_embedding
  LIMIT match_count;
$$;
