ALTER TABLE conversation_summaries ADD COLUMN IF NOT EXISTS is_continuous boolean DEFAULT true;
ALTER TABLE conversation_summaries ADD COLUMN IF NOT EXISTS prev_summary_id uuid REFERENCES conversation_summaries(id);
ALTER TABLE conversation_summaries ADD COLUMN IF NOT EXISTS next_summary_id uuid REFERENCES conversation_summaries(id);
