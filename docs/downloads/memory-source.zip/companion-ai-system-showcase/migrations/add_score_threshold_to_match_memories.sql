CREATE OR REPLACE FUNCTION match_memories(
  query_embedding vector(1536),
  match_count int
)
RETURNS TABLE (
  id uuid,
  content text,
  importance float,
  emotion_valence float,
  emotion_intensity float,
  decay_class text,
  tags text[],
  source text,
  created_at timestamptz,
  score float
)
LANGUAGE sql STABLE
AS $$
  select
    m.id,
    m.content,
    m.importance,
    m.emotion_valence,
    m.emotion_intensity,
    m.decay_class,
    m.tags,
    m.source,
    m.created_at,
    (
      (1 - (m.embedding <=> query_embedding))  * 0.25 +
      m.emotion_intensity                       * 0.40 +
      case m.decay_class
        when 'permanent' then 1.0
        when 'long'   then exp(-0.693 * extract(epoch from (now() - m.created_at)) / (90*86400))
        when 'medium' then exp(-0.693 * extract(epoch from (now() - m.created_at)) / (21*86400))
        when 'short'  then exp(-0.693 * extract(epoch from (now() - m.created_at)) / (5*86400))
        else               exp(-0.693 * extract(epoch from (now() - m.created_at)) / (21*86400))
      end                                       * 0.25 +
      m.importance / 10.0                       * 0.10
    ) as score
  from public.memories m
  where m.embedding is not null
    and m.decay_class != 'permanent'
    and (1 - (m.embedding <=> query_embedding)) > 0.35
  order by score desc
  limit match_count;
$$;
