ALTER TABLE session_state ADD COLUMN IF NOT EXISTS active_memory_ids jsonb DEFAULT '[]';
ALTER TABLE session_state ADD COLUMN IF NOT EXISTS active_summary_ids jsonb DEFAULT '[]';
