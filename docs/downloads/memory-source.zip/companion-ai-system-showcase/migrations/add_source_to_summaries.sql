ALTER TABLE conversation_summaries
  ADD COLUMN IF NOT EXISTS source text DEFAULT 'haiku_summary';
