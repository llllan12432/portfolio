CREATE OR REPLACE FUNCTION get_random_old_summary(cutoff_time timestamptz)
RETURNS TABLE (
  id uuid,
  content text,
  fixed_tags text[],
  free_keywords text[],
  start_time timestamptz,
  end_time timestamptz,
  session_id text
)
LANGUAGE sql STABLE AS $$
  SELECT id, content, fixed_tags, free_keywords, start_time, end_time, session_id
  FROM conversation_summaries
  WHERE start_time < cutoff_time
    AND content IS NOT NULL
    AND content <> ''
  ORDER BY RANDOM()
  LIMIT 1;
$$;
