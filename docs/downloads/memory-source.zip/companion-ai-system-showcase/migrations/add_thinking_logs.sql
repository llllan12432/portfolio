CREATE TABLE IF NOT EXISTS thinking_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text,
  created_at timestamptz DEFAULT now(),
  thinking_content text
);
