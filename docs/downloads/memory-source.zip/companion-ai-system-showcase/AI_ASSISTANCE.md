# Contribution

Technical showcase derived from the author's personal application, with AI-assisted development. Confirm personal design, implementation, integration and testing contributions before making precise CV claims. The student did not train the underlying models. No claims of consciousness, production security or measured retrieval quality are made.
