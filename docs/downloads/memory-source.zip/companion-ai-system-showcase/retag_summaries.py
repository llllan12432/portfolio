"""
Rewrite conversation_summaries.content with neutral factual language using updated prompt.
Updates only: content, embedding. Tags and keywords are left untouched.
Run: python retag_summaries.py
"""
import os
import json
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

from supabase import create_client
from app.claude import HAIKU, _get_client
from app.memory import embed

RETAG_PROMPT = """Summarize the following conversation objectively in one factual sentence:
{conversation}"""

FETCH_PROMPT = """Rewrite the following summary objectively, preserving facts and uncertainty. Return one sentence:
{old_summary}"""


def rewrite_summary(old_summary: str) -> str:
    client = _get_client()
    response = client.messages.create(
        model=HAIKU,
        max_tokens=256,
        messages=[{
            "role": "user",
            "content": FETCH_PROMPT.format(old_summary=old_summary),
        }],
    )
    return response.content[0].text.strip()


def main():
    sb = create_client(os.environ["SUPABASE_URL"], os.environ["SUPABASE_KEY"])

    # Fetch all summaries
    result = sb.table("conversation_summaries") \
        .select("id, content, start_time") \
        .order("start_time") \
        .execute()
    rows = result.data or []
    print(f"Total summaries to rewrite: {len(rows)}\n")

    updated = 0
    errors = 0
    for i, row in enumerate(rows, 1):
        old_content = row.get("content") or ""
        sid = row["id"]
        ts = (row.get("start_time") or "")[:10]
        try:
            new_content = rewrite_summary(old_content)
            new_embedding = embed(new_content)
            sb.table("conversation_summaries").update({
                "content": new_content,
                "embedding": new_embedding,
            }).eq("id", sid).execute()
            print(f"[{i:3}/{len(rows)}] {ts}  {new_content[:80]}")
            updated += 1
        except Exception as e:
            print(f"[{i:3}/{len(rows)}] {ts}  ERROR: {e}")
            errors += 1

    print(f"\nDone. {updated} rewritten, {errors} errors.")


if __name__ == "__main__":
    main()
