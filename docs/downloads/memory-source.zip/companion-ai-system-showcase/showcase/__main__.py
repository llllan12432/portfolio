"""Serve the synthetic browser demo: python -m showcase. No SDKs or keys needed."""
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import argparse
from functools import partial
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--port',type=int,default=8765)
args=parser.parse_args();root=Path(__file__).resolve().parent.parent/'demo'
print(f'Synthetic ranking explorer: http://127.0.0.1:{args.port}',flush=True)
ThreadingHTTPServer(('127.0.0.1',args.port),partial(SimpleHTTPRequestHandler,directory=str(root))).serve_forever()
