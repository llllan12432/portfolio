"""Offline synthetic ranking demonstration; uses no external credentials."""
