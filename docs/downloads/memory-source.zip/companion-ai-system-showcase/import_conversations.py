import json
import sys
import os
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

from supabase import create_client

SESSION_ID = "imported_history"
BATCH_SIZE = 100

def extract_text(msg: dict) -> str:
    text = (msg.get("text") or "").strip()
    if text:
        return text
    for block in msg.get("content") or []:
        t = (block.get("text") or "").strip()
        if t:
            return t
    return ""

def main(json_path: str):
    with open(json_path, encoding="utf-8") as f:
        data = json.load(f)

    messages = data["chat_messages"]
    print(f"原始消息数: {len(messages)}")

    role_map = {"human": "user", "assistant": "assistant"}

    rows = []
    skipped = 0
    for msg in messages:
        text = extract_text(msg)
        if not text:
            skipped += 1
            continue
        sender = msg.get("sender", "")
        role = role_map.get(sender)
        if role is None:
            skipped += 1
            continue
        rows.append({
            "session_id": SESSION_ID,
            "role": role,
            "content": text,
            "created_at": msg.get("created_at"),
        })

    print(f"待导入: {len(rows)} 条  |  跳过: {skipped} 条")

    sb = create_client(os.environ["SUPABASE_URL"], os.environ["SUPABASE_KEY"])

    imported = 0
    for i in range(0, len(rows), BATCH_SIZE):
        batch = rows[i : i + BATCH_SIZE]
        sb.table("conversations").insert(batch).execute()
        imported += len(batch)
        print(f"  已导入 {imported}/{len(rows)}", end="\r", flush=True)

    print(f"\n完成。导入 {imported} 条，跳过 {skipped} 条。")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python import_conversations.py sample-export.json")
    path = sys.argv[1]
    main(path)
